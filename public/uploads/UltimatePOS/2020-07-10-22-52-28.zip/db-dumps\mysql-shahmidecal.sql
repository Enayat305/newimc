
/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;
DROP TABLE IF EXISTS `account_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_transactions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `account_id` int(11) NOT NULL,
  `type` enum('debit','credit') COLLATE utf8mb4_unicode_ci NOT NULL,
  `sub_type` enum('debit','opening_balance','fund_transfer','deposit') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `amount` decimal(22,4) NOT NULL,
  `reff_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `operation_date` datetime NOT NULL,
  `created_by` int(11) NOT NULL,
  `transaction_id` int(11) DEFAULT NULL,
  `transaction_payment_id` int(11) DEFAULT NULL,
  `transfer_transaction_id` int(11) DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `account_transactions_account_id_index` (`account_id`),
  KEY `account_transactions_transaction_id_index` (`transaction_id`),
  KEY `account_transactions_transaction_payment_id_index` (`transaction_payment_id`),
  KEY `account_transactions_transfer_transaction_id_index` (`transfer_transaction_id`),
  KEY `account_transactions_created_by_index` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `account_transactions` WRITE;
/*!40000 ALTER TABLE `account_transactions` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_transactions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `account_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `account_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `parent_account_type_id` int(11) DEFAULT NULL,
  `business_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `account_types` WRITE;
/*!40000 ALTER TABLE `account_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `account_types` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `accounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `accounts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_number` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `account_type_id` int(11) DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `is_closed` tinyint(1) NOT NULL DEFAULT 0,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `accounts` WRITE;
/*!40000 ALTER TABLE `accounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `accounts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `activity_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `activity_log` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `log_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `subject_id` int(11) DEFAULT NULL,
  `subject_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `causer_id` int(11) DEFAULT NULL,
  `causer_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `properties` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `activity_log_log_name_index` (`log_name`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `activity_log` WRITE;
/*!40000 ALTER TABLE `activity_log` DISABLE KEYS */;
/*!40000 ALTER TABLE `activity_log` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `allergies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `allergies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `actual_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `base_id` int(11) DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `allergies_business_id_foreign` (`business_id`),
  KEY `allergies_created_by_foreign` (`created_by`),
  CONSTRAINT `allergies_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `allergies_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `allergies` WRITE;
/*!40000 ALTER TABLE `allergies` DISABLE KEYS */;
/*!40000 ALTER TABLE `allergies` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `appointments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `appointments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `schedul_id` int(10) unsigned NOT NULL,
  `contact_id` int(10) unsigned NOT NULL,
  `doctor_id` int(10) unsigned NOT NULL,
  `appointment_id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sequence` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `get_date_time` datetime NOT NULL,
  `date` date NOT NULL,
  `note` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `fee_status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(10) unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `appointments_business_id_foreign` (`business_id`),
  KEY `appointments_schedul_id_foreign` (`schedul_id`),
  KEY `appointments_contact_id_foreign` (`contact_id`),
  KEY `appointments_doctor_id_foreign` (`doctor_id`),
  KEY `appointments_user_id_foreign` (`user_id`),
  CONSTRAINT `appointments_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `appointments_contact_id_foreign` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `appointments_doctor_id_foreign` FOREIGN KEY (`doctor_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `appointments_schedul_id_foreign` FOREIGN KEY (`schedul_id`) REFERENCES `schedules` (`id`) ON DELETE CASCADE,
  CONSTRAINT `appointments_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `appointments` WRITE;
/*!40000 ALTER TABLE `appointments` DISABLE KEYS */;
/*!40000 ALTER TABLE `appointments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `barcodes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `barcodes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `width` double(22,4) DEFAULT NULL,
  `height` double(22,4) DEFAULT NULL,
  `paper_width` double(22,4) DEFAULT NULL,
  `paper_height` double(22,4) DEFAULT NULL,
  `top_margin` double(22,4) DEFAULT NULL,
  `left_margin` double(22,4) DEFAULT NULL,
  `row_distance` double(22,4) DEFAULT NULL,
  `col_distance` double(22,4) DEFAULT NULL,
  `stickers_in_one_row` int(11) DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `is_continuous` tinyint(1) NOT NULL DEFAULT 0,
  `stickers_in_one_sheet` int(11) DEFAULT NULL,
  `business_id` int(10) unsigned DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `barcodes_business_id_foreign` (`business_id`),
  CONSTRAINT `barcodes_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `barcodes` WRITE;
/*!40000 ALTER TABLE `barcodes` DISABLE KEYS */;
/*!40000 ALTER TABLE `barcodes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `bookings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `bookings` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `contact_id` int(10) unsigned NOT NULL,
  `waiter_id` int(10) unsigned DEFAULT NULL,
  `table_id` int(10) unsigned DEFAULT NULL,
  `correspondent_id` int(11) DEFAULT NULL,
  `business_id` int(10) unsigned NOT NULL,
  `location_id` int(10) unsigned NOT NULL,
  `booking_start` datetime NOT NULL,
  `booking_end` datetime NOT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `booking_status` enum('booked','completed','cancelled') COLLATE utf8mb4_unicode_ci NOT NULL,
  `booking_note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `bookings_contact_id_foreign` (`contact_id`),
  KEY `bookings_business_id_foreign` (`business_id`),
  KEY `bookings_created_by_foreign` (`created_by`),
  KEY `bookings_table_id_index` (`table_id`),
  KEY `bookings_waiter_id_index` (`waiter_id`),
  KEY `bookings_location_id_index` (`location_id`),
  CONSTRAINT `bookings_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bookings_contact_id_foreign` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `bookings_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `bookings` WRITE;
/*!40000 ALTER TABLE `bookings` DISABLE KEYS */;
/*!40000 ALTER TABLE `bookings` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `brands`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `brands` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `brands_business_id_foreign` (`business_id`),
  KEY `brands_created_by_foreign` (`created_by`),
  CONSTRAINT `brands_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `brands_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `brands` WRITE;
/*!40000 ALTER TABLE `brands` DISABLE KEYS */;
/*!40000 ALTER TABLE `brands` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `business`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `business` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency_id` int(10) unsigned NOT NULL,
  `start_date` date DEFAULT NULL,
  `tax_number_1` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_label_1` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_number_2` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_label_2` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `default_sales_tax` int(10) unsigned DEFAULT NULL,
  `default_profit_percent` double(5,2) NOT NULL DEFAULT 0.00,
  `owner_id` int(10) unsigned NOT NULL,
  `time_zone` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'Asia/Kolkata',
  `fy_start_month` tinyint(4) NOT NULL DEFAULT 1,
  `accounting_method` enum('fifo','lifo','avco') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'fifo',
  `default_sales_discount` decimal(5,2) DEFAULT NULL,
  `sell_price_tax` enum('includes','excludes') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'includes',
  `logo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sku_prefix` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enable_product_expiry` tinyint(1) NOT NULL DEFAULT 0,
  `expiry_type` enum('add_expiry','add_manufacturing') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'add_expiry',
  `on_product_expiry` enum('keep_selling','stop_selling','auto_delete') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'keep_selling',
  `stop_selling_before` int(11) NOT NULL COMMENT 'Stop selling expied item n days before expiry',
  `enable_tooltip` tinyint(1) NOT NULL DEFAULT 1,
  `purchase_in_diff_currency` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Allow purchase to be in different currency then the business currency',
  `purchase_currency_id` int(10) unsigned DEFAULT NULL,
  `p_exchange_rate` decimal(20,3) NOT NULL DEFAULT 1.000,
  `transaction_edit_days` int(10) unsigned NOT NULL DEFAULT 30,
  `stock_expiry_alert_days` int(10) unsigned NOT NULL DEFAULT 30,
  `keyboard_shortcuts` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pos_settings` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `weighing_scale_setting` text COLLATE utf8mb4_unicode_ci NOT NULL COMMENT 'used to store the configuration of weighing scale',
  `essentials_settings` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enable_brand` tinyint(1) NOT NULL DEFAULT 1,
  `enable_category` tinyint(1) NOT NULL DEFAULT 1,
  `enable_sub_category` tinyint(1) NOT NULL DEFAULT 1,
  `enable_price_tax` tinyint(1) NOT NULL DEFAULT 1,
  `enable_purchase_status` tinyint(1) DEFAULT 1,
  `enable_lot_number` tinyint(1) NOT NULL DEFAULT 0,
  `default_unit` int(11) DEFAULT NULL,
  `enable_sub_units` tinyint(1) NOT NULL DEFAULT 0,
  `enable_racks` tinyint(1) NOT NULL DEFAULT 0,
  `enable_row` tinyint(1) NOT NULL DEFAULT 0,
  `enable_position` tinyint(1) NOT NULL DEFAULT 0,
  `enable_editing_product_from_purchase` tinyint(1) NOT NULL DEFAULT 1,
  `sales_cmsn_agnt` enum('logged_in_user','user','cmsn_agnt') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `item_addition_method` tinyint(1) NOT NULL DEFAULT 1,
  `enable_inline_tax` tinyint(1) NOT NULL DEFAULT 1,
  `currency_symbol_placement` enum('before','after') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'before',
  `enabled_modules` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_format` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'm/d/Y',
  `time_format` enum('12','24') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '24',
  `ref_no_prefixes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `theme_color` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `enable_rp` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'rp is the short form of reward points',
  `rp_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'rp is the short form of reward points',
  `amount_for_unit_rp` decimal(22,4) NOT NULL DEFAULT 1.0000 COMMENT 'rp is the short form of reward points',
  `min_order_total_for_rp` decimal(22,4) NOT NULL DEFAULT 1.0000 COMMENT 'rp is the short form of reward points',
  `max_rp_per_order` int(11) DEFAULT NULL COMMENT 'rp is the short form of reward points',
  `redeem_amount_per_unit_rp` decimal(22,4) NOT NULL DEFAULT 1.0000 COMMENT 'rp is the short form of reward points',
  `min_order_total_for_redeem` decimal(22,4) NOT NULL DEFAULT 1.0000 COMMENT 'rp is the short form of reward points',
  `min_redeem_point` int(11) DEFAULT NULL COMMENT 'rp is the short form of reward points',
  `max_redeem_point` int(11) DEFAULT NULL COMMENT 'rp is the short form of reward points',
  `rp_expiry_period` int(11) DEFAULT NULL COMMENT 'rp is the short form of reward points',
  `rp_expiry_type` enum('month','year') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'year' COMMENT 'rp is the short form of reward points',
  `email_settings` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sms_settings` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_labels` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `common_settings` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `business_owner_id_foreign` (`owner_id`),
  KEY `business_currency_id_foreign` (`currency_id`),
  KEY `business_default_sales_tax_foreign` (`default_sales_tax`),
  CONSTRAINT `business_currency_id_foreign` FOREIGN KEY (`currency_id`) REFERENCES `currencies` (`id`),
  CONSTRAINT `business_default_sales_tax_foreign` FOREIGN KEY (`default_sales_tax`) REFERENCES `tax_rates` (`id`),
  CONSTRAINT `business_owner_id_foreign` FOREIGN KEY (`owner_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `business` WRITE;
/*!40000 ALTER TABLE `business` DISABLE KEYS */;
INSERT INTO `business` VALUES (1,'Shah Clinical Laboratory',91,'2020-07-04',NULL,NULL,NULL,NULL,NULL,0.00,1,'Asia/Karachi',1,'fifo',0.00,'includes',NULL,NULL,1,'add_expiry','keep_selling',0,1,0,NULL,1.000,30,30,'{\"pos\":{\"express_checkout\":\"shift+e\",\"pay_n_ckeckout\":\"shift+p\",\"draft\":\"shift+d\",\"cancel\":\"shift+c\",\"recent_product_quantity\":\"f2\",\"weighing_scale\":null,\"edit_discount\":\"shift+i\",\"edit_order_tax\":\"shift+t\",\"add_payment_row\":\"shift+r\",\"finalize_payment\":\"shift+f\",\"add_new_product\":\"f4\"}}','{\"amount_rounding_method\":null,\"allow_overselling\":\"1\",\"disable_pay_checkout\":0,\"disable_draft\":0,\"disable_express_checkout\":0,\"hide_product_suggestion\":0,\"hide_recent_trans\":0,\"disable_discount\":0,\"disable_order_tax\":0,\"is_pos_subtotal_editable\":0}','{\"label_prefix\":null,\"product_sku_length\":\"4\",\"qty_length\":\"3\",\"qty_length_decimal\":\"2\"}',NULL,1,1,1,1,1,1,NULL,1,0,0,0,1,NULL,1,0,'before','[\"purchases\",\"add_sale\",\"pos_sale\",\"stock_transfers\",\"stock_adjustment\",\"expenses\",\"account\"]','d-m-Y','12','{\"purchase\":\"PO\",\"purchase_return\":null,\"stock_transfer\":\"ST\",\"stock_adjustment\":\"SA\",\"sell_return\":\"CN\",\"expense\":\"EP\",\"contacts\":\"CO\",\"purchase_payment\":\"PP\",\"sell_payment\":\"SP\",\"expense_payment\":null,\"business_location\":\"BL\",\"username\":null,\"subscription\":null}',NULL,NULL,0,NULL,1.0000,1.0000,NULL,1.0000,1.0000,NULL,NULL,NULL,'year','{\"mail_driver\":\"smtp\",\"mail_host\":null,\"mail_port\":null,\"mail_username\":null,\"mail_password\":null,\"mail_encryption\":null,\"mail_from_address\":null,\"mail_from_name\":null}','{\"url\":null,\"send_to_param_name\":\"to\",\"msg_param_name\":\"text\",\"request_method\":\"post\",\"param_1\":null,\"param_val_1\":null,\"param_2\":null,\"param_val_2\":null,\"param_3\":null,\"param_val_3\":null,\"param_4\":null,\"param_val_4\":null,\"param_5\":null,\"param_val_5\":null,\"param_6\":null,\"param_val_6\":null,\"param_7\":null,\"param_val_7\":null,\"param_8\":null,\"param_val_8\":null,\"param_9\":null,\"param_val_9\":null,\"param_10\":null,\"param_val_10\":null}','{\"payments\":{\"custom_pay_1\":null,\"custom_pay_2\":null,\"custom_pay_3\":null},\"contact\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"product\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"location\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"user\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"purchase\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"sell\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null},\"types_of_service\":{\"custom_field_1\":null,\"custom_field_2\":null,\"custom_field_3\":null,\"custom_field_4\":null}}','{\"default_datatable_page_entries\":\"25\"}',1,'2020-07-04 12:23:41','2020-07-04 12:25:05');
/*!40000 ALTER TABLE `business` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `business_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `business_locations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `location_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(256) COLLATE utf8mb4_unicode_ci NOT NULL,
  `landmark` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `state` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `city` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `zip_code` char(7) COLLATE utf8mb4_unicode_ci NOT NULL,
  `invoice_scheme_id` int(10) unsigned NOT NULL,
  `invoice_layout_id` int(10) unsigned NOT NULL,
  `selling_price_group_id` int(11) DEFAULT NULL,
  `print_receipt_on_invoice` tinyint(1) DEFAULT 1,
  `receipt_printer_type` enum('browser','printer') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'browser',
  `printer_id` int(11) DEFAULT NULL,
  `mobile` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alternate_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `website` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `featured_products` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `default_payment_accounts` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `business_locations_business_id_index` (`business_id`),
  KEY `business_locations_invoice_scheme_id_foreign` (`invoice_scheme_id`),
  KEY `business_locations_invoice_layout_id_foreign` (`invoice_layout_id`),
  CONSTRAINT `business_locations_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `business_locations_invoice_layout_id_foreign` FOREIGN KEY (`invoice_layout_id`) REFERENCES `invoice_layouts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `business_locations_invoice_scheme_id_foreign` FOREIGN KEY (`invoice_scheme_id`) REFERENCES `invoice_schemes` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `business_locations` WRITE;
/*!40000 ALTER TABLE `business_locations` DISABLE KEYS */;
INSERT INTO `business_locations` VALUES (1,1,'BL0001','Shah Clinical Laboratory','0946','Pakistan','KPK','Khawaza Khela','0946',1,1,NULL,1,'browser',NULL,'03339775572','0946745550','','',NULL,1,'{\"cash\":{\"is_enabled\":1,\"account\":null},\"card\":{\"is_enabled\":1,\"account\":null},\"cheque\":{\"is_enabled\":1,\"account\":null},\"bank_transfer\":{\"is_enabled\":1,\"account\":null},\"other\":{\"is_enabled\":1,\"account\":null},\"custom_pay_1\":{\"is_enabled\":1,\"account\":null},\"custom_pay_2\":{\"is_enabled\":1,\"account\":null},\"custom_pay_3\":{\"is_enabled\":1,\"account\":null}}',NULL,NULL,NULL,NULL,NULL,'2020-07-04 12:23:42','2020-07-04 12:23:42'),(2,1,'BL0002','Shah Clinical Laboratory',NULL,'Pakistan','kpk','Khwaza Khela','0946',1,1,NULL,1,'browser',NULL,'03339775572','0946745550',NULL,NULL,NULL,1,'{\"cash\":{\"is_enabled\":\"1\"},\"card\":{\"is_enabled\":\"1\"},\"cheque\":{\"is_enabled\":\"1\"},\"bank_transfer\":{\"is_enabled\":\"1\"},\"other\":{\"is_enabled\":\"1\"},\"custom_pay_1\":{\"is_enabled\":\"1\"},\"custom_pay_2\":{\"is_enabled\":\"1\"},\"custom_pay_3\":{\"is_enabled\":\"1\"}}',NULL,NULL,NULL,NULL,NULL,'2020-07-04 12:02:17','2020-07-04 12:02:17');
/*!40000 ALTER TABLE `business_locations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cash_register_transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cash_register_transactions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `cash_register_id` int(10) unsigned NOT NULL,
  `amount` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `pay_method` enum('cash','card','cheque','bank_transfer','custom_pay_1','custom_pay_2','custom_pay_3','other') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` enum('debit','credit') COLLATE utf8mb4_unicode_ci NOT NULL,
  `transaction_type` enum('initial','sell','transfer','refund') COLLATE utf8mb4_unicode_ci NOT NULL,
  `transaction_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cash_register_transactions_cash_register_id_foreign` (`cash_register_id`),
  KEY `cash_register_transactions_transaction_id_index` (`transaction_id`),
  CONSTRAINT `cash_register_transactions_cash_register_id_foreign` FOREIGN KEY (`cash_register_id`) REFERENCES `cash_registers` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=31 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cash_register_transactions` WRITE;
/*!40000 ALTER TABLE `cash_register_transactions` DISABLE KEYS */;
INSERT INTO `cash_register_transactions` VALUES (1,1,0.0000,'cash','credit','initial',NULL,'2020-07-04 13:18:22','2020-07-04 13:18:22'),(2,1,300.0000,'cash','credit','',1,'2020-07-04 13:19:21','2020-07-04 13:19:21'),(3,1,0.0000,'cash','credit','',1,'2020-07-04 13:19:21','2020-07-04 13:19:21'),(4,1,150.0000,'cash','credit','',2,'2020-07-04 14:05:51','2020-07-04 14:05:51'),(5,1,0.0000,'cash','credit','',2,'2020-07-04 14:05:51','2020-07-04 14:05:51'),(6,1,300.0000,'cash','credit','',3,'2020-07-07 16:26:34','2020-07-07 16:26:34'),(7,1,0.0000,'cash','credit','',3,'2020-07-07 16:26:34','2020-07-07 16:26:34'),(8,1,100.0000,'cash','credit','',4,'2020-07-07 16:41:21','2020-07-07 16:41:21'),(9,1,0.0000,'cash','credit','',4,'2020-07-07 16:41:21','2020-07-07 16:41:21'),(10,1,300.0000,'cash','credit','',5,'2020-07-07 18:15:53','2020-07-07 18:15:53'),(11,1,0.0000,'cash','credit','',5,'2020-07-07 18:15:53','2020-07-07 18:15:53'),(14,1,2.0000,'cash','credit','',7,'2020-07-08 16:25:20','2020-07-08 16:25:20'),(15,1,0.0000,'cash','credit','',7,'2020-07-08 16:25:20','2020-07-08 16:25:20'),(16,1,300.0000,'cash','credit','',8,'2020-07-09 14:10:09','2020-07-09 14:10:09'),(17,1,0.0000,'cash','credit','',8,'2020-07-09 14:10:09','2020-07-09 14:10:09'),(18,1,300.0000,'cash','credit','',10,'2020-07-09 23:02:43','2020-07-09 23:02:43'),(19,1,0.0000,'cash','credit','',10,'2020-07-09 23:02:43','2020-07-09 23:02:43'),(20,2,0.0000,'cash','credit','initial',NULL,'2020-07-10 17:02:07','2020-07-10 17:02:07'),(21,2,100.0000,'cash','credit','',11,'2020-07-10 17:02:50','2020-07-10 17:02:50'),(22,2,0.0000,'cash','credit','',11,'2020-07-10 17:02:50','2020-07-10 17:02:50'),(23,2,2.0000,'cash','credit','',13,'2020-07-10 19:41:12','2020-07-10 19:41:12'),(24,2,0.0000,'cash','credit','',13,'2020-07-10 19:41:12','2020-07-10 19:41:12'),(25,2,600.0000,'cash','credit','',14,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(26,2,0.0000,'cash','credit','',14,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(27,2,300.0000,'cash','credit','',15,'2020-07-10 19:57:41','2020-07-10 19:57:41'),(28,2,0.0000,'cash','credit','',15,'2020-07-10 19:57:41','2020-07-10 19:57:41'),(29,2,400.0000,'cash','credit','',16,'2020-07-10 20:24:53','2020-07-10 20:24:53'),(30,2,0.0000,'cash','credit','',16,'2020-07-10 20:24:53','2020-07-10 20:24:53');
/*!40000 ALTER TABLE `cash_register_transactions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `cash_registers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `cash_registers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `location_id` int(11) DEFAULT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `status` enum('close','open') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'open',
  `closed_at` datetime DEFAULT NULL,
  `closing_amount` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `total_card_slips` int(11) NOT NULL DEFAULT 0,
  `total_cheques` int(11) NOT NULL DEFAULT 0,
  `closing_note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `cash_registers_business_id_foreign` (`business_id`),
  KEY `cash_registers_user_id_foreign` (`user_id`),
  KEY `cash_registers_location_id_index` (`location_id`),
  CONSTRAINT `cash_registers_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `cash_registers_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `cash_registers` WRITE;
/*!40000 ALTER TABLE `cash_registers` DISABLE KEYS */;
INSERT INTO `cash_registers` VALUES (1,1,2,1,'close','2020-07-09 18:05:04',0.0000,0,0,NULL,'2020-07-04 13:18:22','2020-07-09 23:05:04'),(2,1,2,1,'open',NULL,0.0000,0,0,NULL,'2020-07-10 17:02:07','2020-07-10 17:02:07');
/*!40000 ALTER TABLE `cash_registers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `business_id` int(10) unsigned NOT NULL,
  `short_code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_id` int(11) NOT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `category_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `slug` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `categories_business_id_foreign` (`business_id`),
  KEY `categories_created_by_foreign` (`created_by`),
  CONSTRAINT `categories_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `categories_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categories` WRITE;
/*!40000 ALTER TABLE `categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `categorizables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `categorizables` (
  `category_id` int(11) NOT NULL,
  `categorizable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `categorizable_id` bigint(20) unsigned NOT NULL,
  KEY `categorizables_categorizable_type_categorizable_id_index` (`categorizable_type`,`categorizable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `categorizables` WRITE;
/*!40000 ALTER TABLE `categorizables` DISABLE KEYS */;
/*!40000 ALTER TABLE `categorizables` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `contacts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `contacts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `supplier_business_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `gender` enum('Male','Female','Other') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `birth_date` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `age` int(11) DEFAULT NULL,
  `blood_group` enum('A+','A-','B+','AB+','AB-','B-','O+','O-') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `marital_status` enum('single','married','other') COLLATE utf8mb4_unicode_ci NOT NULL,
  `ref_by` int(10) unsigned DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `tax_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `city` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `state` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `country` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `landmark` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `mobile` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `landline` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `alternate_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pay_term_number` int(11) DEFAULT NULL,
  `pay_term_type` enum('days','months') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `credit_limit` decimal(22,4) DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `total_rp` int(11) NOT NULL DEFAULT 0 COMMENT 'rp is the short form of reward points',
  `total_rp_used` int(11) NOT NULL DEFAULT 0 COMMENT 'rp is the short form of reward points',
  `total_rp_expired` int(11) NOT NULL DEFAULT 0 COMMENT 'rp is the short form of reward points',
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `shipping_address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `customer_group_id` int(11) DEFAULT NULL,
  `custom_field1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `contacts_business_id_foreign` (`business_id`),
  KEY `contacts_created_by_foreign` (`created_by`),
  KEY `contacts_type_index` (`type`),
  KEY `contacts_contact_status_index` (`contact_status`),
  KEY `contacts_ref_by_foreign` (`ref_by`),
  CONSTRAINT `contacts_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `contacts_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `contacts_ref_by_foreign` FOREIGN KEY (`ref_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `contacts` WRITE;
/*!40000 ALTER TABLE `contacts` DISABLE KEYS */;
INSERT INTO `contacts` VALUES (1,1,'customer',NULL,'Walk-In Customer',NULL,'CO0001',NULL,NULL,NULL,NULL,'single',NULL,NULL,'active',NULL,NULL,NULL,NULL,NULL,'',NULL,NULL,NULL,NULL,NULL,1,0,0,0,1,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-04 12:23:41','2020-07-04 12:23:41'),(2,1,'customer',NULL,'reHAIB',NULL,'CO0002','Female',NULL,0,NULL,'single',16,NULL,'active',NULL,'Khwaza Khela',NULL,NULL,NULL,'NIL',NULL,NULL,NULL,NULL,NULL,1,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-07 18:15:38','2020-07-07 18:15:38'),(3,1,'customer',NULL,'salman',NULL,'CO0003','Male',NULL,NULL,NULL,'single',4,NULL,'active',NULL,'kk',NULL,NULL,NULL,'nil',NULL,NULL,NULL,NULL,NULL,1,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-10 19:46:14','2020-07-10 19:46:14'),(4,1,'customer',NULL,'Israr',NULL,'CO0004','Male',NULL,21,NULL,'single',4,NULL,'active',NULL,'Khwaza Khela',NULL,NULL,NULL,'nil',NULL,NULL,NULL,NULL,NULL,1,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-10 19:57:33','2020-07-10 19:57:33'),(5,1,'customer',NULL,'azan',NULL,'03428927305','Male',NULL,20,NULL,'single',4,NULL,'active',NULL,'kk',NULL,NULL,NULL,'03428927305',NULL,NULL,NULL,NULL,NULL,1,0,0,0,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-10 20:24:29','2020-07-10 20:24:29');
/*!40000 ALTER TABLE `contacts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `currencies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `currencies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `country` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `currency` varchar(100) COLLATE utf8mb4_unicode_ci NOT NULL,
  `code` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `symbol` varchar(25) COLLATE utf8mb4_unicode_ci NOT NULL,
  `thousand_separator` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `decimal_separator` varchar(10) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=141 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `currencies` WRITE;
/*!40000 ALTER TABLE `currencies` DISABLE KEYS */;
INSERT INTO `currencies` VALUES (1,'Albania','Leke','ALL','Lek',',','.',NULL,NULL),(2,'America','Dollars','USD','$',',','.',NULL,NULL),(3,'Afghanistan','Afghanis','AF','؋',',','.',NULL,NULL),(4,'Argentina','Pesos','ARS','$',',','.',NULL,NULL),(5,'Aruba','Guilders','AWG','ƒ',',','.',NULL,NULL),(6,'Australia','Dollars','AUD','$',',','.',NULL,NULL),(7,'Azerbaijan','New Manats','AZ','ман',',','.',NULL,NULL),(8,'Bahamas','Dollars','BSD','$',',','.',NULL,NULL),(9,'Barbados','Dollars','BBD','$',',','.',NULL,NULL),(10,'Belarus','Rubles','BYR','p.',',','.',NULL,NULL),(11,'Belgium','Euro','EUR','€',',','.',NULL,NULL),(12,'Beliz','Dollars','BZD','BZ$',',','.',NULL,NULL),(13,'Bermuda','Dollars','BMD','$',',','.',NULL,NULL),(14,'Bolivia','Bolivianos','BOB','$b',',','.',NULL,NULL),(15,'Bosnia and Herzegovina','Convertible Marka','BAM','KM',',','.',NULL,NULL),(16,'Botswana','Pula\'s','BWP','P',',','.',NULL,NULL),(17,'Bulgaria','Leva','BG','лв',',','.',NULL,NULL),(18,'Brazil','Reais','BRL','R$',',','.',NULL,NULL),(19,'Britain [United Kingdom]','Pounds','GBP','£',',','.',NULL,NULL),(20,'Brunei Darussalam','Dollars','BND','$',',','.',NULL,NULL),(21,'Cambodia','Riels','KHR','៛',',','.',NULL,NULL),(22,'Canada','Dollars','CAD','$',',','.',NULL,NULL),(23,'Cayman Islands','Dollars','KYD','$',',','.',NULL,NULL),(24,'Chile','Pesos','CLP','$',',','.',NULL,NULL),(25,'China','Yuan Renminbi','CNY','¥',',','.',NULL,NULL),(26,'Colombia','Pesos','COP','$',',','.',NULL,NULL),(27,'Costa Rica','Colón','CRC','₡',',','.',NULL,NULL),(28,'Croatia','Kuna','HRK','kn',',','.',NULL,NULL),(29,'Cuba','Pesos','CUP','₱',',','.',NULL,NULL),(30,'Cyprus','Euro','EUR','€','.',',',NULL,NULL),(31,'Czech Republic','Koruny','CZK','Kč',',','.',NULL,NULL),(32,'Denmark','Kroner','DKK','kr',',','.',NULL,NULL),(33,'Dominican Republic','Pesos','DOP ','RD$',',','.',NULL,NULL),(34,'East Caribbean','Dollars','XCD','$',',','.',NULL,NULL),(35,'Egypt','Pounds','EGP','£',',','.',NULL,NULL),(36,'El Salvador','Colones','SVC','$',',','.',NULL,NULL),(37,'England [United Kingdom]','Pounds','GBP','£',',','.',NULL,NULL),(38,'Euro','Euro','EUR','€','.',',',NULL,NULL),(39,'Falkland Islands','Pounds','FKP','£',',','.',NULL,NULL),(40,'Fiji','Dollars','FJD','$',',','.',NULL,NULL),(41,'France','Euro','EUR','€','.',',',NULL,NULL),(42,'Ghana','Cedis','GHC','¢',',','.',NULL,NULL),(43,'Gibraltar','Pounds','GIP','£',',','.',NULL,NULL),(44,'Greece','Euro','EUR','€','.',',',NULL,NULL),(45,'Guatemala','Quetzales','GTQ','Q',',','.',NULL,NULL),(46,'Guernsey','Pounds','GGP','£',',','.',NULL,NULL),(47,'Guyana','Dollars','GYD','$',',','.',NULL,NULL),(48,'Holland [Netherlands]','Euro','EUR','€','.',',',NULL,NULL),(49,'Honduras','Lempiras','HNL','L',',','.',NULL,NULL),(50,'Hong Kong','Dollars','HKD','$',',','.',NULL,NULL),(51,'Hungary','Forint','HUF','Ft',',','.',NULL,NULL),(52,'Iceland','Kronur','ISK','kr',',','.',NULL,NULL),(53,'India','Rupees','INR','₹',',','.',NULL,NULL),(54,'Indonesia','Rupiahs','IDR','Rp',',','.',NULL,NULL),(55,'Iran','Rials','IRR','﷼',',','.',NULL,NULL),(56,'Ireland','Euro','EUR','€','.',',',NULL,NULL),(57,'Isle of Man','Pounds','IMP','£',',','.',NULL,NULL),(58,'Israel','New Shekels','ILS','₪',',','.',NULL,NULL),(59,'Italy','Euro','EUR','€','.',',',NULL,NULL),(60,'Jamaica','Dollars','JMD','J$',',','.',NULL,NULL),(61,'Japan','Yen','JPY','¥',',','.',NULL,NULL),(62,'Jersey','Pounds','JEP','£',',','.',NULL,NULL),(63,'Kazakhstan','Tenge','KZT','лв',',','.',NULL,NULL),(64,'Korea [North]','Won','KPW','₩',',','.',NULL,NULL),(65,'Korea [South]','Won','KRW','₩',',','.',NULL,NULL),(66,'Kyrgyzstan','Soms','KGS','лв',',','.',NULL,NULL),(67,'Laos','Kips','LAK','₭',',','.',NULL,NULL),(68,'Latvia','Lati','LVL','Ls',',','.',NULL,NULL),(69,'Lebanon','Pounds','LBP','£',',','.',NULL,NULL),(70,'Liberia','Dollars','LRD','$',',','.',NULL,NULL),(71,'Liechtenstein','Switzerland Francs','CHF','CHF',',','.',NULL,NULL),(72,'Lithuania','Litai','LTL','Lt',',','.',NULL,NULL),(73,'Luxembourg','Euro','EUR','€','.',',',NULL,NULL),(74,'Macedonia','Denars','MKD','ден',',','.',NULL,NULL),(75,'Malaysia','Ringgits','MYR','RM',',','.',NULL,NULL),(76,'Malta','Euro','EUR','€','.',',',NULL,NULL),(77,'Mauritius','Rupees','MUR','₨',',','.',NULL,NULL),(78,'Mexico','Pesos','MXN','$',',','.',NULL,NULL),(79,'Mongolia','Tugriks','MNT','₮',',','.',NULL,NULL),(80,'Mozambique','Meticais','MZ','MT',',','.',NULL,NULL),(81,'Namibia','Dollars','NAD','$',',','.',NULL,NULL),(82,'Nepal','Rupees','NPR','₨',',','.',NULL,NULL),(83,'Netherlands Antilles','Guilders','ANG','ƒ',',','.',NULL,NULL),(84,'Netherlands','Euro','EUR','€','.',',',NULL,NULL),(85,'New Zealand','Dollars','NZD','$',',','.',NULL,NULL),(86,'Nicaragua','Cordobas','NIO','C$',',','.',NULL,NULL),(87,'Nigeria','Nairas','NG','₦',',','.',NULL,NULL),(88,'North Korea','Won','KPW','₩',',','.',NULL,NULL),(89,'Norway','Krone','NOK','kr',',','.',NULL,NULL),(90,'Oman','Rials','OMR','﷼',',','.',NULL,NULL),(91,'Pakistan','Rupees','PKR','₨',',','.',NULL,NULL),(92,'Panama','Balboa','PAB','B/.',',','.',NULL,NULL),(93,'Paraguay','Guarani','PYG','Gs',',','.',NULL,NULL),(94,'Peru','Nuevos Soles','PE','S/.',',','.',NULL,NULL),(95,'Philippines','Pesos','PHP','Php',',','.',NULL,NULL),(96,'Poland','Zlotych','PL','zł',',','.',NULL,NULL),(97,'Qatar','Rials','QAR','﷼',',','.',NULL,NULL),(98,'Romania','New Lei','RO','lei',',','.',NULL,NULL),(99,'Russia','Rubles','RUB','руб',',','.',NULL,NULL),(100,'Saint Helena','Pounds','SHP','£',',','.',NULL,NULL),(101,'Saudi Arabia','Riyals','SAR','﷼',',','.',NULL,NULL),(102,'Serbia','Dinars','RSD','Дин.',',','.',NULL,NULL),(103,'Seychelles','Rupees','SCR','₨',',','.',NULL,NULL),(104,'Singapore','Dollars','SGD','$',',','.',NULL,NULL),(105,'Slovenia','Euro','EUR','€','.',',',NULL,NULL),(106,'Solomon Islands','Dollars','SBD','$',',','.',NULL,NULL),(107,'Somalia','Shillings','SOS','S',',','.',NULL,NULL),(108,'South Africa','Rand','ZAR','R',',','.',NULL,NULL),(109,'South Korea','Won','KRW','₩',',','.',NULL,NULL),(110,'Spain','Euro','EUR','€','.',',',NULL,NULL),(111,'Sri Lanka','Rupees','LKR','₨',',','.',NULL,NULL),(112,'Sweden','Kronor','SEK','kr',',','.',NULL,NULL),(113,'Switzerland','Francs','CHF','CHF',',','.',NULL,NULL),(114,'Suriname','Dollars','SRD','$',',','.',NULL,NULL),(115,'Syria','Pounds','SYP','£',',','.',NULL,NULL),(116,'Taiwan','New Dollars','TWD','NT$',',','.',NULL,NULL),(117,'Thailand','Baht','THB','฿',',','.',NULL,NULL),(118,'Trinidad and Tobago','Dollars','TTD','TT$',',','.',NULL,NULL),(119,'Turkey','Lira','TRY','TL',',','.',NULL,NULL),(120,'Turkey','Liras','TRL','£',',','.',NULL,NULL),(121,'Tuvalu','Dollars','TVD','$',',','.',NULL,NULL),(122,'Ukraine','Hryvnia','UAH','₴',',','.',NULL,NULL),(123,'United Kingdom','Pounds','GBP','£',',','.',NULL,NULL),(124,'United States of America','Dollars','USD','$',',','.',NULL,NULL),(125,'Uruguay','Pesos','UYU','$U',',','.',NULL,NULL),(126,'Uzbekistan','Sums','UZS','лв',',','.',NULL,NULL),(127,'Vatican City','Euro','EUR','€','.',',',NULL,NULL),(128,'Venezuela','Bolivares Fuertes','VEF','Bs',',','.',NULL,NULL),(129,'Vietnam','Dong','VND','₫',',','.',NULL,NULL),(130,'Yemen','Rials','YER','﷼',',','.',NULL,NULL),(131,'Zimbabwe','Zimbabwe Dollars','ZWD','Z$',',','.',NULL,NULL),(132,'Iraq','Iraqi dinar','IQD','د.ع',',','.',NULL,NULL),(133,'Kenya','Kenyan shilling','KES','KSh',',','.',NULL,NULL),(134,'Bangladesh','Taka','BDT','৳',',','.',NULL,NULL),(135,'Algerie','Algerian dinar','DZD','د.ج',' ','.',NULL,NULL),(136,'United Arab Emirates','United Arab Emirates dirham','AED','د.إ',',','.',NULL,NULL),(137,'Uganda','Uganda shillings','UGX','USh',',','.',NULL,NULL),(138,'Tanzania','Tanzanian shilling','TZS','TSh',',','.',NULL,NULL),(139,'Angola','Kwanza','AOA','Kz',',','.',NULL,NULL),(140,'Kuwait','Kuwaiti dinar','KWD','KD',',','.',NULL,NULL);
/*!40000 ALTER TABLE `currencies` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `customer_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `customer_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` double(5,2) NOT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `customer_groups_business_id_foreign` (`business_id`),
  CONSTRAINT `customer_groups_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `customer_groups` WRITE;
/*!40000 ALTER TABLE `customer_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `customer_groups` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `dashboard_configurations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `dashboard_configurations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `created_by` int(11) NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `color` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `configuration` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `dashboard_configurations_business_id_foreign` (`business_id`),
  CONSTRAINT `dashboard_configurations_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `dashboard_configurations` WRITE;
/*!40000 ALTER TABLE `dashboard_configurations` DISABLE KEYS */;
/*!40000 ALTER TABLE `dashboard_configurations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `departments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `business_id` int(10) unsigned NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `departments_business_id_foreign` (`business_id`),
  KEY `departments_created_by_foreign` (`created_by`),
  CONSTRAINT `departments_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `departments_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=548 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
INSERT INTO `departments` VALUES (1,'Hematology REPORT',1,'Hematology Department',1,NULL,'2020-07-04 12:10:47','2020-07-04 13:53:09'),(2,'Urine Complete Examination',1,'Urine Complete Examination',1,NULL,'2020-07-06 06:25:37','2020-07-06 06:25:37'),(3,'Bio Chemistry  Department',1,'Bio Chemistry  Department',1,NULL,'2020-07-06 06:34:13','2020-07-06 06:34:13'),(4,'Serology Department',1,'Serology Department',1,NULL,'2020-07-06 06:41:04','2020-07-06 06:41:04'),(5,'17-Ketogenic Steroids',1,'17-Ketogenic Steroids',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(6,'17-Ketosteroids (24 Hrs Urine)',1,'17-Ketosteroids (24 Hrs Urine)',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(7,'17-OH Progesterone',1,'17-OH Progesterone',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(8,'25-OH Vitamin-D',1,'25-OH Vitamin-D',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(9,'5 - H.I.A.A. Report',1,'5 - H.I.A.A. Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(10,'LIVER FUNCTIONS REPORT',1,'LIVER FUNCTIONS REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(11,'Absolute Eosinophil Count Report',1,'Absolute Eosinophil Count Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(12,'Absolute Values/Cell Counts',1,'Absolute Values/Cell Counts',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(13,'SPECIAL CHEMISTRY REPORT',1,'SPECIAL CHEMISTRY REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(15,'ENDOCRINOLOGY REPORT',1,'ENDOCRINOLOGY REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(16,'SEROLOGY REPORT',1,'SEROLOGY REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(18,'Alcohol Level Report',1,'Alcohol Level Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(22,'CARDIAC ENZYMES REPORT',1,'CARDIAC ENZYMES REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(23,'TUMOUR MARKERS REPORT',1,'TUMOUR MARKERS REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(25,'Aminophylline / Theophylline',1,'Aminophylline / Theophylline',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(26,'SERUM ELECTROLYTES REPORT',1,'SERUM ELECTROLYTES REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(30,'A.N.A. By Elisa',1,'A.N.A. By Elisa',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(31,'A.N.C.A - C',1,'A.N.C.A - C',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(32,'A.N.C.A.',1,'A.N.C.A.',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(33,'Androgen Level',1,'Androgen Level',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(34,'Androstenidione Level',1,'Androstenidione Level',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(35,'Anti Cardiolipin lgG',1,'Anti Cardiolipin lgG',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(36,'Anti Cardiolipin lgM',1,'Anti Cardiolipin lgM',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(37,'Anti Centromer Abs',1,'Anti Centromer Abs',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(38,'Anti Cytoplasmic Antibodies',1,'Anti Cytoplasmic Antibodies',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(40,'Anti Endomysial Abs',1,'Anti Endomysial Abs',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(41,'Anti G.B.M.',1,'Anti G.B.M.',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(42,'Anti Gliadin lgA',1,'Anti Gliadin lgA',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(43,'Anti Gliadin lgG',1,'Anti Gliadin lgG',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(44,'Anti Gliadin lgM',1,'Anti Gliadin lgM',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(45,'HEPATITIS VIROLOGICAL REPORT',1,'HEPATITIS VIROLOGICAL REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(51,'SCREENING REPORT',1,'SCREENING REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(58,'Anti HIV - 1 & 2',1,'Anti HIV - 1 & 2',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(62,'Anti JO-1',1,'Anti JO-1',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(63,'Anti L.K.M',1,'Anti L.K.M',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(64,'Anti Microsomal Abs',1,'Anti Microsomal Abs',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(65,'Anti Mitochondrial Antibody',1,'Anti Mitochondrial Antibody',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(66,'Anti Phospholipid lgG',1,'Anti Phospholipid lgG',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(67,'Anti Phospholipid lgM',1,'Anti Phospholipid lgM',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(68,'Anti SCL-70',1,'Anti SCL-70',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(69,'Anti Smooth Muscle Abs',1,'Anti Smooth Muscle Abs',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(70,'SPECIAL REPORT',1,'SPECIAL REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(71,'Anti Thrombin-III',1,'Anti Thrombin-III',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(72,'Anti Thyroglobulin Antibodies',1,'Anti Thyroglobulin Antibodies',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(73,'HAEMATOLOGY REPORT',1,'HAEMATOLOGY REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(74,'Arterial Blood Gases (ABG\'s)',1,'Arterial Blood Gases (ABG\'s)',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(75,'Ascitic Fluid For AFB Culture',1,'Ascitic Fluid For AFB Culture',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(76,'Ascitic Fluid For AFB Smear / Z.N.',1,'Ascitic Fluid For AFB Smear / Z.N.',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(77,'Ascitic Fluid For Amylase',1,'Ascitic Fluid For Amylase',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(78,'Ascitic Fluid Analysis (C/E) Report',1,'Ascitic Fluid Analysis (C/E) Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(79,'Ascitic Fluid For C / S',1,'Ascitic Fluid For C / S',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(80,'Ascitic Fluid For Cytology',1,'Ascitic Fluid For Cytology',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(81,'Ascitic Fluid For Gram Stain',1,'Ascitic Fluid For Gram Stain',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(82,'Ascitic Fluid For L.D.H.',1,'Ascitic Fluid For L.D.H.',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(83,'Ascitic Fluid For MTB By PCR',1,'Ascitic Fluid For MTB By PCR',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(85,'Asperrgillus Abs',1,'Asperrgillus Abs',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(87,'Atypical Lymphocytes',1,'Atypical Lymphocytes',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(88,'B-2 Micro Globulin',1,'B-2 Micro Globulin',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(89,'Bence Jones Protein (Urine)',1,'Bence Jones Protein (Urine)',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(92,'BIL SGPT SGOT ALK PROT ALB',1,'BIL SGPT SGOT ALK PROT ALB',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(97,'Biopsy For H/P',1,'Biopsy For H/P',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(99,'Blood C/E Retic Count',1,'Blood C/E Retic Count',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(101,'Blood Culture For Aerobic',1,'Blood Culture For Aerobic',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(102,'Blood Culture For Anaerobic',1,'Blood Culture For Anaerobic',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(103,'Blood Film For Filariasis',1,'Blood Film For Filariasis',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(104,'Blood For C/S',1,'Blood For C/S',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(105,'BLOOD GROUP & CROSS MATCHING REPORT',1,'BLOOD GROUP & CROSS MATCHING REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(106,'BLOOD GROUP REPORT',1,'BLOOD GROUP REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(107,'RENAL FUNCTION REPORT',1,'RENAL FUNCTION REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(108,'Bone Marrow Biopsy Report',1,'Bone Marrow Biopsy Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(110,'MILK ANALYSIS REPORT',1,'MILK ANALYSIS REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(111,'Bronchial Washing AFB Culture',1,'Bronchial Washing AFB Culture',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(112,'Bronchial Washing C/S',1,'Bronchial Washing C/S',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(113,'Bronchial Washing ',1,'Bronchial Washing ',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(114,'Bronchial Washing For Gram',1,'Bronchial Washing For Gram',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(115,'Bronchial Washing For ZN',1,'Bronchial Washing For ZN',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(116,'Bronchial Washing MTB By PCR',1,'Bronchial Washing MTB By PCR',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(117,'Brucella Test',1,'Brucella Test',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(118,'Buceal Smear for Bar Bodies',1,'Buceal Smear for Bar Bodies',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(119,'BLOOD/RENAL FUNCTION REPORT',1,'BLOOD/RENAL FUNCTION REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(120,'C-2 Monitring',1,'C-2 Monitring',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(121,'SPECIAL BIO-CHEMISTRY REPORT',1,'SPECIAL BIO-CHEMISTRY REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(127,'Calcitonin',1,'Calcitonin',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(129,'Calcium (Urine) Report',1,'Calcium (Urine) Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(130,'Calcium Ionized Report',1,'Calcium Ionized Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(131,'Calcium/Creatinine Ratio',1,'Calcium/Creatinine Ratio',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(132,'Calculi Analysis (Stone)',1,'Calculi Analysis (Stone)',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(133,'Calculi Analysis (Urine)',1,'Calculi Analysis (Urine)',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(134,'Candida Albicans Abs',1,'Candida Albicans Abs',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(135,'DRUGS REPORT',1,'DRUGS REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(137,'Catecholamines (24 Hrs)',1,'Catecholamines (24 Hrs)',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(139,'Ceruloplasmin',1,'Ceruloplasmin',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(140,'Chickenpox abs',1,'Chickenpox abs',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(144,'LIPID PROFILE REPORT',1,'LIPID PROFILE REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(148,'CYTO MAGALO VIRUS REPORT',1,'CYTO MAGALO VIRUS REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(150,'Cocaine',1,'Cocaine',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(151,'Cold Agglutination Test',1,'Cold Agglutination Test',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(152,'COOMB\'s TEST REPORT',1,'COOMB\'s TEST REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(155,'Copper (Urine) Report',1,'Copper (Urine) Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(156,'Coprophyrins',1,'Coprophyrins',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(165,'URINARY/RENAL FUNCTION REPORT',1,'URINARY/RENAL FUNCTION REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(167,'CROSS MATCHING REPORT',1,'CROSS MATCHING REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(168,'CROSS MATCHING WITH ELISA REPORT',1,'CROSS MATCHING WITH ELISA REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(169,'CROSS MATCHING WITH SCREENING REPORT',1,'CROSS MATCHING WITH SCREENING REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(170,'SPECIAL CHEMISTRY PROTEIN',1,'SPECIAL CHEMISTRY PROTEIN',1,'2020-07-07 17:24:34','0000-00-00 00:00:00','2020-07-07 17:24:34'),(171,'Cryoglobulin Level Report',1,'Cryoglobulin Level Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(172,'CSF For AFB Culture',1,'CSF For AFB Culture',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(173,'CEREBROSPINAL FLUID ANALYSIS REPORT',1,'CEREBROSPINAL FLUID ANALYSIS REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(174,'CSF for C/S Report',1,'CSF for C/S Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(175,'CSF For Cytology ',1,'CSF For Cytology ',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(176,'CSF For Gram Stain',1,'CSF For Gram Stain',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(177,'CSF For Lactate Level',1,'CSF For Lactate Level',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(178,'CSF For LDH',1,'CSF For LDH',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(179,'CSF For lgA',1,'CSF For lgA',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(180,'CSF For lgG',1,'CSF For lgG',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(181,'CSF For lgM',1,'CSF For lgM',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(182,'CSF For Measels lgG',1,'CSF For Measels lgG',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(183,'CSF For Measels lgM',1,'CSF For Measels lgM',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(184,'CSF For MTB By PCR',1,'CSF For MTB By PCR',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(185,'CSF For Mumps abs',1,'CSF For Mumps abs',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(186,'CSF For Oligloconal Bands',1,'CSF For Oligloconal Bands',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(187,'CSF For Z.N. Stain',1,'CSF For Z.N. Stain',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(188,'CVP TIP For C/S',1,'CVP TIP For C/S',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(189,'Cyclosporin Level Report',1,'Cyclosporin Level Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(190,'Cyst Fluid Analysis (C/E) Report',1,'Cyst Fluid Analysis (C/E) Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(191,'Cytology Report',1,'Cytology Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(198,'E.B.V. Abs',1,'E.B.V. Abs',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(199,'Ear Swab For AFB C/S Report',1,'Ear Swab For AFB C/S Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(200,'Ear Swab For AFB Staining Report',1,'Ear Swab For AFB Staining Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(201,'Ear Swab For C/S',1,'Ear Swab For C/S',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(202,'Ear Swab For Gram Staining',1,'Ear Swab For Gram Staining',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(203,'ENA Profile',1,'ENA Profile',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(208,'Estrogen Level, Progesterone Receptor',1,'Estrogen Level, Progesterone Receptor',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(210,'F.N.A.C. Report',1,'F.N.A.C. Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(211,'F.N.A.C. Slids Report',1,'F.N.A.C. Slids Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(213,'Factor IX Level Report',1,'Factor IX Level Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(214,'Factor VIII Level Report',1,'Factor VIII Level Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(216,'FFP\'s Report',1,'FFP\'s Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(217,'FFP\'s With X-Matching Report',1,'FFP\'s With X-Matching Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(219,'FLUID COMPLETE EXAMINATION',1,'FLUID COMPLETE EXAMINATION',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(220,'Fluid For C/S',1,'Fluid For C/S',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(222,'Free PSA',1,'Free PSA',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(223,'Free PSA/PSA Ratio Report',1,'Free PSA/PSA Ratio Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(226,'Free Testosterone Report',1,'Free Testosterone Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(227,'Free Thyroxin Index',1,'Free Thyroxin Index',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(228,'Frozen Section Report',1,'Frozen Section Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(230,'Fungus Culture Report',1,'Fungus Culture Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(231,'G-6 PD Test',1,'G-6 PD Test',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(232,'Gall Bladder Stone for Analysis',1,'Gall Bladder Stone for Analysis',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(234,'Gastrin Level',1,'Gastrin Level',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(235,'GCT (Glucose Challenge Test) Report',1,'GCT (Glucose Challenge Test) Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(236,'Gentamycin',1,'Gentamycin',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(240,'Gram Stain',1,'Gram Stain',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(241,'GLUCOSE TOLERANCE TESTS REPORT',1,'GLUCOSE TOLERANCE TESTS REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(242,'Haemagglutination Test for E.Granulosus Test',1,'Haemagglutination Test for E.Granulosus Test',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(243,'Haemagglutination Test For Echinococcus',1,'Haemagglutination Test For Echinococcus',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(244,'Haemagglutination Test for Entamoeba Histolytica',1,'Haemagglutination Test for Entamoeba Histolytica',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(245,'Haemagglutination Test for Hydatid Test',1,'Haemagglutination Test for Hydatid Test',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(246,'Haptoglobin Report',1,'Haptoglobin Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(250,'HB Electrophoresis',1,'HB Electrophoresis',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(255,'HBV DNA BY PCR (QL) REPORT',1,'HBV DNA BY PCR (QL) REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(256,'HBV DNA BY PCR (QN) REPORT',1,'HBV DNA BY PCR (QN) REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(258,'HCV GENOTYPING REPORT',1,'HCV GENOTYPING REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(259,'HCV RNA PCR (QL) REPORT',1,'HCV RNA PCR (QL) REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(260,'HCV RNA PCR (QN) REPORT',1,'HCV RNA PCR (QN) REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(261,'HCV SEROTYPING REPORT',1,'HCV SEROTYPING REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(264,'Helicobacter Pylori Abs Report',1,'Helicobacter Pylori Abs Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(266,'\"Hepatitis \"\"B\"\" Profile\"',1,'\"Hepatitis \"\"B\"\" Profile\"',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(268,'HER 2-NEU (Staining)',1,'HER 2-NEU (Staining)',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(269,'Herpes lgG',1,'Herpes lgG',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(270,'Herpes lgM',1,'Herpes lgM',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(271,'HIV (Aids) TEST REPORT',1,'HIV (Aids) TEST REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(273,'HLA Typing Report',1,'HLA Typing Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(275,'HVS For AFB Smear-ZN Stain',1,'HVS For AFB Smear-ZN Stain',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(276,'HVS For C / S Report',1,'HVS For C / S Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(277,'HVS For Gram Stain / Wet Smear',1,'HVS For Gram Stain / Wet Smear',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(279,'IMMUNOLOGY REPORT',1,'IMMUNOLOGY REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(283,'Immunofixation Electrophoresis',1,'Immunofixation Electrophoresis',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(284,'I.N.R. REPORT',1,'I.N.R. REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(286,'Insulin (After 1-Hr)',1,'Insulin (After 1-Hr)',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(287,'Insulin (After 2-Hrs)',1,'Insulin (After 2-Hrs)',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(288,'Insulin (After 3-Hrs)',1,'Insulin (After 3-Hrs)',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(289,'Insulin (After 4-Hrs)',1,'Insulin (After 4-Hrs)',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(290,'Insulin (After 5-Hrs)',1,'Insulin (After 5-Hrs)',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(291,'Insulin (Fasting)',1,'Insulin (Fasting)',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(292,'Intact Parathormone Report',1,'Intact Parathormone Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(294,'Joint Fluid For AFB Culture',1,'Joint Fluid For AFB Culture',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(295,'Joint Fluid For AFB Smear/ZN',1,'Joint Fluid For AFB Smear/ZN',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(296,'Joint Fluid For Analysis',1,'Joint Fluid For Analysis',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(297,'Joint Fluid For C/S Report',1,'Joint Fluid For C/S Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(298,'Joint Fluid For Cytology',1,'Joint Fluid For Cytology',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(299,'Joint Fluid For Gram Stain',1,'Joint Fluid For Gram Stain',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(300,'Joint Fluid For LDH',1,'Joint Fluid For LDH',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(301,'Joint Fluid For MTB by PCR',1,'Joint Fluid For MTB by PCR',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(302,'KIDNEY STONE ANALYSIS REPORT',1,'KIDNEY STONE ANALYSIS REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(303,'Lactate Level Report',1,'Lactate Level Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(304,'LAP Score Level',1,'LAP Score Level',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(307,'LE CELLS REPORT',1,'LE CELLS REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(308,'Lead Level',1,'Lead Level',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(309,'Leptospiral Abs',1,'Leptospiral Abs',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(315,'Lupus Anticoagulant abs',1,'Lupus Anticoagulant abs',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(318,'MANTOUX TEST REPORT',1,'MANTOUX TEST REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(323,'Measles lgG Abs',1,'Measles lgG Abs',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(324,'Measles lgM Abs',1,'Measles lgM Abs',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(325,'Metabolic Studies for Stone Report',1,'Metabolic Studies for Stone Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(326,'Met-Heamoglobin Report',1,'Met-Heamoglobin Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(327,'Microalbumin Urea Report',1,'Microalbumin Urea Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(328,'Milk For AFB C/S Report',1,'Milk For AFB C/S Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(329,'Milk For C/S Report',1,'Milk For C/S Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(330,'Milk For Cytology Report',1,'Milk For Cytology Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(331,'Milk For Gram Stain',1,'Milk For Gram Stain',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(332,'Milk For Z.N. Stain',1,'Milk For Z.N. Stain',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(335,'MTB By PCR (QL) REPORT',1,'MTB By PCR (QL) REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(336,'Mumps Antibodies Report',1,'Mumps Antibodies Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(342,'Mycoplasma Abs Report',1,'Mycoplasma Abs Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(343,'Myoglobin Report',1,'Myoglobin Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(344,'Nasal Screation C/S',1,'Nasal Screation C/S',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(345,'Osmolality (Serum)',1,'Osmolality (Serum)',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(346,'Osmolality Urine',1,'Osmolality Urine',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(347,'Osmotic Fagility',1,'Osmotic Fagility',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(348,'Pack Cell ',1,'Pack Cell ',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(349,'Pack Cell With X-Matching',1,'Pack Cell With X-Matching',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(350,'PAP Smear For Cytology Repor',1,'PAP Smear For Cytology Repor',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(352,'Peritoneal Fluid For AFB',1,'Peritoneal Fluid For AFB',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(353,'Peritoneal Fluid Analysis (C/E) Report',1,'Peritoneal Fluid Analysis (C/E) Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(354,'Peritoneal Fluid For C/S',1,'Peritoneal Fluid For C/S',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(355,'Peritoneal Fluid For Cytology',1,'Peritoneal Fluid For Cytology',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(356,'Peritoneal Fluid For Gram',1,'Peritoneal Fluid For Gram',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(357,'Peritoneal Fluid For LDH',1,'Peritoneal Fluid For LDH',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(358,'Peritoneal Fluid For MTB by PCR',1,'Peritoneal Fluid For MTB by PCR',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(359,'Peritoneal Fluid For NZ Stain',1,'Peritoneal Fluid For NZ Stain',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(363,'Plasma Renin Level',1,'Plasma Renin Level',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(365,'Pleural Fluid For AFB Culture',1,'Pleural Fluid For AFB Culture',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(366,'Pleural Fluid For AFB Smear',1,'Pleural Fluid For AFB Smear',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(367,'Pleural Fluid For Analysis',1,'Pleural Fluid For Analysis',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(368,'Pleural Fluid For C/S',1,'Pleural Fluid For C/S',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(369,'Pleural Fluid for Cytology',1,'Pleural Fluid for Cytology',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(370,'Pleural Fluid For Gram Stain',1,'Pleural Fluid For Gram Stain',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(371,'Pleural Fluid For LDH',1,'Pleural Fluid For LDH',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(372,'Pleural Fluid For MTB by PCR',1,'Pleural Fluid For MTB by PCR',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(373,'URINARY REPORT',1,'URINARY REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(376,'URINE REPORT.',1,'URINE REPORT.',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(377,'Pre-Natal Profile',1,'Pre-Natal Profile',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(380,'Protein Electrophoresis',1,'Protein Electrophoresis',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(381,'Protein-C',1,'Protein-C',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(382,'Protein-S ',1,'Protein-S ',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(383,'ICT TOXOPLASMA REPORT',1,'ICT TOXOPLASMA REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(386,'PUS For AFB Culture',1,'PUS For AFB Culture',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(387,'PUS For AFB Smear- Z.N. Stain',1,'PUS For AFB Smear- Z.N. Stain',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(388,'PUS For C / S',1,'PUS For C / S',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(389,'PUS For Cytology',1,'PUS For Cytology',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(390,'PUS For Gram Stain',1,'PUS For Gram Stain',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(391,'PUS for MTB by PCR',1,'PUS for MTB by PCR',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(393,'HAEMOTOLOGY REPORT',1,'HAEMOTOLOGY REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(397,'Red Cell Folic Acid',1,'Red Cell Folic Acid',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(398,'Reducing Substances (Urine)',1,'Reducing Substances (Urine)',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(401,'Rota Virus',1,'Rota Virus',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(402,'TORCH PROFILE REPORT',1,'TORCH PROFILE REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(404,'SEMEN ANALYSIS REPORT',1,'SEMEN ANALYSIS REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(405,'Semen Culture/Sensitivity Report',1,'Semen Culture/Sensitivity Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(407,'Serum Oxalate Report',1,'Serum Oxalate Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(411,'Skin Scraping For Fungus Report',1,'Skin Scraping For Fungus Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(414,'Sputum For AFB C / S',1,'Sputum For AFB C / S',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(415,'Sputum for AFB Report',1,'Sputum for AFB Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(416,'Sputum For C / S',1,'Sputum For C / S',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(417,'Sputum For Cytology ',1,'Sputum For Cytology ',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(418,'Sputum For Gram Stain',1,'Sputum For Gram Stain',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(419,'Sputum For Malignant Cells',1,'Sputum For Malignant Cells',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(420,'Sputum For MTB by PCR',1,'Sputum For MTB by PCR',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(421,'STOOL EXAMINATION REPORT',1,'STOOL EXAMINATION REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(422,'STOOL (FAECES) COMPLETE EXAMINATION REPORT',1,'STOOL (FAECES) COMPLETE EXAMINATION REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(425,'FAECES REPORT',1,'FAECES REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(428,'BLOOD GLUCOSE REPORT',1,'BLOOD GLUCOSE REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(452,'Tacrolimus',1,'Tacrolimus',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(454,'Throat Swab For AFB Smear/ZN',1,'Throat Swab For AFB Smear/ZN',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(455,'Throat Swab For C/S',1,'Throat Swab For C/S',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(456,'Throat Swab For Gram Stain',1,'Throat Swab For Gram Stain',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(458,'TISSUE TYPING REPORT',1,'TISSUE TYPING REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(469,'MYCOBACTRIUM TUBERCLUSIS REPORT',1,'MYCOBACTRIUM TUBERCLUSIS REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(476,'Unconjugated Estriol',1,'Unconjugated Estriol',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(482,'Urinar Protein Electrophoresis',1,'Urinar Protein Electrophoresis',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(488,'Urinary Immunofixation Electrophoresis',1,'Urinary Immunofixation Electrophoresis',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(497,'URINE COMPLETE EXAMINATION REPORT',1,'URINE COMPLETE EXAMINATION REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(498,'URINE EXAMINATION REPORT',1,'URINE EXAMINATION REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(508,'URINE GLUCOSE REPORT',1,'URINE GLUCOSE REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(523,'Varicella Zoster abs',1,'Varicella Zoster abs',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(528,'Vomitus For Occult Blood',1,'Vomitus For Occult Blood',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(531,'WIDAL TEST REPORT',1,'WIDAL TEST REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(532,'Wound Secretion For C/S',1,'Wound Secretion For C/S',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(533,'Wound Swab For AFB Smear - ZN',1,'Wound Swab For AFB Smear - ZN',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(534,'Wound Swab For C / S',1,'Wound Swab For C / S',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(535,'Wound Swap For Gram Stain',1,'Wound Swap For Gram Stain',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(536,'X-Ray',1,'X-Ray',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(537,'Z.N. Staining / AFB Smear Report',1,'Z.N. Staining / AFB Smear Report',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(539,'Zinc Level (24 Hrs. Urine)',1,'Zinc Level (24 Hrs. Urine)',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(542,'ABDOMINAL ULTRASOUND REPORT',1,'ABDOMINAL ULTRASOUND REPORT',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(543,'OBSTETRICAL ULTRASOUND EXAMINATION',1,'OBSTETRICAL ULTRASOUND EXAMINATION',1,NULL,'0000-00-00 00:00:00','0000-00-00 00:00:00'),(544,'URINE PREGNANCY REPORT',1,'URINE PREGNANCY REPORT',1,NULL,'2020-07-07 17:16:43','2020-07-07 17:16:43'),(545,'SPECIAL CHEMISTRY PROTEIN',1,'SPECIAL CHEMISTRY PROTEIN',1,NULL,'2020-07-07 17:23:41','2020-07-07 17:23:41'),(546,'Ascitic Fluid Analysis (C/E) Report',1,'Ascitic Fluid Analysis (C/E) Report',1,NULL,'2020-07-08 04:27:30','2020-07-08 04:27:30'),(547,'BRUCELLA  ANTIBODIES REPORT',1,'BRUCELLA   ANTIBODIES REPORT',1,NULL,'2020-07-10 19:10:19','2020-07-10 19:11:53');
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `diets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `diets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `actual_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `base_id` int(11) DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `diets_business_id_foreign` (`business_id`),
  KEY `diets_created_by_foreign` (`created_by`),
  CONSTRAINT `diets_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `diets_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `diets` WRITE;
/*!40000 ALTER TABLE `diets` DISABLE KEYS */;
/*!40000 ALTER TABLE `diets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `discounts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `discounts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `business_id` int(11) NOT NULL,
  `brand_id` int(11) DEFAULT NULL,
  `category_id` int(11) DEFAULT NULL,
  `location_id` int(11) DEFAULT NULL,
  `priority` int(11) DEFAULT NULL,
  `discount_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount_amount` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `starts_at` datetime DEFAULT NULL,
  `ends_at` datetime DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `applicable_in_spg` tinyint(1) DEFAULT 0,
  `applicable_in_cg` tinyint(1) DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `discounts_business_id_index` (`business_id`),
  KEY `discounts_brand_id_index` (`brand_id`),
  KEY `discounts_category_id_index` (`category_id`),
  KEY `discounts_location_id_index` (`location_id`),
  KEY `discounts_priority_index` (`priority`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `discounts` WRITE;
/*!40000 ALTER TABLE `discounts` DISABLE KEYS */;
/*!40000 ALTER TABLE `discounts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `document_and_notes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `document_and_notes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL,
  `notable_id` int(11) NOT NULL,
  `notable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `heading` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_private` tinyint(1) NOT NULL DEFAULT 0,
  `created_by` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `document_and_notes_business_id_index` (`business_id`),
  KEY `document_and_notes_notable_id_index` (`notable_id`),
  KEY `document_and_notes_created_by_index` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `document_and_notes` WRITE;
/*!40000 ALTER TABLE `document_and_notes` DISABLE KEYS */;
/*!40000 ALTER TABLE `document_and_notes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_allowances_and_deductions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_allowances_and_deductions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('allowance','deduction') COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` decimal(22,4) NOT NULL,
  `amount_type` enum('fixed','percent') COLLATE utf8mb4_unicode_ci NOT NULL,
  `applicable_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_allowances_and_deductions_business_id_index` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_allowances_and_deductions` WRITE;
/*!40000 ALTER TABLE `essentials_allowances_and_deductions` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_allowances_and_deductions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_attendances`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_attendances` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `business_id` int(11) NOT NULL,
  `clock_in_time` datetime DEFAULT NULL,
  `clock_out_time` datetime DEFAULT NULL,
  `essentials_shift_id` int(11) DEFAULT NULL,
  `ip_address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `clock_in_note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `clock_out_note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_attendances_user_id_index` (`user_id`),
  KEY `essentials_attendances_business_id_index` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_attendances` WRITE;
/*!40000 ALTER TABLE `essentials_attendances` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_attendances` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_document_shares`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_document_shares` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `document_id` int(11) NOT NULL,
  `value_type` enum('user','role') COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_document_shares` WRITE;
/*!40000 ALTER TABLE `essentials_document_shares` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_document_shares` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_documents`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_documents` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_documents` WRITE;
/*!40000 ALTER TABLE `essentials_documents` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_documents` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_holidays`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_holidays` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `business_id` int(11) NOT NULL,
  `location_id` int(11) DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_holidays_business_id_index` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_holidays` WRITE;
/*!40000 ALTER TABLE `essentials_holidays` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_holidays` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_leave_types`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_leave_types` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `leave_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `max_leave_count` int(11) DEFAULT NULL,
  `leave_count_interval` enum('month','year') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `business_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_leave_types_business_id_index` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_leave_types` WRITE;
/*!40000 ALTER TABLE `essentials_leave_types` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_leave_types` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_leaves`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_leaves` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `essentials_leave_type_id` int(11) DEFAULT NULL,
  `business_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `start_date` date NOT NULL,
  `end_date` date NOT NULL,
  `ref_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('pending','approved','cancelled') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reason` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status_note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_leaves_essentials_leave_type_id_index` (`essentials_leave_type_id`),
  KEY `essentials_leaves_business_id_index` (`business_id`),
  KEY `essentials_leaves_user_id_index` (`user_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_leaves` WRITE;
/*!40000 ALTER TABLE `essentials_leaves` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_leaves` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_messages`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_messages` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `message` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `location_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_messages` WRITE;
/*!40000 ALTER TABLE `essentials_messages` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_messages` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_reminders`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_reminders` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `time` time NOT NULL,
  `repeat` enum('one_time','every_day','every_week','every_month') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_reminders` WRITE;
/*!40000 ALTER TABLE `essentials_reminders` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_reminders` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_shifts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_shifts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` enum('fixed_shift','flexible_shift') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'fixed_shift',
  `business_id` int(11) NOT NULL,
  `start_time` time DEFAULT NULL,
  `end_time` time DEFAULT NULL,
  `holidays` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_shifts` WRITE;
/*!40000 ALTER TABLE `essentials_shifts` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_shifts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_to_dos`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_to_dos` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL,
  `task` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `date` date NOT NULL,
  `end_date` date DEFAULT NULL,
  `task_id` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `estimated_hours` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `priority` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_to_dos_status_index` (`status`),
  KEY `essentials_to_dos_priority_index` (`priority`),
  KEY `essentials_to_dos_created_by_index` (`created_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_to_dos` WRITE;
/*!40000 ALTER TABLE `essentials_to_dos` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_to_dos` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_todo_comments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_todo_comments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `comment` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `task_id` int(11) NOT NULL,
  `comment_by` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `essentials_todo_comments_task_id_index` (`task_id`),
  KEY `essentials_todo_comments_comment_by_index` (`comment_by`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_todo_comments` WRITE;
/*!40000 ALTER TABLE `essentials_todo_comments` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_todo_comments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_todos_users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_todos_users` (
  `todo_id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_todos_users` WRITE;
/*!40000 ALTER TABLE `essentials_todos_users` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_todos_users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_user_allowance_and_deductions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_user_allowance_and_deductions` (
  `user_id` int(11) NOT NULL,
  `allowance_deduction_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_user_allowance_and_deductions` WRITE;
/*!40000 ALTER TABLE `essentials_user_allowance_and_deductions` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_user_allowance_and_deductions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `essentials_user_shifts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `essentials_user_shifts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `essentials_shift_id` int(11) NOT NULL,
  `start_date` date DEFAULT NULL,
  `end_date` date DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `essentials_user_shifts` WRITE;
/*!40000 ALTER TABLE `essentials_user_shifts` DISABLE KEYS */;
/*!40000 ALTER TABLE `essentials_user_shifts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `expense_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `expense_categories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `business_id` int(10) unsigned NOT NULL,
  `code` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `expense_categories_business_id_foreign` (`business_id`),
  CONSTRAINT `expense_categories_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `expense_categories` WRITE;
/*!40000 ALTER TABLE `expense_categories` DISABLE KEYS */;
/*!40000 ALTER TABLE `expense_categories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `family_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `family_histories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `actual_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `base_id` int(11) DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `family_histories_business_id_foreign` (`business_id`),
  KEY `family_histories_created_by_foreign` (`created_by`),
  CONSTRAINT `family_histories_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `family_histories_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `family_histories` WRITE;
/*!40000 ALTER TABLE `family_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `family_histories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `group_sub_taxes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `group_sub_taxes` (
  `group_tax_id` int(10) unsigned NOT NULL,
  `tax_id` int(10) unsigned NOT NULL,
  KEY `group_sub_taxes_group_tax_id_foreign` (`group_tax_id`),
  KEY `group_sub_taxes_tax_id_foreign` (`tax_id`),
  CONSTRAINT `group_sub_taxes_group_tax_id_foreign` FOREIGN KEY (`group_tax_id`) REFERENCES `tax_rates` (`id`) ON DELETE CASCADE,
  CONSTRAINT `group_sub_taxes_tax_id_foreign` FOREIGN KEY (`tax_id`) REFERENCES `tax_rates` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `group_sub_taxes` WRITE;
/*!40000 ALTER TABLE `group_sub_taxes` DISABLE KEYS */;
/*!40000 ALTER TABLE `group_sub_taxes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `invoice_layouts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoice_layouts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `header_text` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_no_prefix` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quotation_no_prefix` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_heading` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_heading_line1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_heading_line2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_heading_line3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_heading_line4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_heading_line5` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_heading_not_paid` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `invoice_heading_paid` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `quotation_heading` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_total_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `tax_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `round_off_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `total_due_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paid_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `show_client_id` tinyint(1) NOT NULL DEFAULT 0,
  `client_id_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `client_tax_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date_time_format` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `show_time` tinyint(1) NOT NULL DEFAULT 1,
  `show_brand` tinyint(1) NOT NULL DEFAULT 0,
  `show_sku` tinyint(1) NOT NULL DEFAULT 1,
  `show_cat_code` tinyint(1) NOT NULL DEFAULT 1,
  `show_expiry` tinyint(1) NOT NULL DEFAULT 0,
  `show_lot` tinyint(1) NOT NULL DEFAULT 0,
  `show_image` tinyint(1) NOT NULL DEFAULT 0,
  `show_sale_description` tinyint(1) NOT NULL DEFAULT 0,
  `sales_person_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `show_sales_person` tinyint(1) NOT NULL DEFAULT 0,
  `table_product_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `table_qty_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `table_unit_price_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `table_subtotal_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cat_code_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `logo` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `show_logo` tinyint(1) NOT NULL DEFAULT 0,
  `show_business_name` tinyint(1) NOT NULL DEFAULT 0,
  `show_location_name` tinyint(1) NOT NULL DEFAULT 1,
  `show_landmark` tinyint(1) NOT NULL DEFAULT 1,
  `show_city` tinyint(1) NOT NULL DEFAULT 1,
  `show_state` tinyint(1) NOT NULL DEFAULT 1,
  `show_zip_code` tinyint(1) NOT NULL DEFAULT 1,
  `show_country` tinyint(1) NOT NULL DEFAULT 1,
  `show_mobile_number` tinyint(1) NOT NULL DEFAULT 1,
  `show_alternate_number` tinyint(1) NOT NULL DEFAULT 0,
  `show_email` tinyint(1) NOT NULL DEFAULT 0,
  `show_tax_1` tinyint(1) NOT NULL DEFAULT 1,
  `show_tax_2` tinyint(1) NOT NULL DEFAULT 0,
  `show_barcode` tinyint(1) NOT NULL DEFAULT 0,
  `show_payments` tinyint(1) NOT NULL DEFAULT 0,
  `show_customer` tinyint(1) NOT NULL DEFAULT 0,
  `customer_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `show_reward_point` tinyint(1) NOT NULL DEFAULT 0,
  `highlight_color` varchar(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `footer_text` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `module_info` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `common_settings` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `business_id` int(10) unsigned NOT NULL,
  `design` varchar(190) COLLATE utf8mb4_unicode_ci DEFAULT 'classic',
  `cn_heading` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'cn = credit note',
  `cn_no_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cn_amount_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `table_tax_headings` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `show_previous_bal` tinyint(1) NOT NULL DEFAULT 0,
  `prev_bal_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `change_return_label` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_custom_fields` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_custom_fields` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `location_custom_fields` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_layouts_business_id_foreign` (`business_id`),
  CONSTRAINT `invoice_layouts_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `invoice_layouts` WRITE;
/*!40000 ALTER TABLE `invoice_layouts` DISABLE KEYS */;
INSERT INTO `invoice_layouts` VALUES (1,'Default',NULL,'Invoice No.',NULL,'Invoice',NULL,NULL,NULL,NULL,NULL,'','',NULL,'Subtotal','Discount','Tax','Total',NULL,'Total Due','Total Paid',0,NULL,NULL,'Date',NULL,1,0,1,1,0,0,0,0,NULL,0,'Product','Quantity','Unit Price','Subtotal',NULL,NULL,0,0,1,1,1,1,1,1,1,0,0,1,0,0,1,1,'Customer',0,'#000000','',NULL,NULL,1,1,'classic',NULL,NULL,NULL,NULL,0,NULL,NULL,NULL,NULL,NULL,'2020-07-04 12:23:41','2020-07-04 12:23:41');
/*!40000 ALTER TABLE `invoice_layouts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `invoice_schemes`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `invoice_schemes` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `scheme_type` enum('blank','year') COLLATE utf8mb4_unicode_ci NOT NULL,
  `prefix` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `start_number` int(11) DEFAULT NULL,
  `invoice_count` int(11) NOT NULL DEFAULT 0,
  `total_digits` int(11) DEFAULT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `invoice_schemes_business_id_foreign` (`business_id`),
  CONSTRAINT `invoice_schemes_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `invoice_schemes` WRITE;
/*!40000 ALTER TABLE `invoice_schemes` DISABLE KEYS */;
INSERT INTO `invoice_schemes` VALUES (1,1,'Default','blank','',1,14,4,1,'2020-07-04 12:23:41','2020-07-10 20:24:52');
/*!40000 ALTER TABLE `invoice_schemes` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `media`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `media` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL,
  `file_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `uploaded_by` int(11) DEFAULT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `media_model_type_model_id_index` (`model_type`,`model_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `media` WRITE;
/*!40000 ALTER TABLE `media` DISABLE KEYS */;
/*!40000 ALTER TABLE `media` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=291 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES (1,'2014_10_12_000000_create_users_table',1),(2,'2014_10_12_100000_create_password_resets_table',1),(3,'2017_07_05_071953_create_currencies_table',1),(4,'2017_07_05_073658_create_business_table',1),(5,'2017_07_22_075923_add_business_id_users_table',1),(6,'2017_07_23_113209_create_brands_table',1),(7,'2017_07_26_083429_create_permission_tables',1),(8,'2017_07_26_110000_create_tax_rates_table',1),(9,'2017_07_26_122313_create_units_table',1),(10,'2017_07_27_075706_create_contacts_table',1),(11,'2017_08_04_071038_create_categories_table',1),(12,'2017_08_08_115903_create_products_table',1),(13,'2017_08_09_061616_create_variation_templates_table',1),(14,'2017_08_09_061638_create_variation_value_templates_table',1),(15,'2017_08_10_061146_create_product_variations_table',1),(16,'2017_08_10_061216_create_variations_table',1),(17,'2017_08_19_054827_create_transactions_table',1),(18,'2017_08_31_073533_create_purchase_lines_table',1),(19,'2017_10_15_064638_create_transaction_payments_table',1),(20,'2017_10_31_065621_add_default_sales_tax_to_business_table',1),(21,'2017_11_20_051930_create_table_group_sub_taxes',1),(22,'2017_11_20_063603_create_transaction_sell_lines',1),(23,'2017_11_21_064540_create_barcodes_table',1),(24,'2017_11_23_181237_create_invoice_schemes_table',1),(25,'2017_12_25_122822_create_business_locations_table',1),(26,'2017_12_25_160253_add_location_id_to_transactions_table',1),(27,'2017_12_25_163227_create_variation_location_details_table',1),(28,'2018_01_04_115627_create_sessions_table',1),(29,'2018_01_05_112817_create_invoice_layouts_table',1),(30,'2018_01_06_112303_add_invoice_scheme_id_and_invoice_layout_id_to_business_locations',1),(31,'2018_01_08_104124_create_expense_categories_table',1),(32,'2018_01_08_123327_modify_transactions_table_for_expenses',1),(33,'2018_01_09_111005_modify_payment_status_in_transactions_table',1),(34,'2018_01_09_111109_add_paid_on_column_to_transaction_payments_table',1),(35,'2018_01_25_172439_add_printer_related_fields_to_business_locations_table',1),(36,'2018_01_27_184322_create_printers_table',1),(37,'2018_01_30_181442_create_cash_registers_table',1),(38,'2018_01_31_125836_create_cash_register_transactions_table',1),(39,'2018_02_07_173326_modify_business_table',1),(40,'2018_02_08_105425_add_enable_product_expiry_column_to_business_table',1),(41,'2018_02_08_111027_add_expiry_period_and_expiry_period_type_columns_to_products_table',1),(42,'2018_02_08_131118_add_mfg_date_and_exp_date_purchase_lines_table',1),(43,'2018_02_08_155348_add_exchange_rate_to_transactions_table',1),(44,'2018_02_09_124945_modify_transaction_payments_table_for_contact_payments',1),(45,'2018_02_12_113640_create_transaction_sell_lines_purchase_lines_table',1),(46,'2018_02_12_114605_add_quantity_sold_in_purchase_lines_table',1),(47,'2018_02_13_183323_alter_decimal_fields_size',1),(48,'2018_02_14_161928_add_transaction_edit_days_to_business_table',1),(49,'2018_02_15_161032_add_document_column_to_transactions_table',1),(50,'2018_02_17_124709_add_more_options_to_invoice_layouts',1),(51,'2018_02_19_111517_add_keyboard_shortcut_column_to_business_table',1),(52,'2018_02_19_121537_stock_adjustment_move_to_transaction_table',1),(53,'2018_02_20_165505_add_is_direct_sale_column_to_transactions_table',1),(54,'2018_02_21_105329_create_system_table',1),(55,'2018_02_23_100549_version_1_2',1),(56,'2018_02_23_125648_add_enable_editing_sp_from_purchase_column_to_business_table',1),(57,'2018_02_26_103612_add_sales_commission_agent_column_to_business_table',1),(58,'2018_02_26_130519_modify_users_table_for_sales_cmmsn_agnt',1),(59,'2018_02_26_134500_add_commission_agent_to_transactions_table',1),(60,'2018_02_27_121422_add_item_addition_method_to_business_table',1),(61,'2018_02_27_170232_modify_transactions_table_for_stock_transfer',1),(62,'2018_03_05_153510_add_enable_inline_tax_column_to_business_table',1),(63,'2018_03_06_210206_modify_product_barcode_types',1),(64,'2018_03_13_181541_add_expiry_type_to_business_table',1),(65,'2018_03_16_113446_product_expiry_setting_for_business',1),(66,'2018_03_19_113601_add_business_settings_options',1),(67,'2018_03_26_125334_add_pos_settings_to_business_table',1),(68,'2018_03_26_165350_create_customer_groups_table',1),(69,'2018_03_27_122720_customer_group_related_changes_in_tables',1),(70,'2018_03_29_110138_change_tax_field_to_nullable_in_business_table',1),(71,'2018_03_29_115502_add_changes_for_sr_number_in_products_and_sale_lines_table',1),(72,'2018_03_29_134340_add_inline_discount_fields_in_purchase_lines',1),(73,'2018_03_31_140921_update_transactions_table_exchange_rate',1),(74,'2018_04_03_103037_add_contact_id_to_contacts_table',1),(75,'2018_04_03_122709_add_changes_to_invoice_layouts_table',1),(76,'2018_04_09_135320_change_exchage_rate_size_in_business_table',1),(77,'2018_04_17_123122_add_lot_number_to_business',1),(78,'2018_04_17_160845_add_product_racks_table',1),(79,'2018_04_20_182015_create_res_tables_table',1),(80,'2018_04_24_105246_restaurant_fields_in_transaction_table',1),(81,'2018_04_24_114149_add_enabled_modules_business_table',1),(82,'2018_04_24_133704_add_modules_fields_in_invoice_layout_table',1),(83,'2018_04_27_132653_quotation_related_change',1),(84,'2018_05_02_104439_add_date_format_and_time_format_to_business',1),(85,'2018_05_02_111939_add_sell_return_to_transaction_payments',1),(86,'2018_05_14_114027_add_rows_positions_for_products',1),(87,'2018_05_14_125223_add_weight_to_products_table',1),(88,'2018_05_14_164754_add_opening_stock_permission',1),(89,'2018_05_15_134729_add_design_to_invoice_layouts',1),(90,'2018_05_16_183307_add_tax_fields_invoice_layout',1),(91,'2018_05_18_191956_add_sell_return_to_transaction_table',1),(92,'2018_05_21_131349_add_custom_fileds_to_contacts_table',1),(93,'2018_05_21_131607_invoice_layout_fields_for_sell_return',1),(94,'2018_05_21_131949_add_custom_fileds_and_website_to_business_locations_table',1),(95,'2018_05_22_123527_create_reference_counts_table',1),(96,'2018_05_22_154540_add_ref_no_prefixes_column_to_business_table',1),(97,'2018_05_24_132620_add_ref_no_column_to_transaction_payments_table',1),(98,'2018_05_24_161026_add_location_id_column_to_business_location_table',1),(99,'2018_05_25_180603_create_modifiers_related_table',1),(100,'2018_05_29_121714_add_purchase_line_id_to_stock_adjustment_line_table',1),(101,'2018_05_31_114645_add_res_order_status_column_to_transactions_table',1),(102,'2018_06_05_103530_rename_purchase_line_id_in_stock_adjustment_lines_table',1),(103,'2018_06_05_111905_modify_products_table_for_modifiers',1),(104,'2018_06_06_110524_add_parent_sell_line_id_column_to_transaction_sell_lines_table',1),(105,'2018_06_07_152443_add_is_service_staff_to_roles_table',1),(106,'2018_06_07_182258_add_image_field_to_products_table',1),(107,'2018_06_13_133705_create_bookings_table',1),(108,'2018_06_15_173636_add_email_column_to_contacts_table',1),(109,'2018_06_27_182835_add_superadmin_related_fields_business',1),(110,'2018_07_10_101913_add_custom_fields_to_products_table',1),(111,'2018_07_17_103434_add_sales_person_name_label_to_invoice_layouts_table',1),(112,'2018_07_17_163920_add_theme_skin_color_column_to_business_table',1),(113,'2018_07_24_160319_add_lot_no_line_id_to_transaction_sell_lines_table',1),(114,'2018_07_25_110004_add_show_expiry_and_show_lot_colums_to_invoice_layouts_table',1),(115,'2018_07_25_172004_add_discount_columns_to_transaction_sell_lines_table',1),(116,'2018_07_26_124720_change_design_column_type_in_invoice_layouts_table',1),(117,'2018_07_26_170424_add_unit_price_before_discount_column_to_transaction_sell_line_table',1),(118,'2018_07_28_103614_add_credit_limit_column_to_contacts_table',1),(119,'2018_08_08_110755_add_new_payment_methods_to_transaction_payments_table',1),(120,'2018_08_08_122225_modify_cash_register_transactions_table_for_new_payment_methods',1),(121,'2018_08_14_104036_add_opening_balance_type_to_transactions_table',1),(122,'2018_09_04_155900_create_accounts_table',1),(123,'2018_09_06_114438_create_selling_price_groups_table',1),(124,'2018_09_06_154057_create_variation_group_prices_table',1),(125,'2018_09_07_102413_add_permission_to_access_default_selling_price',1),(126,'2018_09_07_134858_add_selling_price_group_id_to_transactions_table',1),(127,'2018_09_10_112448_update_product_type_to_single_if_null_in_products_table',1),(128,'2018_09_10_152703_create_account_transactions_table',1),(129,'2018_09_10_173656_add_account_id_column_to_transaction_payments_table',1),(130,'2018_09_19_123914_create_notification_templates_table',1),(131,'2018_09_22_110504_add_sms_and_email_settings_columns_to_business_table',1),(132,'2018_09_24_134942_add_lot_no_line_id_to_stock_adjustment_lines_table',1),(133,'2018_09_26_105557_add_transaction_payments_for_existing_expenses',1),(134,'2018_09_27_111609_modify_transactions_table_for_purchase_return',1),(135,'2018_09_27_131154_add_quantity_returned_column_to_purchase_lines_table',1),(136,'2018_10_01_151252_create_documents_table',1),(137,'2018_10_02_131401_add_return_quantity_column_to_transaction_sell_lines_table',1),(138,'2018_10_02_151803_create_document_shares_table',1),(139,'2018_10_03_104918_add_qty_returned_column_to_transaction_sell_lines_purchase_lines_table',1),(140,'2018_10_03_185947_add_default_notification_templates_to_database',1),(141,'2018_10_09_134558_create_reminders_table',1),(142,'2018_10_09_153105_add_business_id_to_transaction_payments_table',1),(143,'2018_10_16_135229_create_permission_for_sells_and_purchase',1),(144,'2018_10_22_114441_add_columns_for_variable_product_modifications',1),(145,'2018_10_22_134428_modify_variable_product_data',1),(146,'2018_10_30_181558_add_table_tax_headings_to_invoice_layout',1),(147,'2018_10_31_122619_add_pay_terms_field_transactions_table',1),(148,'2018_10_31_161328_add_new_permissions_for_pos_screen',1),(149,'2018_10_31_174752_add_access_selected_contacts_only_to_users_table',1),(150,'2018_10_31_175627_add_user_contact_access',1),(151,'2018_10_31_180559_add_auto_send_sms_column_to_notification_templates_table',1),(152,'2018_11_02_171949_change_card_type_column_to_varchar_in_transaction_payments_table',1),(153,'2018_11_08_105621_add_role_permissions',1),(154,'2018_11_16_170756_create_to_dos_table',1),(155,'2018_11_26_114135_add_is_suspend_column_to_transactions_table',1),(156,'2018_11_28_104410_modify_units_table_for_multi_unit',1),(157,'2018_11_28_170952_add_sub_unit_id_to_purchase_lines_and_sell_lines',1),(158,'2018_11_29_115918_add_primary_key_in_system_table',1),(159,'2018_12_03_185546_add_product_description_column_to_products_table',1),(160,'2018_12_06_114937_modify_system_table_and_users_table',1),(161,'2018_12_13_160007_add_custom_fields_display_options_to_invoice_layouts_table',1),(162,'2018_12_14_103307_modify_system_table',1),(163,'2018_12_18_133837_add_prev_balance_due_columns_to_invoice_layouts_table',1),(164,'2018_12_18_170656_add_invoice_token_column_to_transaction_table',1),(165,'2018_12_20_133639_add_date_time_format_column_to_invoice_layouts_table',1),(166,'2018_12_21_120659_add_recurring_invoice_fields_to_transactions_table',1),(167,'2018_12_24_154933_create_notifications_table',1),(168,'2019_01_08_112015_add_document_column_to_transaction_payments_table',1),(169,'2019_01_10_124645_add_account_permission',1),(170,'2019_01_16_125825_add_subscription_no_column_to_transactions_table',1),(171,'2019_01_28_111647_add_order_addresses_column_to_transactions_table',1),(172,'2019_02_13_173821_add_is_inactive_column_to_products_table',1),(173,'2019_02_19_103118_create_discounts_table',1),(174,'2019_02_21_120324_add_discount_id_column_to_transaction_sell_lines_table',1),(175,'2019_02_21_134324_add_permission_for_discount',1),(176,'2019_02_22_120329_essentials_messages',1),(177,'2019_02_22_161513_add_message_permissions',1),(178,'2019_03_04_170832_add_service_staff_columns_to_transaction_sell_lines_table',1),(179,'2019_03_09_102425_add_sub_type_column_to_transactions_table',1),(180,'2019_03_09_124457_add_indexing_transaction_sell_lines_purchase_lines_table',1),(181,'2019_03_12_120336_create_activity_log_table',1),(182,'2019_03_15_132925_create_media_table',1),(183,'2019_03_29_164339_add_essentials_version_to_system_table',1),(184,'2019_05_08_130339_add_indexing_to_parent_id_in_transaction_payments_table',1),(185,'2019_05_10_132311_add_missing_column_indexing',1),(186,'2019_05_14_091812_add_show_image_column_to_invoice_layouts_table',1),(187,'2019_05_17_153306_create_essentials_leave_types_table',1),(188,'2019_05_17_175921_create_essentials_leaves_table',1),(189,'2019_05_21_154517_add_essentials_settings_columns_to_business_table',1),(190,'2019_05_21_181653_create_table_essentials_attendance',1),(191,'2019_05_25_104922_add_view_purchase_price_permission',1),(192,'2019_05_30_110049_create_essentials_payrolls_table',1),(193,'2019_06_04_105723_create_essentials_holidays_table',1),(194,'2019_06_17_103515_add_profile_informations_columns_to_users_table',1),(195,'2019_06_18_135524_add_permission_to_view_own_sales_only',1),(196,'2019_06_19_112058_add_database_changes_for_reward_points',1),(197,'2019_06_28_133732_change_type_column_to_string_in_transactions_table',1),(198,'2019_06_28_134217_add_payroll_columns_to_transactions_table',1),(199,'2019_07_13_111420_add_is_created_from_api_column_to_transactions_table',1),(200,'2019_07_15_165136_add_fields_for_combo_product',1),(201,'2019_07_19_103446_add_mfg_quantity_used_column_to_purchase_lines_table',1),(202,'2019_07_22_152649_add_not_for_selling_in_product_table',1),(203,'2019_07_29_185351_add_show_reward_point_column_to_invoice_layouts_table',1),(204,'2019_08_08_162302_add_sub_units_related_fields',1),(205,'2019_08_26_103520_add_approve_leave_permission',1),(206,'2019_08_26_133419_update_price_fields_decimal_point',1),(207,'2019_08_27_103724_create_essentials_allowance_and_deduction_table',1),(208,'2019_08_27_105236_create_essentials_user_allowances_and_deductions',1),(209,'2019_09_02_160054_remove_location_permissions_from_roles',1),(210,'2019_09_03_185259_add_permission_for_pos_screen',1),(211,'2019_09_04_163141_add_location_id_to_cash_registers_table',1),(212,'2019_09_04_184008_create_types_of_services_table',1),(213,'2019_09_06_131445_add_types_of_service_fields_to_transactions_table',1),(214,'2019_09_09_134810_add_default_selling_price_group_id_column_to_business_locations_table',1),(215,'2019_09_12_105616_create_product_locations_table',1),(216,'2019_09_17_122522_add_custom_labels_column_to_business_table',1),(217,'2019_09_18_164319_add_shipping_fields_to_transactions_table',1),(218,'2019_09_19_170927_close_all_active_registers',1),(219,'2019_09_20_115906_add_more_columns_to_essentials_to_dos_table',1),(220,'2019_09_23_120439_create_essentials_todo_comments_table',1),(221,'2019_09_23_161906_add_media_description_cloumn_to_media_table',1),(222,'2019_10_18_155633_create_account_types_table',1),(223,'2019_10_22_163335_add_common_settings_column_to_business_table',1),(224,'2019_10_29_132521_add_update_purchase_status_permission',1),(225,'2019_11_09_110522_add_indexing_to_lot_number',1),(226,'2019_11_19_170824_add_is_active_column_to_business_locations_table',1),(227,'2019_11_21_162913_change_quantity_field_types_to_decimal',1),(228,'2019_11_25_160340_modify_categories_table_for_polymerphic_relationship',1),(229,'2019_12_02_105025_create_warranties_table',1),(230,'2019_12_03_180342_add_common_settings_field_to_invoice_layouts_table',1),(231,'2019_12_05_170724_add_hrm_columns_to_users_table',1),(232,'2019_12_05_183955_add_more_fields_to_users_table',1),(233,'2019_12_06_174904_add_change_return_label_column_to_invoice_layouts_table',1),(234,'2019_12_09_105809_add_allowance_and_deductions_permission',1),(235,'2019_12_11_121307_add_draft_and_quotation_list_permissions',1),(236,'2019_12_12_180126_copy_expense_total_to_total_before_tax',1),(237,'2019_12_19_181412_make_alert_quantity_field_nullable_on_products_table',1),(238,'2019_12_25_173413_create_dashboard_configurations_table',1),(239,'2020_01_08_133506_create_document_and_notes_table',1),(240,'2020_01_09_113252_add_cc_bcc_column_to_notification_templates_table',1),(241,'2020_01_16_174818_add_round_off_amount_field_to_transactions_table',1),(242,'2020_01_28_162345_add_weighing_scale_settings_in_business_settings_table',1),(243,'2020_02_18_172447_add_import_fields_to_transactions_table',1),(244,'2020_03_13_135844_add_is_active_column_to_selling_price_groups_table',1),(245,'2020_03_16_115449_add_contact_status_field_to_contacts_table',1),(246,'2020_03_26_124736_add_allow_login_column_in_users_table',1),(247,'2020_03_28_152838_create_essentials_shift_table',1),(248,'2020_03_30_162029_create_user_shifts_table',1),(249,'2020_03_31_134558_add_shift_id_to_attendance_table',1),(250,'2020_04_05_181044_create_allergies_table',1),(251,'2020_04_05_181138_create_pathological_history',1),(252,'2020_04_05_181237_create_nonpathological_history_table',1),(253,'2020_04_05_181307_create_family_history',1),(254,'2020_04_05_181927_create_phychiatric_history_table',1),(255,'2020_04_05_181951_create_vaccines_table',1),(256,'2020_04_05_182016_create_diets_table',1),(257,'2020_04_08_172100_create_paitent_table',1),(258,'2020_04_13_154150_add_feature_products_column_to_business_loactions',1),(259,'2020_04_14_171642_create_patient_diet_table',1),(260,'2020_04_14_191031_create_patient_allergie_table',1),(261,'2020_04_14_191116_create_patient_family_table',1),(262,'2020_04_14_191143_create_patient_pathlogy_table',1),(263,'2020_04_14_191225_create_patient_nonpathological_table',1),(264,'2020_04_14_191251_create_patient_phychiatrichistory_table',1),(265,'2020_04_14_191313_create_patient_vaccine_table',1),(266,'2020_04_15_151802_add_user_type_to_users_table',1),(267,'2020_04_16_145002_add_coloum',1),(268,'2020_04_16_231040_add_coloum_patient_medical_info',1),(269,'2020_04_17_201946_create_schedule_table',1),(270,'2020_04_18_235810_create_appointment_table',1),(271,'2020_04_21_134823_create_prescription_table',1),(272,'2020_04_22_130503_create_prescriptions_histories__table',1),(273,'2020_04_22_153905_add_subscription_repeat_on_column_to_transactions_table',1),(274,'2020_04_28_111436_add_shipping_address_to_contacts_table',1),(275,'2020_05_09_141859_create_departments_table',1),(276,'2020_05_09_205027_create_tests_table',1),(277,'2020_05_09_231637_create_use_product_tests_table',1),(278,'2020_05_09_232039_create_report_heads_table',1),(279,'2020_05_11_201933_create_test_particulars_table',1),(280,'2020_05_12_235752_create_test_sells_table',1),(281,'2020_05_13_155501_create_report_test_particulars_table',1),(282,'2020_05_16_122802_add_status_test_sell_table',1),(283,'2020_05_16_162520_add_doctor_tranasaction_table',1),(284,'2020_06_01_094654_add_max_sale_discount_column_to_users_table',1),(285,'2020_06_09_020139_addcoloprose',1),(286,'2020_06_16_165253_add_softdelete',1),(287,'2020_06_16_171753_add_invoice_token_test_sell',1),(288,'2020_06_18_101205_add_column_to_transaction',1),(289,'2020_06_19_232858_modifytest_idcolumn',1),(290,'2020_06_19_233513_create_test_heads__table',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_permissions` (
  `permission_id` int(10) unsigned NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`model_id`,`model_type`),
  KEY `model_has_permissions_model_type_model_id_index` (`model_type`,`model_id`),
  CONSTRAINT `model_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_permissions` WRITE;
/*!40000 ALTER TABLE `model_has_permissions` DISABLE KEYS */;
INSERT INTO `model_has_permissions` VALUES (223,'App\\User',2),(223,'App\\User',3),(223,'App\\User',4),(223,'App\\User',5),(223,'App\\User',6),(223,'App\\User',7),(223,'App\\User',8),(223,'App\\User',9),(223,'App\\User',10),(223,'App\\User',11),(223,'App\\User',12),(223,'App\\User',13),(223,'App\\User',14),(223,'App\\User',15),(223,'App\\User',16),(223,'App\\User',17),(223,'App\\User',18),(223,'App\\User',19),(223,'App\\User',20),(223,'App\\User',21),(223,'App\\User',22),(223,'App\\User',23),(223,'App\\User',24),(223,'App\\User',25),(223,'App\\User',26),(223,'App\\User',27),(223,'App\\User',28),(223,'App\\User',29),(223,'App\\User',30),(223,'App\\User',31),(223,'App\\User',32),(223,'App\\User',33),(223,'App\\User',34),(223,'App\\User',35),(223,'App\\User',36),(223,'App\\User',37),(223,'App\\User',38),(223,'App\\User',39),(223,'App\\User',40),(223,'App\\User',41),(223,'App\\User',42),(223,'App\\User',43),(223,'App\\User',44),(223,'App\\User',45),(223,'App\\User',46),(223,'App\\User',47),(223,'App\\User',48),(223,'App\\User',49),(223,'App\\User',50),(223,'App\\User',51),(223,'App\\User',52),(223,'App\\User',53),(223,'App\\User',54),(223,'App\\User',55),(223,'App\\User',56),(223,'App\\User',57),(223,'App\\User',58),(223,'App\\User',59),(223,'App\\User',60),(223,'App\\User',61),(223,'App\\User',62),(223,'App\\User',63),(223,'App\\User',64),(223,'App\\User',65),(223,'App\\User',66),(223,'App\\User',67),(223,'App\\User',68),(223,'App\\User',69),(223,'App\\User',70),(223,'App\\User',71),(223,'App\\User',72),(223,'App\\User',73),(223,'App\\User',74),(223,'App\\User',75),(223,'App\\User',76),(223,'App\\User',77),(223,'App\\User',78),(223,'App\\User',79),(223,'App\\User',80),(223,'App\\User',81),(223,'App\\User',82),(223,'App\\User',83),(223,'App\\User',84),(223,'App\\User',85);
/*!40000 ALTER TABLE `model_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `model_has_roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `model_has_roles` (
  `role_id` int(10) unsigned NOT NULL,
  `model_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `model_id` bigint(20) unsigned NOT NULL,
  PRIMARY KEY (`role_id`,`model_id`,`model_type`),
  KEY `model_has_roles_model_type_model_id_index` (`model_type`,`model_id`),
  CONSTRAINT `model_has_roles_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `model_has_roles` WRITE;
/*!40000 ALTER TABLE `model_has_roles` DISABLE KEYS */;
INSERT INTO `model_has_roles` VALUES (1,'App\\User',1),(1,'App\\User',2),(1,'App\\User',3),(1,'App\\User',4),(1,'App\\User',5),(1,'App\\User',6),(1,'App\\User',7),(1,'App\\User',8),(1,'App\\User',9),(1,'App\\User',10),(1,'App\\User',11),(1,'App\\User',12),(1,'App\\User',13),(1,'App\\User',14),(1,'App\\User',15),(1,'App\\User',16),(1,'App\\User',17),(1,'App\\User',18),(1,'App\\User',19),(1,'App\\User',20),(1,'App\\User',21),(1,'App\\User',22),(1,'App\\User',23),(1,'App\\User',24),(1,'App\\User',25),(1,'App\\User',26),(1,'App\\User',27),(1,'App\\User',28),(1,'App\\User',29),(1,'App\\User',30),(1,'App\\User',31),(1,'App\\User',32),(1,'App\\User',33),(1,'App\\User',34),(1,'App\\User',35),(1,'App\\User',36),(1,'App\\User',37),(1,'App\\User',38),(1,'App\\User',39),(1,'App\\User',40),(1,'App\\User',41),(1,'App\\User',42),(1,'App\\User',43),(1,'App\\User',44),(1,'App\\User',45),(1,'App\\User',46),(1,'App\\User',47),(1,'App\\User',48),(1,'App\\User',49),(1,'App\\User',50),(1,'App\\User',51),(1,'App\\User',52),(1,'App\\User',53),(1,'App\\User',54),(1,'App\\User',55),(1,'App\\User',56),(1,'App\\User',57),(1,'App\\User',58),(1,'App\\User',59),(1,'App\\User',60),(1,'App\\User',61),(1,'App\\User',62),(1,'App\\User',63),(1,'App\\User',64),(1,'App\\User',65),(1,'App\\User',66),(1,'App\\User',67),(1,'App\\User',68),(1,'App\\User',69),(1,'App\\User',70),(1,'App\\User',71),(1,'App\\User',72),(1,'App\\User',73),(1,'App\\User',74),(1,'App\\User',75),(1,'App\\User',76),(1,'App\\User',77),(1,'App\\User',78),(1,'App\\User',79),(1,'App\\User',80),(1,'App\\User',81),(1,'App\\User',82),(1,'App\\User',83),(1,'App\\User',84),(1,'App\\User',85);
/*!40000 ALTER TABLE `model_has_roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `nonpathologicalhistories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `nonpathologicalhistories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `actual_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `base_id` int(11) DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `nonpathologicalhistories_business_id_foreign` (`business_id`),
  KEY `nonpathologicalhistories_created_by_foreign` (`created_by`),
  CONSTRAINT `nonpathologicalhistories_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `nonpathologicalhistories_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `nonpathologicalhistories` WRITE;
/*!40000 ALTER TABLE `nonpathologicalhistories` DISABLE KEYS */;
/*!40000 ALTER TABLE `nonpathologicalhistories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `notification_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notification_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(11) NOT NULL,
  `template_for` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `email_body` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sms_body` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subject` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cc` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bcc` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `auto_send` tinyint(1) NOT NULL DEFAULT 0,
  `auto_send_sms` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=9 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `notification_templates` WRITE;
/*!40000 ALTER TABLE `notification_templates` DISABLE KEYS */;
INSERT INTO `notification_templates` VALUES (1,1,'new_sale','<p>Dear {contact_name},</p>\n\n                    <p>Your invoice number is {invoice_number}<br />\n                    Total amount: {total_amount}<br />\n                    Paid amount: {received_amount}</p>\n\n                    <p>Thank you for shopping with us.</p>\n\n                    <p>{business_logo}</p>\n\n                    <p>&nbsp;</p>','Dear {contact_name}, Thank you for shopping with us. {business_name}','Thank you from {business_name}',NULL,NULL,0,0,'2020-07-04 12:23:41','2020-07-04 12:23:41'),(2,1,'payment_received','<p>Dear {contact_name},</p>\n\n                <p>We have received a payment of {received_amount}</p>\n\n                <p>{business_logo}</p>','Dear {contact_name}, We have received a payment of {received_amount}. {business_name}','Payment Received, from {business_name}',NULL,NULL,0,0,'2020-07-04 12:23:41','2020-07-04 12:23:41'),(3,1,'payment_reminder','<p>Dear {contact_name},</p>\n\n                    <p>This is to remind you that you have pending payment of {due_amount}. Kindly pay it as soon as possible.</p>\n\n                    <p>{business_logo}</p>','Dear {contact_name}, You have pending payment of {due_amount}. Kindly pay it as soon as possible. {business_name}','Payment Reminder, from {business_name}',NULL,NULL,0,0,'2020-07-04 12:23:41','2020-07-04 12:23:41'),(4,1,'new_booking','<p>Dear {contact_name},</p>\n\n                    <p>Your booking is confirmed</p>\n\n                    <p>Date: {start_time} to {end_time}</p>\n\n                    <p>Table: {table}</p>\n\n                    <p>Location: {location}</p>\n\n                    <p>{business_logo}</p>','Dear {contact_name}, Your booking is confirmed. Date: {start_time} to {end_time}, Table: {table}, Location: {location}','Booking Confirmed - {business_name}',NULL,NULL,0,0,'2020-07-04 12:23:41','2020-07-04 12:23:41'),(5,1,'new_order','<p>Dear {contact_name},</p>\n\n                    <p>We have a new order with reference number {order_ref_number}. Kindly process the products as soon as possible.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','Dear {contact_name}, We have a new order with reference number {order_ref_number}. Kindly process the products as soon as possible. {business_name}','New Order, from {business_name}',NULL,NULL,0,0,'2020-07-04 12:23:41','2020-07-04 12:23:41'),(6,1,'payment_paid','<p>Dear {contact_name},</p>\n\n                    <p>We have paid amount {paid_amount} again invoice number {order_ref_number}.<br />\n                    Kindly note it down.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','We have paid amount {paid_amount} again invoice number {order_ref_number}.\n                    Kindly note it down. {business_name}','Payment Paid, from {business_name}',NULL,NULL,0,0,'2020-07-04 12:23:41','2020-07-04 12:23:41'),(7,1,'items_received','<p>Dear {contact_name},</p>\n\n                    <p>We have received all items from invoice reference number {order_ref_number}. Thank you for processing it.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','We have received all items from invoice reference number {order_ref_number}. Thank you for processing it. {business_name}','Items received, from {business_name}',NULL,NULL,0,0,'2020-07-04 12:23:41','2020-07-04 12:23:41'),(8,1,'items_pending','<p>Dear {contact_name},<br />\n                    This is to remind you that we have not yet received some items from invoice reference number {order_ref_number}. Please process it as soon as possible.</p>\n\n                    <p>{business_name}<br />\n                    {business_logo}</p>','This is to remind you that we have not yet received some items from invoice reference number {order_ref_number} . Please process it as soon as possible.{business_name}','Items Pending, from {business_name}',NULL,NULL,0,0,'2020-07-04 12:23:41','2020-07-04 12:23:41');
/*!40000 ALTER TABLE `notification_templates` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `notifications`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `notifications` (
  `id` char(36) COLLATE utf8mb4_unicode_ci NOT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `notifiable_id` bigint(20) unsigned NOT NULL,
  `data` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `read_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `notifications_notifiable_type_notifiable_id_index` (`notifiable_type`,`notifiable_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `notifications` WRITE;
/*!40000 ALTER TABLE `notifications` DISABLE KEYS */;
/*!40000 ALTER TABLE `notifications` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `password_resets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `password_resets` (
  `email` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `token` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  KEY `password_resets_email_index` (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `password_resets` WRITE;
/*!40000 ALTER TABLE `password_resets` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_resets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `pathologicalhistories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `pathologicalhistories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `actual_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `base_id` int(11) DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `pathologicalhistories_business_id_foreign` (`business_id`),
  KEY `pathologicalhistories_created_by_foreign` (`created_by`),
  CONSTRAINT `pathologicalhistories_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `pathologicalhistories_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `pathologicalhistories` WRITE;
/*!40000 ALTER TABLE `pathologicalhistories` DISABLE KEYS */;
/*!40000 ALTER TABLE `pathologicalhistories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `patient_allergies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patient_allergies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `contact_id` int(10) unsigned NOT NULL,
  `base_id` int(11) NOT NULL,
  `allergie_id` int(10) unsigned NOT NULL,
  `check_box` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `patient_allergies_business_id_foreign` (`business_id`),
  KEY `patient_allergies_contact_id_foreign` (`contact_id`),
  KEY `patient_allergies_allergie_id_foreign` (`allergie_id`),
  CONSTRAINT `patient_allergies_allergie_id_foreign` FOREIGN KEY (`allergie_id`) REFERENCES `allergies` (`id`) ON DELETE CASCADE,
  CONSTRAINT `patient_allergies_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `patient_allergies_contact_id_foreign` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `patient_allergies` WRITE;
/*!40000 ALTER TABLE `patient_allergies` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient_allergies` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `patient_diets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patient_diets` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `contact_id` int(10) unsigned NOT NULL,
  `base_id` int(11) NOT NULL,
  `diet_id` int(10) unsigned NOT NULL,
  `check_box` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `patient_diets_business_id_foreign` (`business_id`),
  KEY `patient_diets_contact_id_foreign` (`contact_id`),
  KEY `patient_diets_diet_id_foreign` (`diet_id`),
  CONSTRAINT `patient_diets_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `patient_diets_contact_id_foreign` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `patient_diets_diet_id_foreign` FOREIGN KEY (`diet_id`) REFERENCES `diets` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `patient_diets` WRITE;
/*!40000 ALTER TABLE `patient_diets` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient_diets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `patient_family_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patient_family_histories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `contact_id` int(10) unsigned NOT NULL,
  `base_id` int(11) NOT NULL,
  `family_history_id` int(10) unsigned NOT NULL,
  `check_box` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `patient_family_histories_business_id_foreign` (`business_id`),
  KEY `patient_family_histories_contact_id_foreign` (`contact_id`),
  KEY `patient_family_histories_family_history_id_foreign` (`family_history_id`),
  CONSTRAINT `patient_family_histories_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `patient_family_histories_contact_id_foreign` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `patient_family_histories_family_history_id_foreign` FOREIGN KEY (`family_history_id`) REFERENCES `family_histories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `patient_family_histories` WRITE;
/*!40000 ALTER TABLE `patient_family_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient_family_histories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `patient_nonpathologicals`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patient_nonpathologicals` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `contact_id` int(10) unsigned NOT NULL,
  `base_id` int(11) NOT NULL,
  `nonpathological_id` int(10) unsigned NOT NULL,
  `check_box` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `patient_nonpathologicals_business_id_foreign` (`business_id`),
  KEY `patient_nonpathologicals_contact_id_foreign` (`contact_id`),
  KEY `patient_nonpathologicals_nonpathological_id_foreign` (`nonpathological_id`),
  CONSTRAINT `patient_nonpathologicals_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `patient_nonpathologicals_contact_id_foreign` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `patient_nonpathologicals_nonpathological_id_foreign` FOREIGN KEY (`nonpathological_id`) REFERENCES `nonpathologicalhistories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `patient_nonpathologicals` WRITE;
/*!40000 ALTER TABLE `patient_nonpathologicals` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient_nonpathologicals` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `patient_pathlogies`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patient_pathlogies` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `contact_id` int(10) unsigned NOT NULL,
  `base_id` int(11) NOT NULL,
  `pathologicalhistory_id` int(10) unsigned NOT NULL,
  `check_box` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `patient_pathlogies_business_id_foreign` (`business_id`),
  KEY `patient_pathlogies_contact_id_foreign` (`contact_id`),
  KEY `patient_pathlogies_pathologicalhistory_id_foreign` (`pathologicalhistory_id`),
  CONSTRAINT `patient_pathlogies_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `patient_pathlogies_contact_id_foreign` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `patient_pathlogies_pathologicalhistory_id_foreign` FOREIGN KEY (`pathologicalhistory_id`) REFERENCES `pathologicalhistories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `patient_pathlogies` WRITE;
/*!40000 ALTER TABLE `patient_pathlogies` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient_pathlogies` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `patient_phychiatrichistories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patient_phychiatrichistories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `contact_id` int(10) unsigned NOT NULL,
  `base_id` int(11) NOT NULL,
  `phychiatrichistorie_id` int(10) unsigned NOT NULL,
  `check_box` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `patient_phychiatrichistories_business_id_foreign` (`business_id`),
  KEY `patient_phychiatrichistories_contact_id_foreign` (`contact_id`),
  KEY `patient_phychiatrichistories_phychiatrichistorie_id_foreign` (`phychiatrichistorie_id`),
  CONSTRAINT `patient_phychiatrichistories_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `patient_phychiatrichistories_contact_id_foreign` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `patient_phychiatrichistories_phychiatrichistorie_id_foreign` FOREIGN KEY (`phychiatrichistorie_id`) REFERENCES `phychiatric_histories` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `patient_phychiatrichistories` WRITE;
/*!40000 ALTER TABLE `patient_phychiatrichistories` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient_phychiatrichistories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `patient_vaccines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `patient_vaccines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `contact_id` int(10) unsigned NOT NULL,
  `base_id` int(11) NOT NULL,
  `vaccines_id` int(10) unsigned NOT NULL,
  `check_box` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `patient_vaccines_business_id_foreign` (`business_id`),
  KEY `patient_vaccines_contact_id_foreign` (`contact_id`),
  KEY `patient_vaccines_vaccines_id_foreign` (`vaccines_id`),
  CONSTRAINT `patient_vaccines_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `patient_vaccines_contact_id_foreign` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `patient_vaccines_vaccines_id_foreign` FOREIGN KEY (`vaccines_id`) REFERENCES `vaccines` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `patient_vaccines` WRITE;
/*!40000 ALTER TABLE `patient_vaccines` DISABLE KEYS */;
/*!40000 ALTER TABLE `patient_vaccines` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `permissions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=227 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `permissions` WRITE;
/*!40000 ALTER TABLE `permissions` DISABLE KEYS */;
INSERT INTO `permissions` VALUES (1,'profit_loss_report.view','web','2020-07-04 11:56:11',NULL),(2,'direct_sell.access','web','2020-07-04 11:56:11',NULL),(3,'product.opening_stock','web','2020-07-04 11:56:28','2020-07-04 11:56:28'),(4,'crud_all_bookings','web','2020-07-04 11:56:36','2020-07-04 11:56:36'),(5,'crud_own_bookings','web','2020-07-04 11:56:36','2020-07-04 11:56:36'),(6,'access_default_selling_price','web','2020-07-04 11:56:47','2020-07-04 11:56:47'),(7,'purchase.payments','web','2020-07-04 11:56:53','2020-07-04 11:56:53'),(8,'sell.payments','web','2020-07-04 11:56:53','2020-07-04 11:56:53'),(9,'edit_product_price_from_sale_screen','web','2020-07-04 11:56:56','2020-07-04 11:56:56'),(10,'edit_product_discount_from_sale_screen','web','2020-07-04 11:56:56','2020-07-04 11:56:56'),(11,'roles.view','web','2020-07-04 11:56:58','2020-07-04 11:56:58'),(12,'roles.create','web','2020-07-04 11:56:58','2020-07-04 11:56:58'),(13,'roles.update','web','2020-07-04 11:56:58','2020-07-04 11:56:58'),(14,'roles.delete','web','2020-07-04 11:56:58','2020-07-04 11:56:58'),(15,'account.access','web','2020-07-04 11:57:04','2020-07-04 11:57:04'),(16,'discount.access','web','2020-07-04 11:57:07','2020-07-04 11:57:07'),(17,'essentials.create_message','web','2020-07-04 11:57:08','2020-07-04 11:57:08'),(18,'essentials.view_message','web','2020-07-04 11:57:08','2020-07-04 11:57:08'),(19,'view_purchase_price','web','2020-07-04 11:57:16','2020-07-04 11:57:16'),(20,'view_own_sell_only','web','2020-07-04 11:57:17','2020-07-04 11:57:17'),(21,'essentials.approve_leave','web','2020-07-04 11:57:26','2020-07-04 11:57:26'),(22,'edit_product_discount_from_pos_screen','web','2020-07-04 11:57:27','2020-07-04 11:57:27'),(23,'edit_product_price_from_pos_screen','web','2020-07-04 11:57:27','2020-07-04 11:57:27'),(24,'access_shipping','web','2020-07-04 11:57:30','2020-07-04 11:57:30'),(25,'essentials.assign_todos','web','2020-07-04 11:57:32','2020-07-04 11:57:32'),(26,'purchase.update_status','web','2020-07-04 11:57:34','2020-07-04 11:57:34'),(27,'essentials.add_allowance_and_deduction','web','2020-07-04 11:57:39','2020-07-04 11:57:39'),(28,'list_drafts','web','2020-07-04 11:57:39','2020-07-04 11:57:39'),(29,'list_quotations','web','2020-07-04 11:57:39','2020-07-04 11:57:39'),(30,'essentials.create_message','web','2020-07-04 12:02:29',NULL),(31,'essentials.view_message','web','2020-07-04 12:02:29',NULL),(32,'essentials.approve_leave','web','2020-07-04 12:02:29',NULL),(33,'essentials.add_allowance_and_deduction','web','2020-07-04 12:02:29',NULL),(34,'essentials.assign_todos','web','2020-07-04 12:02:29',NULL),(35,'lab_profit_loss_report.view','web','2020-07-04 12:18:53',NULL),(36,'lab_direct_sell.access','web','2020-07-04 12:18:53',NULL),(37,'lab_list_drafts','web','2020-07-04 12:18:53',NULL),(38,'lab_list_quotations','web','2020-07-04 12:18:53',NULL),(39,'lab_view_own_sell_only','web','2020-07-04 12:18:53',NULL),(40,'lab_sell.payments','web','2020-07-04 12:18:53',NULL),(41,'lab_edit_product_price_from_sale_screen','web','2020-07-04 12:18:53',NULL),(42,'lab_edit_product_price_from_pos_screen','web','2020-07-04 12:18:53',NULL),(43,'lab_edit_product_discount_from_sale_screen','web','2020-07-04 12:18:53',NULL),(44,'lab_edit_product_discount_from_pos_screen','web','2020-07-04 12:18:53',NULL),(45,'lab_discount.access','web','2020-07-04 12:18:53',NULL),(46,'lab_access_shipping','web','2020-07-04 12:18:53',NULL),(47,'lab_purchase.payments','web','2020-07-04 12:18:53',NULL),(48,'lab_purchase.update_status','web','2020-07-04 12:18:53',NULL),(49,'lab_roles.view','web','2020-07-04 12:18:53',NULL),(50,'lab_roles.create','web','2020-07-04 12:18:53',NULL),(51,'lab_roles.update','web','2020-07-04 12:18:53',NULL),(52,'lab_roles.delete','web','2020-07-04 12:18:53',NULL),(53,'lab_test_report.view','web','2020-07-04 12:18:53',NULL),(54,'lab_test_report.create','web','2020-07-04 12:18:53',NULL),(55,'lab_test_report.update','web','2020-07-04 12:18:53',NULL),(56,'lab_test_report.delete','web','2020-07-04 12:18:53',NULL),(57,'vaccine.view','web','2020-07-04 12:18:53',NULL),(58,'vaccine.create','web','2020-07-04 12:18:53',NULL),(59,'vaccine.update','web','2020-07-04 12:18:53',NULL),(60,'vaccine.delete','web','2020-07-04 12:18:53',NULL),(61,'testparticular.view','web','2020-07-04 12:18:53',NULL),(62,'testparticular.create','web','2020-07-04 12:18:53',NULL),(63,'testparticular.update','web','2020-07-04 12:18:53',NULL),(64,'testparticular.delete','web','2020-07-04 12:18:53',NULL),(65,'test.view','web','2020-07-04 12:18:53',NULL),(66,'test.create','web','2020-07-04 12:18:53',NULL),(67,'test.update','web','2020-07-04 12:18:53',NULL),(68,'test.delete','web','2020-07-04 12:18:53',NULL),(69,'schedule.view','web','2020-07-04 12:18:53',NULL),(70,'schedule.create','web','2020-07-04 12:18:53',NULL),(71,'schedule.update','web','2020-07-04 12:18:53',NULL),(72,'schedule.delete','web','2020-07-04 12:18:53',NULL),(73,'prescription.view','web','2020-07-04 12:18:53',NULL),(74,'prescription.create','web','2020-07-04 12:18:53',NULL),(75,'prescription.update','web','2020-07-04 12:18:53',NULL),(76,'prescription.delete','web','2020-07-04 12:18:53',NULL),(77,'phychiatrichistory.view','web','2020-07-04 12:18:53',NULL),(78,'phychiatrichistory.create','web','2020-07-04 12:18:53',NULL),(79,'phychiatrichistory.update','web','2020-07-04 12:18:53',NULL),(80,'phychiatrichistory.delete','web','2020-07-04 12:18:53',NULL),(81,'patient.view','web','2020-07-04 12:18:53',NULL),(82,'patient.create','web','2020-07-04 12:18:53',NULL),(83,'patient.update','web','2020-07-04 12:18:53',NULL),(84,'patient.delete','web','2020-07-04 12:18:53',NULL),(85,'pathologicalhistory.view','web','2020-07-04 12:18:53',NULL),(86,'pathologicalhistory.create','web','2020-07-04 12:18:53',NULL),(87,'pathologicalhistory.update','web','2020-07-04 12:18:53',NULL),(88,'pathologicalhistory.delete','web','2020-07-04 12:18:53',NULL),(89,'nonpathologicalhistory.view','web','2020-07-04 12:18:53',NULL),(90,'nonpathologicalhistory.create','web','2020-07-04 12:18:53',NULL),(91,'nonpathologicalhistory.update','web','2020-07-04 12:18:53',NULL),(92,'nonpathologicalhistory.delete','web','2020-07-04 12:18:53',NULL),(93,'multi_reportmulti_report.view','web','2020-07-04 12:18:53',NULL),(94,'multi_report.create','web','2020-07-04 12:18:53',NULL),(95,'multi_report.update','web','2020-07-04 12:18:53',NULL),(96,'multi_report.delete','web','2020-07-04 12:18:53',NULL),(97,'familyhistory.view','web','2020-07-04 12:18:53',NULL),(98,'familyhistory.create','web','2020-07-04 12:18:53',NULL),(99,'familyhistory.update','web','2020-07-04 12:18:53',NULL),(100,'familyhistory.delete','web','2020-07-04 12:18:53',NULL),(101,'diet.view','web','2020-07-04 12:18:53',NULL),(102,'diet.create','web','2020-07-04 12:18:53',NULL),(103,'diet.update','web','2020-07-04 12:18:53',NULL),(104,'diet.delete','web','2020-07-04 12:18:53',NULL),(105,'lab_department.view','web','2020-07-04 12:18:53',NULL),(106,'lab_department.create','web','2020-07-04 12:18:53',NULL),(107,'lab_department.update','web','2020-07-04 12:18:53',NULL),(108,'lab_department.delete','web','2020-07-04 12:18:53',NULL),(109,'allergie.view','web','2020-07-04 12:18:53',NULL),(110,'allergie.create','web','2020-07-04 12:18:53',NULL),(111,'allergie.update','web','2020-07-04 12:18:53',NULL),(112,'allergie.delete','web','2020-07-04 12:18:53',NULL),(113,'appointment.view','web','2020-07-04 12:18:53',NULL),(114,'appointment.create','web','2020-07-04 12:18:53',NULL),(115,'appointment.update','web','2020-07-04 12:18:53',NULL),(116,'appointment.delete','web','2020-07-04 12:18:53',NULL),(117,'lab_user.view','web','2020-07-04 12:18:53',NULL),(118,'lab_user.create','web','2020-07-04 12:18:53',NULL),(119,'lab_user.update','web','2020-07-04 12:18:53',NULL),(120,'lab_user.delete','web','2020-07-04 12:18:53',NULL),(121,'lab_supplier.view','web','2020-07-04 12:18:53',NULL),(122,'lab_supplier.create','web','2020-07-04 12:18:53',NULL),(123,'lab_supplier.update','web','2020-07-04 12:18:53',NULL),(124,'lab_supplier.delete','web','2020-07-04 12:18:53',NULL),(125,'lab_customer.view','web','2020-07-04 12:18:53',NULL),(126,'lab_customer.create','web','2020-07-04 12:18:53',NULL),(127,'lab_customer.update','web','2020-07-04 12:18:53',NULL),(128,'lab_customer.delete','web','2020-07-04 12:18:53',NULL),(129,'lab_product.view','web','2020-07-04 12:18:53',NULL),(130,'lab_product.create','web','2020-07-04 12:18:53',NULL),(131,'lab_product.update','web','2020-07-04 12:18:53',NULL),(132,'lab_product.delete','web','2020-07-04 12:18:53',NULL),(133,'lab_purchase.view','web','2020-07-04 12:18:53',NULL),(134,'lab_purchase.create','web','2020-07-04 12:18:53',NULL),(135,'lab_purchase.update','web','2020-07-04 12:18:53',NULL),(136,'lab_purchase.delete','web','2020-07-04 12:18:53',NULL),(137,'lab_sell.view','web','2020-07-04 12:18:53',NULL),(138,'lab_sell.create','web','2020-07-04 12:18:53',NULL),(139,'lab_sell.update','web','2020-07-04 12:18:53',NULL),(140,'lab_sell.delete','web','2020-07-04 12:18:53',NULL),(141,'lab_purchase_n_sell_report.view','web','2020-07-04 12:18:53',NULL),(142,'lab_contacts_report.view','web','2020-07-04 12:18:53',NULL),(143,'lab_stock_report.view','web','2020-07-04 12:18:53',NULL),(144,'lab_tax_report.view','web','2020-07-04 12:18:53',NULL),(145,'lab_trending_product_report.view','web','2020-07-04 12:18:53',NULL),(146,'lab_register_report.view','web','2020-07-04 12:18:53',NULL),(147,'lab_sales_representative.view','web','2020-07-04 12:18:53',NULL),(148,'lab_expense_report.view','web','2020-07-04 12:18:53',NULL),(149,'lab_business_settings.access','web','2020-07-04 12:18:53',NULL),(150,'lab_barcode_settings.access','web','2020-07-04 12:18:53',NULL),(151,'lab_invoice_settings.access','web','2020-07-04 12:18:53',NULL),(152,'lab_brand.view','web','2020-07-04 12:18:53',NULL),(153,'lab_brand.create','web','2020-07-04 12:18:53',NULL),(154,'lab_brand.update','web','2020-07-04 12:18:53',NULL),(155,'lab_brand.delete','web','2020-07-04 12:18:53',NULL),(156,'lab_tax_rate.view','web','2020-07-04 12:18:53',NULL),(157,'lab_tax_rate.create','web','2020-07-04 12:18:53',NULL),(158,'lab_tax_rate.update','web','2020-07-04 12:18:53',NULL),(159,'lab_tax_rate.delete','web','2020-07-04 12:18:53',NULL),(160,'lab_unit.view','web','2020-07-04 12:18:53',NULL),(161,'lab_unit.create','web','2020-07-04 12:18:53',NULL),(162,'lab_unit.update','web','2020-07-04 12:18:53',NULL),(163,'lab_unit.delete','web','2020-07-04 12:18:53',NULL),(164,'lab_category.view','web','2020-07-04 12:18:53',NULL),(165,'lab_category.create','web','2020-07-04 12:18:53',NULL),(166,'lab_category.update','web','2020-07-04 12:18:53',NULL),(167,'lab_category.delete','web','2020-07-04 12:18:53',NULL),(168,'lab_expense.access','web','2020-07-04 12:18:53',NULL),(169,'lab_access_all_locations','web','2020-07-04 12:18:53',NULL),(170,'lab_dashboard.data','web','2020-07-04 12:18:53',NULL),(171,'user.view','web','2020-07-04 12:18:53',NULL),(172,'user.create','web','2020-07-04 12:18:53',NULL),(173,'user.update','web','2020-07-04 12:18:53',NULL),(174,'user.delete','web','2020-07-04 12:18:53',NULL),(175,'supplier.view','web','2020-07-04 12:18:53',NULL),(176,'supplier.create','web','2020-07-04 12:18:53',NULL),(177,'supplier.update','web','2020-07-04 12:18:53',NULL),(178,'supplier.delete','web','2020-07-04 12:18:53',NULL),(179,'customer.view','web','2020-07-04 12:18:53',NULL),(180,'customer.create','web','2020-07-04 12:18:53',NULL),(181,'customer.update','web','2020-07-04 12:18:53',NULL),(182,'customer.delete','web','2020-07-04 12:18:53',NULL),(183,'product.view','web','2020-07-04 12:18:53',NULL),(184,'product.create','web','2020-07-04 12:18:53',NULL),(185,'product.update','web','2020-07-04 12:18:53',NULL),(186,'product.delete','web','2020-07-04 12:18:53',NULL),(187,'purchase.view','web','2020-07-04 12:18:53',NULL),(188,'purchase.create','web','2020-07-04 12:18:53',NULL),(189,'purchase.update','web','2020-07-04 12:18:53',NULL),(190,'purchase.delete','web','2020-07-04 12:18:53',NULL),(191,'sell.view','web','2020-07-04 12:18:53',NULL),(192,'sell.create','web','2020-07-04 12:18:53',NULL),(193,'sell.update','web','2020-07-04 12:18:53',NULL),(194,'sell.delete','web','2020-07-04 12:18:53',NULL),(195,'purchase_n_sell_report.view','web','2020-07-04 12:18:53',NULL),(196,'contacts_report.view','web','2020-07-04 12:18:53',NULL),(197,'stock_report.view','web','2020-07-04 12:18:53',NULL),(198,'tax_report.view','web','2020-07-04 12:18:53',NULL),(199,'trending_product_report.view','web','2020-07-04 12:18:53',NULL),(200,'register_report.view','web','2020-07-04 12:18:53',NULL),(201,'sales_representative.view','web','2020-07-04 12:18:53',NULL),(202,'expense_report.view','web','2020-07-04 12:18:53',NULL),(203,'business_settings.access','web','2020-07-04 12:18:53',NULL),(204,'barcode_settings.access','web','2020-07-04 12:18:53',NULL),(205,'invoice_settings.access','web','2020-07-04 12:18:53',NULL),(206,'brand.view','web','2020-07-04 12:18:53',NULL),(207,'brand.create','web','2020-07-04 12:18:53',NULL),(208,'brand.update','web','2020-07-04 12:18:53',NULL),(209,'brand.delete','web','2020-07-04 12:18:53',NULL),(210,'tax_rate.view','web','2020-07-04 12:18:53',NULL),(211,'tax_rate.create','web','2020-07-04 12:18:53',NULL),(212,'tax_rate.update','web','2020-07-04 12:18:53',NULL),(213,'tax_rate.delete','web','2020-07-04 12:18:53',NULL),(214,'unit.view','web','2020-07-04 12:18:53',NULL),(215,'unit.create','web','2020-07-04 12:18:53',NULL),(216,'unit.update','web','2020-07-04 12:18:53',NULL),(217,'unit.delete','web','2020-07-04 12:18:53',NULL),(218,'category.view','web','2020-07-04 12:18:53',NULL),(219,'category.create','web','2020-07-04 12:18:53',NULL),(220,'category.update','web','2020-07-04 12:18:53',NULL),(221,'category.delete','web','2020-07-04 12:18:53',NULL),(222,'expense.access','web','2020-07-04 12:18:53',NULL),(223,'access_all_locations','web','2020-07-04 12:18:53',NULL),(224,'dashboard.data','web','2020-07-04 12:18:53',NULL),(225,'location.1','web','2020-07-04 12:23:42','2020-07-04 12:23:42'),(226,'location.2','web','2020-07-04 12:02:17','2020-07-04 12:02:17');
/*!40000 ALTER TABLE `permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `phychiatric_histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `phychiatric_histories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `actual_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `base_id` int(11) DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `phychiatric_histories_business_id_foreign` (`business_id`),
  KEY `phychiatric_histories_created_by_foreign` (`created_by`),
  CONSTRAINT `phychiatric_histories_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `phychiatric_histories_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `phychiatric_histories` WRITE;
/*!40000 ALTER TABLE `phychiatric_histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `phychiatric_histories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `prescription__histories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prescription__histories` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `prescription_id` int(10) unsigned NOT NULL,
  `height` int(11) DEFAULT NULL,
  `weight` int(11) DEFAULT NULL,
  `body_mass` int(11) DEFAULT NULL,
  `temperature` int(11) DEFAULT NULL,
  `respiratory_rate` int(11) DEFAULT NULL,
  `systole` int(11) DEFAULT NULL,
  `diastole` int(11) DEFAULT NULL,
  `heart_rate` int(11) DEFAULT NULL,
  `body_fat_per` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `lean_body_mass` int(11) DEFAULT NULL,
  `head_circumference` int(11) DEFAULT NULL,
  `oxygen_saturiation` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `prescription__histories_prescription_id_foreign` (`prescription_id`),
  CONSTRAINT `prescription__histories_prescription_id_foreign` FOREIGN KEY (`prescription_id`) REFERENCES `prescriptions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `prescription__histories` WRITE;
/*!40000 ALTER TABLE `prescription__histories` DISABLE KEYS */;
/*!40000 ALTER TABLE `prescription__histories` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `prescriptions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `prescriptions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `appointments_id` int(10) unsigned NOT NULL,
  `contact_id` int(10) unsigned NOT NULL,
  `doctor_id` int(10) unsigned NOT NULL,
  `clinical_record` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `medicine` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `test` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_unit_ids` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `date` datetime NOT NULL,
  `advice` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `validity` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `prescriptions_business_id_foreign` (`business_id`),
  KEY `prescriptions_appointments_id_foreign` (`appointments_id`),
  KEY `prescriptions_contact_id_foreign` (`contact_id`),
  KEY `prescriptions_doctor_id_foreign` (`doctor_id`),
  CONSTRAINT `prescriptions_appointments_id_foreign` FOREIGN KEY (`appointments_id`) REFERENCES `appointments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `prescriptions_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `prescriptions_contact_id_foreign` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `prescriptions_doctor_id_foreign` FOREIGN KEY (`doctor_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `prescriptions` WRITE;
/*!40000 ALTER TABLE `prescriptions` DISABLE KEYS */;
/*!40000 ALTER TABLE `prescriptions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `printers`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `printers` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `connection_type` enum('network','windows','linux') COLLATE utf8mb4_unicode_ci NOT NULL,
  `capability_profile` enum('default','simple','SP2000','TEP-200M','P822D') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'default',
  `char_per_line` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ip_address` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `port` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `path` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `printers_business_id_foreign` (`business_id`),
  CONSTRAINT `printers_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `printers` WRITE;
/*!40000 ALTER TABLE `printers` DISABLE KEYS */;
/*!40000 ALTER TABLE `printers` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `product_locations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_locations` (
  `product_id` int(11) NOT NULL,
  `location_id` int(11) NOT NULL,
  KEY `product_locations_product_id_index` (`product_id`),
  KEY `product_locations_location_id_index` (`location_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `product_locations` WRITE;
/*!40000 ALTER TABLE `product_locations` DISABLE KEYS */;
INSERT INTO `product_locations` VALUES (1,2),(2,2),(3,2),(4,2),(5,2),(6,2),(7,2),(8,2),(9,2),(10,2),(11,2),(13,1),(14,2),(15,2),(16,2),(17,2),(18,2),(19,2),(20,2),(21,2),(22,2),(23,2),(24,2),(25,2),(26,2),(27,2),(28,2),(29,2),(30,2),(31,2),(32,2),(33,2),(34,2),(35,2),(36,2);
/*!40000 ALTER TABLE `product_locations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `product_racks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_racks` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `location_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `rack` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `row` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `position` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `product_racks` WRITE;
/*!40000 ALTER TABLE `product_racks` DISABLE KEYS */;
/*!40000 ALTER TABLE `product_racks` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `product_variations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `product_variations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `variation_template_id` int(11) DEFAULT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `is_dummy` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `product_variations_name_index` (`name`),
  KEY `product_variations_product_id_index` (`product_id`),
  CONSTRAINT `product_variations_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `product_variations` WRITE;
/*!40000 ALTER TABLE `product_variations` DISABLE KEYS */;
INSERT INTO `product_variations` VALUES (1,NULL,'DUMMY',1,1,'2020-07-04 12:28:28','2020-07-04 12:28:28'),(2,NULL,'DUMMY',2,1,'2020-07-04 12:30:02','2020-07-04 12:30:02'),(3,NULL,'DUMMY',3,1,'2020-07-04 12:30:36','2020-07-04 12:30:36'),(4,NULL,'DUMMY',4,1,'2020-07-04 12:31:16','2020-07-04 12:31:16'),(5,NULL,'DUMMY',5,1,'2020-07-06 06:04:19','2020-07-06 06:04:19'),(6,NULL,'DUMMY',6,1,'2020-07-06 06:11:34','2020-07-06 06:11:34'),(7,NULL,'DUMMY',7,1,'2020-07-06 06:16:53','2020-07-06 06:16:53'),(8,NULL,'DUMMY',8,1,'2020-07-06 06:17:55','2020-07-06 06:17:55'),(9,NULL,'DUMMY',9,1,'2020-07-06 06:19:15','2020-07-06 06:19:15'),(10,NULL,'DUMMY',10,1,'2020-07-06 06:19:59','2020-07-06 06:19:59'),(11,NULL,'DUMMY',11,1,'2020-07-06 06:20:50','2020-07-06 06:20:50'),(12,NULL,'DUMMY',12,1,'2020-07-06 07:06:05','2020-07-06 07:06:05'),(14,NULL,'DUMMY',14,1,'2020-07-07 16:52:05','2020-07-07 16:52:05'),(15,NULL,'DUMMY',15,1,'2020-07-07 17:19:10','2020-07-07 17:19:10'),(16,NULL,'DUMMY',16,1,'2020-07-07 17:26:45','2020-07-07 17:26:45'),(17,NULL,'DUMMY',17,1,'2020-07-07 17:28:45','2020-07-07 17:28:45'),(18,NULL,'DUMMY',18,1,'2020-07-10 16:05:18','2020-07-10 16:05:18'),(19,NULL,'DUMMY',19,1,'2020-07-10 16:17:34','2020-07-10 16:17:34'),(20,NULL,'DUMMY',20,1,'2020-07-10 16:34:53','2020-07-10 16:34:53'),(21,NULL,'DUMMY',21,1,'2020-07-10 16:36:18','2020-07-10 16:36:18'),(22,NULL,'DUMMY',22,1,'2020-07-10 16:47:18','2020-07-10 16:47:18'),(23,NULL,'DUMMY',23,1,'2020-07-10 16:59:54','2020-07-10 16:59:54'),(24,NULL,'DUMMY',24,1,'2020-07-10 17:07:13','2020-07-10 17:07:13'),(25,NULL,'DUMMY',25,1,'2020-07-10 17:27:12','2020-07-10 17:27:12'),(26,NULL,'DUMMY',26,1,'2020-07-10 17:41:51','2020-07-10 17:41:51'),(27,NULL,'DUMMY',27,1,'2020-07-10 17:51:17','2020-07-10 17:51:17'),(28,NULL,'DUMMY',28,1,'2020-07-10 17:57:51','2020-07-10 17:57:51'),(29,NULL,'DUMMY',29,1,'2020-07-10 18:16:49','2020-07-10 18:16:49'),(30,NULL,'DUMMY',30,1,'2020-07-10 18:47:32','2020-07-10 18:47:32'),(31,NULL,'DUMMY',31,1,'2020-07-10 18:55:56','2020-07-10 18:55:56'),(32,NULL,'DUMMY',32,1,'2020-07-10 18:56:24','2020-07-10 18:56:24'),(33,NULL,'DUMMY',33,1,'2020-07-10 18:56:56','2020-07-10 18:56:56'),(34,NULL,'DUMMY',34,1,'2020-07-10 18:58:10','2020-07-10 18:58:10'),(35,NULL,'DUMMY',35,1,'2020-07-10 19:06:01','2020-07-10 19:06:01'),(36,NULL,'DUMMY',36,1,'2020-07-10 19:41:54','2020-07-10 19:41:54');
/*!40000 ALTER TABLE `product_variations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `products`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `products` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `business_id` int(10) unsigned NOT NULL,
  `type` enum('single','variable','modifier','combo') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit_id` int(11) unsigned DEFAULT NULL,
  `sub_unit_ids` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `brand_id` int(10) unsigned DEFAULT NULL,
  `category_id` int(10) unsigned DEFAULT NULL,
  `sub_category_id` int(10) unsigned DEFAULT NULL,
  `tax` int(10) unsigned DEFAULT NULL,
  `tax_type` enum('inclusive','exclusive') COLLATE utf8mb4_unicode_ci NOT NULL,
  `enable_stock` tinyint(1) NOT NULL DEFAULT 0,
  `alert_quantity` decimal(22,4) DEFAULT NULL,
  `sku` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `barcode_type` enum('C39','C128','EAN13','EAN8','UPCA','UPCE') COLLATE utf8mb4_unicode_ci DEFAULT 'C128',
  `expiry_period` decimal(4,2) DEFAULT NULL,
  `expiry_period_type` enum('days','months') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enable_sr_no` tinyint(1) NOT NULL DEFAULT 0,
  `weight` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_custom_field1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_custom_field2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_custom_field3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_custom_field4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `image` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `warranty_id` int(11) DEFAULT NULL,
  `is_inactive` tinyint(1) NOT NULL DEFAULT 0,
  `not_for_selling` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `products_brand_id_foreign` (`brand_id`),
  KEY `products_category_id_foreign` (`category_id`),
  KEY `products_sub_category_id_foreign` (`sub_category_id`),
  KEY `products_tax_foreign` (`tax`),
  KEY `products_name_index` (`name`),
  KEY `products_business_id_index` (`business_id`),
  KEY `products_unit_id_index` (`unit_id`),
  KEY `products_created_by_index` (`created_by`),
  KEY `products_warranty_id_index` (`warranty_id`),
  CONSTRAINT `products_brand_id_foreign` FOREIGN KEY (`brand_id`) REFERENCES `brands` (`id`) ON DELETE CASCADE,
  CONSTRAINT `products_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `products_category_id_foreign` FOREIGN KEY (`category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `products_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `products_sub_category_id_foreign` FOREIGN KEY (`sub_category_id`) REFERENCES `categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `products_tax_foreign` FOREIGN KEY (`tax`) REFERENCES `tax_rates` (`id`),
  CONSTRAINT `products_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `products` WRITE;
/*!40000 ALTER TABLE `products` DISABLE KEYS */;
INSERT INTO `products` VALUES (1,'cell pack',1,'single',2,'[\"3\",\"7\"]',NULL,NULL,NULL,NULL,'exclusive',1,10.0000,'0001','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,0,'2020-07-04 12:28:28','2020-07-04 12:28:28'),(2,'stromatolyser',1,'single',2,'[\"6\",\"7\"]',NULL,NULL,NULL,NULL,'exclusive',1,100.0000,'0002','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,0,'2020-07-04 12:30:02','2020-07-04 12:30:02'),(3,'EDTA tube',1,'single',1,'[\"1\"]',NULL,NULL,NULL,NULL,'exclusive',1,20.0000,'0003','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,0,'2020-07-04 12:30:36','2020-07-04 12:30:36'),(4,'3 ml sirnge',1,'single',1,'[\"1\"]',NULL,NULL,NULL,NULL,'exclusive',1,120.0000,'0004','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,0,'2020-07-04 12:31:16','2020-07-07 16:19:19'),(5,'SGPT Regeant R1 R2',1,'single',2,'[\"6\",\"7\"]',NULL,NULL,NULL,NULL,'exclusive',1,NULL,'0005','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,0,'2020-07-06 06:04:19','2020-07-06 06:08:10'),(6,'H.pylori kit',1,'single',1,'[\"1\"]',NULL,NULL,NULL,NULL,'exclusive',1,NULL,'0006','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,0,'2020-07-06 06:11:34','2020-07-06 06:11:34'),(7,'Urine Bottal 60ml',1,'single',1,'[\"1\"]',NULL,NULL,NULL,NULL,'exclusive',1,NULL,'0007','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,0,'2020-07-06 06:16:53','2020-07-06 06:16:53'),(8,'Urine Cancave Tube',1,'single',1,'[\"1\"]',NULL,NULL,NULL,NULL,'exclusive',1,NULL,'0008','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,0,'2020-07-06 06:17:55','2020-07-06 06:17:55'),(9,'Combo 10 Urine Stips',1,'single',1,'[\"1\"]',NULL,NULL,NULL,NULL,'exclusive',1,NULL,'0009','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,0,'2020-07-06 06:19:15','2020-07-06 06:19:15'),(10,'Glass Slide',1,'single',1,'[\"1\"]',NULL,NULL,NULL,NULL,'exclusive',1,NULL,'0010','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,0,'2020-07-06 06:19:59','2020-07-06 06:19:59'),(11,'Cover Slip',1,'single',1,'[\"1\"]',NULL,NULL,NULL,NULL,'exclusive',1,NULL,'0011','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,0,'2020-07-06 06:20:50','2020-07-06 06:20:50'),(12,'sugar Tube',1,'single',1,'[\"1\"]',NULL,NULL,NULL,NULL,'exclusive',1,NULL,'0012','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,0,'2020-07-06 07:06:05','2020-07-06 07:06:05'),(14,'Heparin tube',1,'single',1,'[\"1\"]',NULL,NULL,NULL,NULL,'exclusive',1,NULL,'0014','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,0,'2020-07-07 16:52:05','2020-07-07 16:52:05'),(15,'Pregnancy stripe',1,'single',1,'[\"1\"]',NULL,NULL,NULL,NULL,'exclusive',1,NULL,'0015','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,0,'2020-07-07 17:19:10','2020-07-07 17:19:10'),(16,'Gel  tube',1,'single',1,'[\"1\"]',NULL,NULL,NULL,NULL,'exclusive',1,NULL,'0016','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,0,'2020-07-07 17:26:45','2020-07-07 17:26:45'),(17,'print paper  A4',1,'single',1,'[\"1\"]',NULL,NULL,NULL,NULL,'exclusive',1,NULL,'0017','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,0,'2020-07-07 17:28:45','2020-07-07 17:28:45'),(18,'Tsh',1,'single',1,'[\"1\"]',NULL,NULL,NULL,NULL,'exclusive',1,NULL,'0018','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,0,'2020-07-10 16:05:18','2020-07-10 16:05:18'),(19,'TYPHIOD IgG',1,'single',1,'[\"1\"]',NULL,NULL,NULL,NULL,'exclusive',1,NULL,'0019','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,0,'2020-07-10 16:17:34','2020-07-10 16:17:34'),(20,'CAL. TUB',1,'single',1,'[\"1\"]',NULL,NULL,NULL,NULL,'exclusive',1,NULL,'0020','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,0,'2020-07-10 16:34:53','2020-07-10 16:34:53'),(21,'YEL.TIP',1,'single',1,'[\"1\"]',NULL,NULL,NULL,NULL,'exclusive',1,NULL,'0021','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,0,'2020-07-10 16:36:18','2020-07-10 16:36:18'),(22,'T3',1,'single',1,'[\"1\"]',NULL,NULL,NULL,NULL,'exclusive',1,NULL,'0022','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,0,'2020-07-10 16:47:18','2020-07-10 16:47:18'),(23,'T4',1,'single',1,'[\"1\"]',NULL,NULL,NULL,NULL,'exclusive',1,NULL,'0023','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,0,'2020-07-10 16:59:54','2020-07-10 16:59:54'),(24,'Tcs',1,'single',1,'[\"1\"]',NULL,NULL,NULL,NULL,'exclusive',1,NULL,'0024','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,0,'2020-07-10 17:07:13','2020-07-10 17:07:13'),(25,'Hba1c',1,'single',1,'[\"1\"]',NULL,NULL,NULL,NULL,'exclusive',1,NULL,'0025','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,0,'2020-07-10 17:27:12','2020-07-10 17:27:12'),(26,'FSh',1,'single',1,'[\"1\"]',NULL,NULL,NULL,NULL,'exclusive',1,NULL,'0026','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,0,'2020-07-10 17:41:51','2020-07-10 17:41:51'),(27,'LH',1,'single',1,'[\"1\"]',NULL,NULL,NULL,NULL,'exclusive',1,NULL,'0027','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,0,'2020-07-10 17:51:17','2020-07-10 17:51:17'),(28,'Testosterone',1,'single',1,'[\"1\"]',NULL,NULL,NULL,NULL,'exclusive',1,NULL,'0028','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,0,'2020-07-10 17:57:51','2020-07-10 17:57:51'),(29,'Prolactin',1,'single',1,'[\"1\"]',NULL,NULL,NULL,NULL,'exclusive',1,NULL,'0029','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,0,'2020-07-10 18:16:49','2020-07-10 18:16:49'),(30,'Amylase',1,'single',2,'[\"7\"]',NULL,NULL,NULL,NULL,'exclusive',1,NULL,'0030','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,0,'2020-07-10 18:47:32','2020-07-10 18:47:32'),(31,'Creatinine',1,'single',2,'[\"7\"]',NULL,NULL,NULL,NULL,'exclusive',1,NULL,'0031','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,0,'2020-07-10 18:55:56','2020-07-10 18:55:56'),(32,'Urea',1,'single',2,'[\"7\"]',NULL,NULL,NULL,NULL,'exclusive',1,NULL,'0032','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,0,'2020-07-10 18:56:24','2020-07-10 18:56:24'),(33,'Albumin',1,'single',2,'[\"7\"]',NULL,NULL,NULL,NULL,'exclusive',1,NULL,'0033','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,0,'2020-07-10 18:56:56','2020-07-10 18:56:56'),(34,'total proteins',1,'single',2,'[\"7\"]',NULL,NULL,NULL,NULL,'exclusive',1,NULL,'0034','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,0,'2020-07-10 18:58:10','2020-07-10 18:58:10'),(35,'CPK',1,'single',2,'[\"7\"]',NULL,NULL,NULL,NULL,'exclusive',1,NULL,'0035','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,0,'2020-07-10 19:06:01','2020-07-10 19:06:01'),(36,'Brucella',1,'single',2,'[\"7\"]',NULL,NULL,NULL,NULL,'exclusive',1,NULL,'0036','C128',12.00,'months',0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,1,NULL,0,0,'2020-07-10 19:41:54','2020-07-10 19:41:54');
/*!40000 ALTER TABLE `products` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `purchase_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `purchase_lines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `variation_id` int(10) unsigned NOT NULL,
  `quantity` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `pp_without_discount` decimal(22,4) NOT NULL DEFAULT 0.0000 COMMENT 'Purchase price before inline discounts',
  `discount_percent` decimal(5,2) NOT NULL DEFAULT 0.00 COMMENT 'Inline discount percentage',
  `purchase_price` decimal(22,4) NOT NULL,
  `purchase_price_inc_tax` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `item_tax` decimal(22,4) NOT NULL COMMENT 'Tax for one quantity',
  `tax_id` int(10) unsigned DEFAULT NULL,
  `quantity_sold` decimal(22,4) NOT NULL DEFAULT 0.0000 COMMENT 'Quanity sold from this purchase line',
  `quantity_adjusted` decimal(22,4) NOT NULL DEFAULT 0.0000 COMMENT 'Quanity adjusted in stock adjustment from this purchase line',
  `quantity_returned` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `mfg_quantity_used` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `mfg_date` date DEFAULT NULL,
  `exp_date` date DEFAULT NULL,
  `lot_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_unit_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `purchase_lines_transaction_id_foreign` (`transaction_id`),
  KEY `purchase_lines_product_id_foreign` (`product_id`),
  KEY `purchase_lines_variation_id_foreign` (`variation_id`),
  KEY `purchase_lines_tax_id_foreign` (`tax_id`),
  KEY `purchase_lines_sub_unit_id_index` (`sub_unit_id`),
  KEY `purchase_lines_lot_number_index` (`lot_number`),
  CONSTRAINT `purchase_lines_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `purchase_lines_tax_id_foreign` FOREIGN KEY (`tax_id`) REFERENCES `tax_rates` (`id`) ON DELETE CASCADE,
  CONSTRAINT `purchase_lines_transaction_id_foreign` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `purchase_lines_variation_id_foreign` FOREIGN KEY (`variation_id`) REFERENCES `variations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `purchase_lines` WRITE;
/*!40000 ALTER TABLE `purchase_lines` DISABLE KEYS */;
/*!40000 ALTER TABLE `purchase_lines` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `reference_counts`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `reference_counts` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `ref_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `ref_count` int(11) NOT NULL,
  `business_id` int(11) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `reference_counts` WRITE;
/*!40000 ALTER TABLE `reference_counts` DISABLE KEYS */;
INSERT INTO `reference_counts` VALUES (1,'contacts',5,1,'2020-07-04 12:23:41','2020-07-10 20:24:29'),(2,'business_location',2,1,'2020-07-04 12:23:42','2020-07-04 12:02:17'),(3,'username',86,1,'2020-07-04 12:07:04','2020-07-04 14:14:23'),(4,'report',18,1,'2020-07-04 13:19:21','2020-07-10 20:24:52'),(5,'sell_payment',17,1,'2020-07-04 13:19:21','2020-07-10 20:29:43'),(6,'expense',3,1,'2020-07-09 15:11:32','2020-07-10 20:29:43'),(7,'purchase_payment',1,1,'2020-07-09 15:38:27','2020-07-09 15:38:27');
/*!40000 ALTER TABLE `reference_counts` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `report_heads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `report_heads` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `test_id` int(11) unsigned DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_show` tinyint(1) NOT NULL DEFAULT 1,
  PRIMARY KEY (`id`),
  KEY `report_heads_test_id_foreign` (`test_id`),
  CONSTRAINT `report_heads_test_id_foreign` FOREIGN KEY (`test_id`) REFERENCES `tests` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=91 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `report_heads` WRITE;
/*!40000 ALTER TABLE `report_heads` DISABLE KEYS */;
INSERT INTO `report_heads` VALUES (1,'COMPLETE BLOOD COUNT',NULL,NULL,'2020-07-04 12:48:51','2020-07-04 13:32:36',1),(2,'PHYSICAL EXAMINATION',NULL,NULL,'2020-07-04 12:56:57','2020-07-04 12:56:57',1),(3,'DIFFERENTIAL LEUKOCYTES COUNT',NULL,NULL,'2020-07-04 13:03:20','2020-07-04 13:03:20',1),(4,'CHEMICAL ANALYSIS',NULL,NULL,'2020-07-04 13:03:50','2020-07-04 13:03:50',1),(5,'MICROSCOPIC EXAMINATION',NULL,NULL,'2020-07-04 13:20:10','2020-07-04 13:20:10',1),(6,'HB',NULL,NULL,'2020-07-04 14:01:27','2020-07-07 16:57:34',1),(7,'SGPT Report',NULL,NULL,'2020-07-06 06:31:53','2020-07-10 19:53:05',0),(8,'H.Pylori Abs (Screening)',NULL,NULL,'2020-07-06 06:44:22','2020-07-07 16:56:03',1),(9,'Blood sugar',NULL,NULL,'2020-07-06 07:02:04','2020-07-07 16:57:21',1),(10,'Typhidot',NULL,NULL,'2020-07-06 07:12:53','2020-07-07 16:57:50',1),(11,'Creatinine Report',NULL,NULL,'2020-07-07 16:08:58','2020-07-07 16:56:32',1),(12,'Urea',NULL,NULL,'2020-07-07 16:46:12','2020-07-07 16:46:48',1),(13,'LDH (Lactic Dehydrogenase)',NULL,NULL,'2020-07-07 17:03:29','2020-07-07 17:03:29',1),(14,'Albumin',NULL,NULL,'2020-07-07 17:10:11','2020-07-07 17:10:11',1),(15,'Pregnancy',NULL,NULL,'2020-07-07 17:15:24','2020-07-07 17:15:24',1),(16,'CRP',NULL,NULL,'2020-07-07 17:23:10','2020-07-07 17:23:10',1),(17,'CPK',NULL,NULL,'2020-07-07 17:31:58','2020-07-07 17:31:58',1),(18,'Serum A.C.Enzyme',NULL,NULL,'2020-07-08 01:06:48','2020-07-08 01:19:00',1),(19,'A/G Ratio',NULL,NULL,'2020-07-08 01:10:44','2020-07-08 01:10:44',1),(20,'ACTH',NULL,NULL,'2020-07-08 01:21:49','2020-07-08 01:21:49',1),(21,'ANA',NULL,NULL,'2020-07-08 01:24:08','2020-07-08 01:24:08',1),(22,'A.P.T.T.',NULL,NULL,'2020-07-08 03:01:50','2020-07-08 03:01:50',1),(23,'Serum Aldolase',NULL,NULL,'2020-07-08 03:08:05','2020-07-08 03:08:05',1),(24,'Aldosteron Level',NULL,NULL,'2020-07-08 03:10:57','2020-07-08 03:10:57',1),(25,'Alkaline Phosphate',NULL,NULL,'2020-07-08 03:14:11','2020-07-08 03:14:11',1),(26,'Alpha-MBDH',NULL,NULL,'2020-07-08 03:17:18','2020-07-08 03:17:18',1),(27,'ALPHA Feto-Protein',NULL,NULL,'2020-07-08 03:22:50','2020-07-08 03:22:50',1),(28,'Ammonia (NH3)',NULL,NULL,'2020-07-08 03:30:28','2020-07-08 03:30:28',1),(29,'Serum Amylase',NULL,NULL,'2020-07-08 03:32:52','2020-07-08 03:32:52',1),(30,'Urinary Amylase',NULL,NULL,'2020-07-08 03:34:47','2020-07-08 16:58:05',0),(31,'Anti ds DNA',NULL,NULL,'2020-07-08 03:37:38','2020-07-08 03:37:38',1),(32,'Anti HBc lgG',NULL,NULL,'2020-07-08 03:53:43','2020-07-08 03:53:43',1),(33,'Anti HBc lgM',NULL,NULL,'2020-07-08 03:55:24','2020-07-08 03:55:24',1),(34,'Anti HBe',NULL,NULL,'2020-07-08 03:57:32','2020-07-08 03:57:32',1),(35,'Anti HBs',NULL,NULL,'2020-07-08 03:59:15','2020-07-08 03:59:15',1),(36,'Anti HCV',NULL,NULL,'2020-07-08 04:01:16','2020-07-08 04:01:16',1),(37,'Anti HCV (ELISA)',NULL,NULL,'2020-07-08 04:04:25','2020-07-08 04:04:25',1),(38,'Anti HEV IgM',NULL,NULL,'2020-07-08 04:06:33','2020-07-08 04:06:33',1),(39,'Anti HEV IgM',NULL,'2020-07-08 04:10:01','2020-07-08 04:08:03','2020-07-08 04:10:01',1),(40,'Anti Sperm Abs (Scamual)',NULL,NULL,'2020-07-08 04:12:40','2020-07-08 04:12:40',1),(41,'PHYSICAL EXAMINATION:',NULL,NULL,'2020-07-08 04:17:54','2020-07-08 04:17:54',1),(42,'CHEMICAL EXAMINATION:',NULL,NULL,'2020-07-08 04:22:29','2020-07-08 04:22:29',1),(43,'MICROSCOPIC EXAMINATION:',NULL,NULL,'2020-07-08 04:24:16','2020-07-08 04:24:16',1),(44,'STAINING',NULL,NULL,'2020-07-08 04:25:56','2020-07-08 04:25:56',1),(45,'ASOT (Quantitative)',NULL,NULL,'2020-07-08 04:30:40','2020-07-08 04:30:40',1),(46,'Beta HCG',NULL,NULL,'2020-07-08 04:33:13','2020-07-08 04:33:13',1),(47,'Bicarbonate (HCO3)',NULL,NULL,'2020-07-08 04:35:15','2020-07-08 04:35:15',1),(48,'Bilirubin (Direct)',NULL,NULL,'2020-07-08 04:39:37','2020-07-08 04:39:37',1),(49,'Bilirubin (Total)',NULL,NULL,'2020-07-08 04:48:20','2020-07-08 04:48:20',1),(50,'Bilirubin (Indirect)',NULL,NULL,'2020-07-08 04:50:11','2020-07-08 04:50:11',1),(51,'COAGULATION PROFILE',NULL,NULL,'2020-07-08 04:53:00','2020-07-08 04:53:00',1),(52,'RENAL FUNCTION REPORT',NULL,NULL,'2020-07-08 04:57:55','2020-07-08 04:57:55',1),(53,'Blood Group & Rh Factor',NULL,NULL,'2020-07-08 05:01:33','2020-07-08 05:01:33',1),(54,'BUN',NULL,NULL,'2020-07-08 15:07:06','2020-07-08 15:07:06',1),(55,'CEA',NULL,NULL,'2020-07-08 15:09:32','2020-07-08 15:09:32',1),(56,'C-3',NULL,NULL,'2020-07-08 15:11:46','2020-07-08 15:11:46',1),(57,'C-4',NULL,NULL,'2020-07-08 15:14:24','2020-07-08 15:14:24',1),(58,'CA 125',NULL,NULL,'2020-07-08 15:16:49','2020-07-08 15:16:49',1),(59,'CA 19-9',NULL,NULL,'2020-07-08 15:19:48','2020-07-08 15:19:48',1),(60,'Calcium (Ca+)',NULL,NULL,'2020-07-08 15:41:32','2020-07-08 15:41:32',1),(61,'Carbamazepine (Tegretol)',NULL,NULL,'2020-07-08 15:44:55','2020-07-08 15:44:55',1),(62,'Cardiac Enzymes (CPK,CKMB,SGOT,LDH)',NULL,NULL,'2020-07-08 15:50:41','2020-07-08 15:50:41',1),(63,'Chloride (Cl-)',NULL,NULL,'2020-07-08 15:54:10','2020-07-08 15:54:10',1),(64,'Cholesterol',NULL,NULL,'2020-07-08 15:57:40','2020-07-08 15:57:40',0),(65,'CK-MB',NULL,'2020-07-08 17:06:29','2020-07-08 17:05:39','2020-07-08 17:06:29',1),(66,'zxc',NULL,'2020-07-08 20:31:20','2020-07-08 20:30:41','2020-07-08 20:31:20',1),(67,'CK-MB',NULL,NULL,'2020-07-08 20:31:36','2020-07-08 20:33:28',0),(68,'COAGULATION PROFILE:',NULL,NULL,'2020-07-08 20:37:46','2020-07-08 20:38:34',1),(69,'CMV lgG',NULL,NULL,'2020-07-08 20:55:47','2020-07-08 20:55:47',0),(70,'CMV lgM',NULL,NULL,'2020-07-08 20:57:35','2020-07-08 20:57:35',0),(71,'Direct',NULL,NULL,'2020-07-08 21:00:03','2020-07-08 21:00:03',0),(72,'Indirect',NULL,NULL,'2020-07-08 21:03:07','2020-07-08 21:03:21',0),(73,'Typhidot IgG',NULL,NULL,'2020-07-10 15:57:13','2020-07-10 16:17:00',0),(74,'TSH',NULL,NULL,'2020-07-10 15:58:20','2020-07-10 15:59:17',0),(75,'Clinical Interpretation',NULL,NULL,'2020-07-10 16:07:23','2020-07-10 16:07:23',1),(76,'SM PHYSICAL EXAMINATION',NULL,NULL,'2020-07-10 16:23:48','2020-07-10 16:23:48',1),(77,'SM MICROSCOPIC EXAMINATION',NULL,NULL,'2020-07-10 16:28:53','2020-07-10 16:28:53',1),(78,'LFT-Liver Functions Tests',NULL,NULL,'2020-07-10 16:30:47','2020-07-10 16:30:47',0),(79,'MOTILITY',NULL,NULL,'2020-07-10 16:33:30','2020-07-10 16:33:30',1),(80,'SM MORPHOLOGY',NULL,NULL,'2020-07-10 16:35:26','2020-07-10 16:35:26',1),(81,'T3',NULL,NULL,'2020-07-10 16:42:53','2020-07-10 16:42:53',0),(82,'Widal Test',NULL,NULL,'2020-07-10 16:49:35','2020-07-10 16:49:35',0),(83,'T4',NULL,NULL,'2020-07-10 16:57:32','2020-07-10 16:57:32',0),(84,'Hcv pcr QN',NULL,NULL,'2020-07-10 17:03:35','2020-07-10 17:03:35',0),(85,'Hba1c',NULL,NULL,'2020-07-10 17:30:19','2020-07-10 17:30:19',0),(86,'FSH',NULL,NULL,'2020-07-10 17:45:31','2020-07-10 17:45:31',0),(87,'LH',NULL,NULL,'2020-07-10 17:53:43','2020-07-10 17:53:43',0),(88,'Testosterone',NULL,NULL,'2020-07-10 17:59:14','2020-07-10 17:59:14',0),(89,'Prolactin',NULL,NULL,'2020-07-10 18:18:28','2020-07-10 18:18:28',0),(90,'Brucella  Antibodies Report',NULL,NULL,'2020-07-10 19:08:04','2020-07-10 19:08:04',1);
/*!40000 ALTER TABLE `report_heads` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `report_test_particulars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `report_test_particulars` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `test_sell_id` int(10) unsigned NOT NULL,
  `report_head_id` int(10) unsigned NOT NULL,
  `invoice_token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `result` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `male` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `female` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `high_range` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `low_range` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `report_test_particulars_test_sell_id_foreign` (`test_sell_id`),
  KEY `report_test_particulars_report_head_id_foreign` (`report_head_id`),
  CONSTRAINT `report_test_particulars_report_head_id_foreign` FOREIGN KEY (`report_head_id`) REFERENCES `report_heads` (`id`) ON DELETE CASCADE,
  CONSTRAINT `report_test_particulars_test_sell_id_foreign` FOREIGN KEY (`test_sell_id`) REFERENCES `test_sells` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=152 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `report_test_particulars` WRITE;
/*!40000 ALTER TABLE `report_test_particulars` DISABLE KEYS */;
INSERT INTO `report_test_particulars` VALUES (1,'HEMOGLOBIN (HB)',1,1,NULL,'10','d/dl','14 - 18','11 - 16','16','11.5','2020-07-04 13:19:21','2020-07-04 13:21:56'),(2,'WBC (TLC)',1,1,NULL,'9','x10 /ul','3.8 - 11','3.8 - 11','11','3.8','2020-07-04 13:19:21','2020-07-04 13:21:56'),(3,'TOTAL RBC',1,1,NULL,'5','Millo/Cmm','4.5 - 6.0','4.0 - 5.5','5.5','4.0','2020-07-04 13:19:21','2020-07-04 13:21:56'),(4,'MCV',1,1,NULL,'5','fl','80 - 96','76 - 96','96','76','2020-07-04 13:19:21','2020-07-04 13:21:56'),(5,'RDW - CV',1,1,NULL,'5','%','12 - 14','12 - 14','14','12','2020-07-04 13:19:21','2020-07-04 13:21:56'),(6,'RDW - SD',1,1,NULL,'56','fl^3','37 - 47','37 - 47','47','37','2020-07-04 13:19:21','2020-07-04 13:21:56'),(7,'HCT',1,1,NULL,'54','%','40 - 49','36 - 46','46','36','2020-07-04 13:19:21','2020-07-04 13:21:56'),(8,'Plateltes',1,1,NULL,'5','/Cmm','150000 - 400000','150000 - 400000','400000','150000','2020-07-04 13:19:21','2020-07-04 13:21:56'),(9,'MPV',1,1,NULL,'5','fl^3','9 - 11.9','9 - 11.9','11.9','9','2020-07-04 13:19:21','2020-07-04 13:21:56'),(10,'PDW',1,1,NULL,'54','fL','9.9','15.4','15.4','9.9','2020-07-04 13:19:21','2020-07-04 13:21:56'),(11,'P-LCR',1,1,NULL,'5454','%','17.5 - 42.3','17.5 - 42.3','42.3','17.5','2020-07-04 13:19:21','2020-07-04 13:21:56'),(12,'MCH',1,1,NULL,'5','%','27 - 32','27 - 32','32','27','2020-07-04 13:19:21','2020-07-04 13:21:56'),(13,'MCHC',1,1,NULL,'54','%','33 - 35','33 - 35','35','33','2020-07-04 13:19:21','2020-07-04 13:21:56'),(14,'Neutrophils',1,3,NULL,'45','%','43-74','43-74','74','43','2020-07-04 13:19:21','2020-07-04 13:21:56'),(15,'Lymphocytes',1,3,NULL,'54','%','18-46','18-46','46','18','2020-07-04 13:19:21','2020-07-04 13:21:56'),(16,'Monocytes',1,3,NULL,'54','%','3-8','3-8','8','3','2020-07-04 13:19:21','2020-07-04 13:21:56'),(17,'Eosinophils',1,3,NULL,'54','%','1-5','1-5','5','1','2020-07-04 13:19:21','2020-07-04 13:21:56'),(18,'HAEMOGLOBIN (HB)',2,6,NULL,'2','g/dl','14 - 18','11 - 16','16','11','2020-07-04 14:05:51','2020-07-04 14:06:29'),(19,'HCT',2,6,NULL,'2','%','40 - 49','36 - 46','46','36','2020-07-04 14:05:51','2020-07-04 14:06:29'),(20,'WBC (TLC)',2,6,NULL,'22','g/dl','3.8 - 11','3.8 - 11','11','3.8','2020-07-04 14:05:51','2020-07-04 14:06:29'),(21,'Plateltes',2,6,NULL,'2','/Cmm','150000 - 400000','150000 - 400000','400000','150000','2020-07-04 14:05:51','2020-07-04 14:06:29'),(22,'H-pylori',3,8,NULL,'Negative',NULL,NULL,NULL,NULL,NULL,'2020-07-07 16:26:34','2020-07-07 16:26:34'),(23,'Blood Sugar (Random)',4,9,NULL,'145','mg/dl','upto 160','upto 160',NULL,NULL,'2020-07-07 16:41:21','2020-07-07 16:42:20'),(24,'Blood Sugar (Fasting)',4,9,NULL,NULL,'mg/dl','55 - 115','55 - 115','115','55','2020-07-07 16:41:21','2020-07-07 16:41:21'),(25,'HEMOGLOBIN (HB)',5,1,NULL,'10.4','d/dl','14 - 18','11 - 16','16','11.5','2020-07-07 18:15:53','2020-07-07 18:35:20'),(26,'WBC (TLC)',5,1,NULL,'7.5','x10 /ul','3.8 - 11','3.8 - 11','11','3.8','2020-07-07 18:15:53','2020-07-07 18:35:20'),(27,'TOTAL RBC',5,1,NULL,'5.24','Millo/Cmm','4.5 - 6.0','4.0 - 5.5','5.5','4.0','2020-07-07 18:15:53','2020-07-07 18:35:20'),(28,'MCV',5,1,NULL,'65','fl','80 - 96','76 - 96','96','76','2020-07-07 18:15:53','2020-07-07 18:35:20'),(29,'RDW - CV',5,1,NULL,'15','%','12 - 14','12 - 14','14','12','2020-07-07 18:15:53','2020-07-07 18:35:20'),(30,'RDW - SD',5,1,NULL,'37','fl^3','37 - 47','37 - 47','47','37','2020-07-07 18:15:53','2020-07-07 18:35:20'),(31,'HCT',5,1,NULL,'34','%','40 - 49','36 - 46','46','36','2020-07-07 18:15:53','2020-07-07 18:35:20'),(32,'Plateltes',5,1,NULL,'449000','/Cmm','150000 - 400000','150000 - 400000','400000','150000','2020-07-07 18:15:53','2020-07-07 18:35:20'),(33,'MPV',5,1,NULL,'8.6','fl^3','9 - 11.9','9 - 11.9','11.9','9','2020-07-07 18:15:53','2020-07-07 18:35:20'),(34,'PDW',5,1,NULL,'9.8','fL','9.9','15.4','15.4','9.9','2020-07-07 18:15:53','2020-07-07 18:35:20'),(35,'P-LCR',5,1,NULL,'15.3','%','17.5 - 42.3','17.5 - 42.3','42.3','17.5','2020-07-07 18:15:53','2020-07-07 18:35:20'),(36,'MCH',5,1,NULL,'19','%','27 - 32','27 - 32','32','27','2020-07-07 18:15:53','2020-07-07 18:35:20'),(37,'MCHC',5,1,NULL,'3','%','33 - 35','33 - 35','35','33','2020-07-07 18:15:53','2020-07-07 18:35:20'),(38,'Neutrophils',5,3,NULL,'70','%','43-74','43-74','74','43','2020-07-07 18:15:53','2020-07-07 18:35:20'),(39,'Lymphocytes',5,3,NULL,'25','%','18-46','18-46','46','18','2020-07-07 18:15:53','2020-07-07 18:35:20'),(40,'Monocytes',5,3,NULL,'03','%','3-8','3-8','8','3','2020-07-07 18:15:53','2020-07-07 18:35:20'),(41,'Eosinophils',5,3,NULL,'02','%','1-5','1-5','5','1','2020-07-07 18:15:53','2020-07-07 18:35:20'),(43,'Cholesterol',7,64,NULL,'15','mg/dl',NULL,NULL,NULL,NULL,'2020-07-08 16:25:20','2020-07-08 16:25:59'),(44,NULL,7,64,NULL,'-  Without Known Cornorary Artery Disease Less Than   Or Equal to 200: DESIRABLE.-  With Known Coronary Artery Disease Less Than    Or Equal to 160: OPTIMAL',NULL,NULL,NULL,NULL,NULL,'2020-07-08 16:25:20','2020-07-08 16:25:59'),(45,'HEMOGLOBIN (HB)',8,1,NULL,'25','d/dl','14 - 18','11 - 16','16','11.5','2020-07-09 14:10:09','2020-07-09 23:03:38'),(46,'WBC (TLC)',8,1,NULL,'566','x10 /ul','3.8 - 11','3.8 - 11','11','3.8','2020-07-09 14:10:09','2020-07-09 23:03:38'),(47,'TOTAL RBC',8,1,NULL,'52','Millo/Cmm','4.5 - 6.0','4.0 - 5.5','5.5','4.0','2020-07-09 14:10:09','2020-07-09 23:03:38'),(48,'MCV',8,1,NULL,NULL,'fl','80 - 96','76 - 96','96','76','2020-07-09 14:10:09','2020-07-09 14:10:09'),(49,'RDW - CV',8,1,NULL,'5','%','12 - 14','12 - 14','14','12','2020-07-09 14:10:09','2020-07-09 23:03:38'),(50,'RDW - SD',8,1,NULL,'23','fl^3','37 - 47','37 - 47','47','37','2020-07-09 14:10:09','2020-07-09 23:03:38'),(51,'HCT',8,1,NULL,NULL,'%','40 - 49','36 - 46','46','36','2020-07-09 14:10:09','2020-07-09 14:10:09'),(52,'Plateltes',8,1,NULL,'22','/Cmm','150000 - 400000','150000 - 400000','400000','150000','2020-07-09 14:10:09','2020-07-09 23:03:38'),(53,'MPV',8,1,NULL,'22','fl^3','9 - 11.9','9 - 11.9','11.9','9','2020-07-09 14:10:09','2020-07-09 23:03:38'),(54,'PDW',8,1,NULL,'222','fL','9.9','15.4','15.4','9.9','2020-07-09 14:10:09','2020-07-09 23:03:38'),(55,'P-LCR',8,1,NULL,'5','%','17.5 - 42.3','17.5 - 42.3','42.3','17.5','2020-07-09 14:10:09','2020-07-09 23:03:38'),(56,'MCH',8,1,NULL,NULL,'%','27 - 32','27 - 32','32','27','2020-07-09 14:10:09','2020-07-09 14:10:09'),(57,'MCHC',8,1,NULL,'5','%','33 - 35','33 - 35','35','33','2020-07-09 14:10:09','2020-07-09 23:03:38'),(58,'Neutrophils',8,3,NULL,'525','%','43-74','43-74','74','43','2020-07-09 14:10:09','2020-07-09 23:03:38'),(59,'Lymphocytes',8,3,NULL,'552','%','18-46','18-46','46','18','2020-07-09 14:10:09','2020-07-09 23:03:38'),(60,'Monocytes',8,3,NULL,'55','%','3-8','3-8','8','3','2020-07-09 14:10:09','2020-07-09 23:03:38'),(61,'Eosinophils',8,3,NULL,'52','%','1-5','1-5','5','1','2020-07-09 14:10:09','2020-07-09 23:03:38'),(62,'HEMOGLOBIN (HB)',9,1,NULL,NULL,'d/dl','14 - 18','11 - 16','16','11.5','2020-07-09 23:02:43','2020-07-09 23:02:43'),(63,'WBC (TLC)',9,1,NULL,NULL,'x10 /ul','3.8 - 11','3.8 - 11','11','3.8','2020-07-09 23:02:43','2020-07-09 23:02:43'),(64,'TOTAL RBC',9,1,NULL,NULL,'Millo/Cmm','4.5 - 6.0','4.0 - 5.5','5.5','4.0','2020-07-09 23:02:43','2020-07-09 23:02:43'),(65,'MCV',9,1,NULL,NULL,'fl','80 - 96','76 - 96','96','76','2020-07-09 23:02:43','2020-07-09 23:02:43'),(66,'RDW - CV',9,1,NULL,NULL,'%','12 - 14','12 - 14','14','12','2020-07-09 23:02:43','2020-07-09 23:02:43'),(67,'RDW - SD',9,1,NULL,NULL,'fl^3','37 - 47','37 - 47','47','37','2020-07-09 23:02:43','2020-07-09 23:02:43'),(68,'HCT',9,1,NULL,NULL,'%','40 - 49','36 - 46','46','36','2020-07-09 23:02:43','2020-07-09 23:02:43'),(69,'Plateltes',9,1,NULL,NULL,'/Cmm','150000 - 400000','150000 - 400000','400000','150000','2020-07-09 23:02:43','2020-07-09 23:02:43'),(70,'MPV',9,1,NULL,NULL,'fl^3','9 - 11.9','9 - 11.9','11.9','9','2020-07-09 23:02:43','2020-07-09 23:02:43'),(71,'PDW',9,1,NULL,NULL,'fL','9.9','15.4','15.4','9.9','2020-07-09 23:02:43','2020-07-09 23:02:43'),(72,'P-LCR',9,1,NULL,NULL,'%','17.5 - 42.3','17.5 - 42.3','42.3','17.5','2020-07-09 23:02:43','2020-07-09 23:02:43'),(73,'MCH',9,1,NULL,NULL,'%','27 - 32','27 - 32','32','27','2020-07-09 23:02:43','2020-07-09 23:02:43'),(74,'MCHC',9,1,NULL,NULL,'%','33 - 35','33 - 35','35','33','2020-07-09 23:02:43','2020-07-09 23:02:43'),(75,'Neutrophils',9,3,NULL,NULL,'%','43-74','43-74','74','43','2020-07-09 23:02:43','2020-07-09 23:02:43'),(76,'Lymphocytes',9,3,NULL,NULL,'%','18-46','18-46','46','18','2020-07-09 23:02:43','2020-07-09 23:02:43'),(77,'Monocytes',9,3,NULL,NULL,'%','3-8','3-8','8','3','2020-07-09 23:02:43','2020-07-09 23:02:43'),(78,'Eosinophils',9,3,NULL,NULL,'%','1-5','1-5','5','1','2020-07-09 23:02:43','2020-07-09 23:02:43'),(79,'S.Typhi (O):',10,82,NULL,'+','+','+','+','-','-','2020-07-10 17:02:50','2020-07-10 17:16:56'),(80,'S.Typhi (H):',10,82,NULL,'-','-','-','-','-','-','2020-07-10 17:02:50','2020-07-10 17:02:50'),(81,'S.P. Typhi (AO):',10,82,NULL,'-','-','-','-','-','-','2020-07-10 17:02:50','2020-07-10 17:02:50'),(82,'S.P. Typhi (AH):',10,82,NULL,'-','-','-','-','-','-','2020-07-10 17:02:50','2020-07-10 17:02:50'),(83,'S.P. Typhi (BO):',10,82,NULL,'-','-','-','-','-','-','2020-07-10 17:02:50','2020-07-10 17:02:50'),(84,'S.P. Typhi (BH):',10,82,NULL,'-','-','-','-','-','-','2020-07-10 17:02:50','2020-07-10 17:02:50'),(85,'Brucella Abortus:',11,90,NULL,'+','+','+','+','-','-','2020-07-10 19:41:12','2020-07-10 19:47:40'),(86,'Brucella Melitensis:',11,90,NULL,'-','-','-','-','-','-','2020-07-10 19:41:12','2020-07-10 19:41:12'),(87,'HEMOGLOBIN (HB)',12,1,NULL,'55.2','d/dl','14 - 18','11 - 16','16','11.5','2020-07-10 19:49:04','2020-07-10 19:50:09'),(88,'WBC (TLC)',12,1,NULL,'2','x10 /ul','3.8 - 11','3.8 - 11','11','3.8','2020-07-10 19:49:04','2020-07-10 19:50:09'),(89,'TOTAL RBC',12,1,NULL,'2','Millo/Cmm','4.5 - 6.0','4.0 - 5.5','5.5','4.0','2020-07-10 19:49:04','2020-07-10 19:50:09'),(90,'MCV',12,1,NULL,'22','fl','80 - 96','76 - 96','96','76','2020-07-10 19:49:04','2020-07-10 19:50:09'),(91,'RDW - CV',12,1,NULL,'23','%','12 - 14','12 - 14','14','12','2020-07-10 19:49:04','2020-07-10 19:50:09'),(92,'RDW - SD',12,1,NULL,'1','fl^3','37 - 47','37 - 47','47','37','2020-07-10 19:49:04','2020-07-10 19:50:09'),(93,'HCT',12,1,NULL,'33','%','40 - 49','36 - 46','46','36','2020-07-10 19:49:04','2020-07-10 19:50:09'),(94,'Plateltes',12,1,NULL,'23290','/Cmm','150000 - 400000','150000 - 400000','400000','150000','2020-07-10 19:49:04','2020-07-10 19:50:09'),(95,'MPV',12,1,NULL,'333','fl^3','9 - 11.9','9 - 11.9','11.9','9','2020-07-10 19:49:04','2020-07-10 19:50:09'),(96,'PDW',12,1,NULL,'3','fL','9.9','15.4','15.4','9.9','2020-07-10 19:49:04','2020-07-10 19:50:09'),(97,'P-LCR',12,1,NULL,'3','%','17.5 - 42.3','17.5 - 42.3','42.3','17.5','2020-07-10 19:49:04','2020-07-10 19:50:09'),(98,'MCH',12,1,NULL,'3','%','27 - 32','27 - 32','32','27','2020-07-10 19:49:04','2020-07-10 19:50:09'),(99,'MCHC',12,1,NULL,'4','%','33 - 35','33 - 35','35','33','2020-07-10 19:49:04','2020-07-10 19:50:09'),(100,'Neutrophils',12,3,NULL,'60','%','43-74','43-74','74','43','2020-07-10 19:49:04','2020-07-10 19:50:09'),(101,'Lymphocytes',12,3,NULL,'30','%','18-46','18-46','46','18','2020-07-10 19:49:04','2020-07-10 19:50:09'),(102,'Monocytes',12,3,NULL,'06','%','3-8','3-8','8','3','2020-07-10 19:49:04','2020-07-10 19:50:09'),(103,'Eosinophils',12,3,NULL,'04','%','1-5','1-5','5','1','2020-07-10 19:49:04','2020-07-10 19:50:09'),(104,'Color',13,2,NULL,'pale Yellow',NULL,'pale Yellow','pale Yellow',NULL,NULL,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(105,'Appearance',13,2,NULL,'Clear',NULL,'Clear','Clear',NULL,NULL,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(106,'Sp.Gravity',13,2,NULL,'1.025',NULL,'1.005 - 1.025','1.005 - 1.025',NULL,NULL,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(107,'pH',13,4,NULL,'7.0',NULL,'5.0 - 7.5','5.0 - 7.5',NULL,NULL,'2020-07-10 19:49:04','2020-07-10 19:51:29'),(108,'Glucose',13,4,NULL,'++',NULL,'Nil','Nil',NULL,NULL,'2020-07-10 19:49:04','2020-07-10 19:51:29'),(109,'Protein',13,4,NULL,'Nil',NULL,'Nil','Nil',NULL,NULL,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(110,'Ketone',13,4,NULL,'Nil',NULL,'Nil','Nil',NULL,NULL,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(111,'Urobilinogen',13,4,NULL,'Normal',NULL,'< 1mg/dl','< 1mg/dl',NULL,NULL,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(112,'Bilirubin',13,4,NULL,'Nil',NULL,'Nil','Nil',NULL,NULL,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(113,'Blood',13,4,NULL,'+',NULL,'Nil','Nil',NULL,NULL,'2020-07-10 19:49:04','2020-07-10 19:51:29'),(114,'Leucocytes',13,4,NULL,'+',NULL,'Negative','Negative',NULL,NULL,'2020-07-10 19:49:04','2020-07-10 19:51:29'),(115,'Nitrite',13,4,NULL,'Negative',NULL,'Negative','Negative',NULL,NULL,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(116,'Pus Cells',13,5,NULL,'4 - 6','/HPF','0 - 2','0 - 2',NULL,NULL,'2020-07-10 19:49:04','2020-07-10 19:51:29'),(117,'Epithelial Cell',13,5,NULL,'3 - 5','/HPF',NULL,'0 - 5',NULL,NULL,'2020-07-10 19:49:04','2020-07-10 19:51:29'),(118,'RBC',13,5,NULL,'2 - 4','/HPF','0 - 2','0 - 2',NULL,NULL,'2020-07-10 19:49:04','2020-07-10 19:51:29'),(119,'Crystals',13,5,NULL,'Nil','/HPF','Nil','Nil',NULL,NULL,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(120,'Casts',13,5,NULL,'Nil','/HPF','Nil','Nil',NULL,NULL,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(121,'SGPT',14,7,NULL,'2','u/l','05 - 42','05 - 42','42','5','2020-07-10 19:49:04','2020-07-10 19:52:15'),(122,'SGPT',15,7,NULL,'25','u/l','05 - 42','05 - 42','42','5','2020-07-10 19:57:41','2020-07-10 19:59:13'),(123,'S.Typhi (O):',16,82,NULL,'+','+','+','+','-','-','2020-07-10 19:57:41','2020-07-10 19:58:52'),(124,'S.Typhi (H):',16,82,NULL,'-','-','-','-','-','-','2020-07-10 19:57:41','2020-07-10 19:57:41'),(125,'S.P. Typhi (AO):',16,82,NULL,'-','-','-','-','-','-','2020-07-10 19:57:41','2020-07-10 19:57:41'),(126,'S.P. Typhi (AH):',16,82,NULL,'-','-','-','-','-','-','2020-07-10 19:57:41','2020-07-10 19:57:41'),(127,'S.P. Typhi (BO):',16,82,NULL,'-','-','-','-','-','-','2020-07-10 19:57:41','2020-07-10 19:57:41'),(128,'S.P. Typhi (BH):',16,82,NULL,'-','-','-','-','-','-','2020-07-10 19:57:41','2020-07-10 19:57:41'),(129,'HEMOGLOBIN (HB)',17,1,NULL,'2','d/dl','14 - 18','11 - 16','16','11.5','2020-07-10 20:24:52','2020-07-10 20:25:47'),(130,'WBC (TLC)',17,1,NULL,'2','x10 /ul','3.8 - 11','3.8 - 11','11','3.8','2020-07-10 20:24:52','2020-07-10 20:25:47'),(131,'TOTAL RBC',17,1,NULL,'2','Millo/Cmm','4.5 - 6.0','4.0 - 5.5','5.5','4.0','2020-07-10 20:24:52','2020-07-10 20:25:47'),(132,'MCV',17,1,NULL,'222','fl','80 - 96','76 - 96','96','76','2020-07-10 20:24:52','2020-07-10 20:25:47'),(133,'RDW - CV',17,1,NULL,'222','%','12 - 14','12 - 14','14','12','2020-07-10 20:24:52','2020-07-10 20:25:47'),(134,'RDW - SD',17,1,NULL,'22','fl^3','37 - 47','37 - 47','47','37','2020-07-10 20:24:52','2020-07-10 20:25:47'),(135,'HCT',17,1,NULL,'22','%','40 - 49','36 - 46','46','36','2020-07-10 20:24:52','2020-07-10 20:25:47'),(136,'Plateltes',17,1,NULL,'22','/Cmm','150000 - 400000','150000 - 400000','400000','150000','2020-07-10 20:24:52','2020-07-10 20:25:47'),(137,'MPV',17,1,NULL,'2','fl^3','9 - 11.9','9 - 11.9','11.9','9','2020-07-10 20:24:52','2020-07-10 20:25:47'),(138,'PDW',17,1,NULL,'23','fL','9.9','15.4','15.4','9.9','2020-07-10 20:24:52','2020-07-10 20:25:47'),(139,'P-LCR',17,1,NULL,'3','%','17.5 - 42.3','17.5 - 42.3','42.3','17.5','2020-07-10 20:24:52','2020-07-10 20:25:47'),(140,'MCH',17,1,NULL,'3','%','27 - 32','27 - 32','32','27','2020-07-10 20:24:52','2020-07-10 20:25:47'),(141,'MCHC',17,1,NULL,'23','%','33 - 35','33 - 35','35','33','2020-07-10 20:24:52','2020-07-10 20:25:47'),(142,'Neutrophils',17,3,NULL,'25','%','43-74','43-74','74','43','2020-07-10 20:24:52','2020-07-10 20:25:47'),(143,'Lymphocytes',17,3,NULL,'25','%','18-46','18-46','46','18','2020-07-10 20:24:52','2020-07-10 20:25:47'),(144,'Monocytes',17,3,NULL,'52','%','3-8','3-8','8','3','2020-07-10 20:24:52','2020-07-10 20:25:47'),(145,'Eosinophils',17,3,NULL,'25','%','1-5','1-5','5','1','2020-07-10 20:24:52','2020-07-10 20:25:47'),(146,'S.Typhi (O):',18,82,NULL,'+','+','+','+','-','-','2020-07-10 20:24:52','2020-07-10 20:26:25'),(147,'S.Typhi (H):',18,82,NULL,'-','-','-','-','-','-','2020-07-10 20:24:52','2020-07-10 20:24:52'),(148,'S.P. Typhi (AO):',18,82,NULL,'-','-','-','-','-','-','2020-07-10 20:24:52','2020-07-10 20:24:52'),(149,'S.P. Typhi (AH):',18,82,NULL,'-','-','-','-','-','-','2020-07-10 20:24:52','2020-07-10 20:24:52'),(150,'S.P. Typhi (BO):',18,82,NULL,'-','-','-','-','-','-','2020-07-10 20:24:52','2020-07-10 20:24:52'),(151,'S.P. Typhi (BH):',18,82,NULL,'-','-','-','-','-','-','2020-07-10 20:24:52','2020-07-10 20:24:52');
/*!40000 ALTER TABLE `report_test_particulars` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `res_product_modifier_sets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `res_product_modifier_sets` (
  `modifier_set_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL COMMENT 'Table use to store the modifier sets applicable for a product',
  KEY `res_product_modifier_sets_modifier_set_id_foreign` (`modifier_set_id`),
  CONSTRAINT `res_product_modifier_sets_modifier_set_id_foreign` FOREIGN KEY (`modifier_set_id`) REFERENCES `products` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `res_product_modifier_sets` WRITE;
/*!40000 ALTER TABLE `res_product_modifier_sets` DISABLE KEYS */;
/*!40000 ALTER TABLE `res_product_modifier_sets` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `res_tables`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `res_tables` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `location_id` int(10) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `res_tables_business_id_foreign` (`business_id`),
  CONSTRAINT `res_tables_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `res_tables` WRITE;
/*!40000 ALTER TABLE `res_tables` DISABLE KEYS */;
/*!40000 ALTER TABLE `res_tables` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `role_has_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `role_has_permissions` (
  `permission_id` int(10) unsigned NOT NULL,
  `role_id` int(10) unsigned NOT NULL,
  PRIMARY KEY (`permission_id`,`role_id`),
  KEY `role_has_permissions_role_id_foreign` (`role_id`),
  CONSTRAINT `role_has_permissions_permission_id_foreign` FOREIGN KEY (`permission_id`) REFERENCES `permissions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `role_has_permissions_role_id_foreign` FOREIGN KEY (`role_id`) REFERENCES `roles` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `role_has_permissions` WRITE;
/*!40000 ALTER TABLE `role_has_permissions` DISABLE KEYS */;
INSERT INTO `role_has_permissions` VALUES (191,2),(192,2),(193,2),(194,2),(223,2);
/*!40000 ALTER TABLE `role_has_permissions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `roles`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `roles` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `guard_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `business_id` int(10) unsigned NOT NULL,
  `is_default` tinyint(1) NOT NULL DEFAULT 0,
  `is_service_staff` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `roles_business_id_foreign` (`business_id`),
  CONSTRAINT `roles_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `roles` WRITE;
/*!40000 ALTER TABLE `roles` DISABLE KEYS */;
INSERT INTO `roles` VALUES (1,'Admin#1','web',1,1,0,'2020-07-04 12:23:41','2020-07-04 12:23:41'),(2,'Cashier#1','web',1,0,0,'2020-07-04 12:23:41','2020-07-04 12:23:41');
/*!40000 ALTER TABLE `roles` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `schedules`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `schedules` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `doctor_id` int(10) unsigned NOT NULL,
  `start_time` time NOT NULL,
  `end_time` time NOT NULL,
  `day` int(11) NOT NULL,
  `per_patient_time` int(11) NOT NULL,
  `visibility` tinyint(1) NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `schedules_business_id_foreign` (`business_id`),
  KEY `schedules_doctor_id_foreign` (`doctor_id`),
  CONSTRAINT `schedules_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `schedules_doctor_id_foreign` FOREIGN KEY (`doctor_id`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `schedules` WRITE;
/*!40000 ALTER TABLE `schedules` DISABLE KEYS */;
/*!40000 ALTER TABLE `schedules` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sell_line_warranties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sell_line_warranties` (
  `sell_line_id` int(11) NOT NULL,
  `warranty_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sell_line_warranties` WRITE;
/*!40000 ALTER TABLE `sell_line_warranties` DISABLE KEYS */;
/*!40000 ALTER TABLE `sell_line_warranties` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `selling_price_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `selling_price_groups` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `business_id` int(10) unsigned NOT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `selling_price_groups_business_id_foreign` (`business_id`),
  CONSTRAINT `selling_price_groups_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `selling_price_groups` WRITE;
/*!40000 ALTER TABLE `selling_price_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `selling_price_groups` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `sessions` (
  `id` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `user_id` int(10) unsigned DEFAULT NULL,
  `ip_address` varchar(45) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `user_agent` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payload` text COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_activity` int(11) NOT NULL,
  UNIQUE KEY `sessions_id_unique` (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `stock_adjustment_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_adjustment_lines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `variation_id` int(10) unsigned NOT NULL,
  `quantity` decimal(22,4) NOT NULL,
  `unit_price` decimal(22,4) DEFAULT NULL COMMENT 'Last purchase unit price',
  `removed_purchase_line` int(11) DEFAULT NULL,
  `lot_no_line_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `stock_adjustment_lines_product_id_foreign` (`product_id`),
  KEY `stock_adjustment_lines_variation_id_foreign` (`variation_id`),
  KEY `stock_adjustment_lines_transaction_id_index` (`transaction_id`),
  CONSTRAINT `stock_adjustment_lines_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `stock_adjustment_lines_transaction_id_foreign` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `stock_adjustment_lines_variation_id_foreign` FOREIGN KEY (`variation_id`) REFERENCES `variations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `stock_adjustment_lines` WRITE;
/*!40000 ALTER TABLE `stock_adjustment_lines` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock_adjustment_lines` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `stock_adjustments_temp`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `stock_adjustments_temp` (
  `id` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `stock_adjustments_temp` WRITE;
/*!40000 ALTER TABLE `stock_adjustments_temp` DISABLE KEYS */;
/*!40000 ALTER TABLE `stock_adjustments_temp` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `system`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `system` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `key` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `value` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `system` WRITE;
/*!40000 ALTER TABLE `system` DISABLE KEYS */;
INSERT INTO `system` VALUES (1,'db_version','3.3'),(2,'default_business_active_status','1'),(3,'essentials_version','2.1');
/*!40000 ALTER TABLE `system` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tax_rates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tax_rates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `amount` double(22,4) NOT NULL,
  `is_tax_group` tinyint(1) NOT NULL DEFAULT 0,
  `created_by` int(10) unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tax_rates_business_id_foreign` (`business_id`),
  KEY `tax_rates_created_by_foreign` (`created_by`),
  CONSTRAINT `tax_rates_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tax_rates_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tax_rates` WRITE;
/*!40000 ALTER TABLE `tax_rates` DISABLE KEYS */;
/*!40000 ALTER TABLE `tax_rates` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `test_heads`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test_heads` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `test_id` int(10) unsigned NOT NULL,
  `report_head_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `test_heads_test_id_foreign` (`test_id`),
  KEY `test_heads_report_head_id_foreign` (`report_head_id`),
  CONSTRAINT `test_heads_report_head_id_foreign` FOREIGN KEY (`report_head_id`) REFERENCES `report_heads` (`id`) ON DELETE CASCADE,
  CONSTRAINT `test_heads_test_id_foreign` FOREIGN KEY (`test_id`) REFERENCES `tests` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=133 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `test_heads` WRITE;
/*!40000 ALTER TABLE `test_heads` DISABLE KEYS */;
INSERT INTO `test_heads` VALUES (15,7,11,'2020-07-07 16:23:03','2020-07-07 16:23:03'),(17,5,8,'2020-07-07 16:31:36','2020-07-07 16:31:36'),(18,4,7,'2020-07-07 16:34:20','2020-07-07 16:34:20'),(19,2,6,'2020-07-07 16:36:03','2020-07-07 16:36:03'),(20,1,1,'2020-07-07 16:37:56','2020-07-07 16:37:56'),(21,1,3,'2020-07-07 16:37:56','2020-07-07 16:37:56'),(22,6,9,'2020-07-07 16:40:22','2020-07-07 16:40:22'),(24,8,12,'2020-07-07 16:54:01','2020-07-07 16:54:01'),(28,9,13,'2020-07-07 17:08:00','2020-07-07 17:08:00'),(29,10,14,'2020-07-07 17:12:01','2020-07-07 17:12:01'),(33,3,2,'2020-07-07 17:30:11','2020-07-07 17:30:11'),(34,3,4,'2020-07-07 17:30:11','2020-07-07 17:30:11'),(35,3,5,'2020-07-07 17:30:11','2020-07-07 17:30:11'),(40,14,19,'2020-07-08 01:16:34','2020-07-08 01:16:34'),(41,15,18,'2020-07-08 01:20:58','2020-07-08 01:20:58'),(42,16,20,'2020-07-08 01:23:18','2020-07-08 01:23:18'),(43,17,21,'2020-07-08 01:25:21','2020-07-08 01:25:21'),(44,18,22,'2020-07-08 03:03:25','2020-07-08 03:03:25'),(45,19,23,'2020-07-08 03:09:59','2020-07-08 03:09:59'),(46,20,24,'2020-07-08 03:12:45','2020-07-08 03:12:45'),(47,21,25,'2020-07-08 03:15:37','2020-07-08 03:15:37'),(48,22,26,'2020-07-08 03:18:56','2020-07-08 03:18:56'),(49,23,27,'2020-07-08 03:25:30','2020-07-08 03:25:30'),(50,24,28,'2020-07-08 03:31:50','2020-07-08 03:31:50'),(52,26,30,'2020-07-08 03:35:50','2020-07-08 03:35:50'),(53,27,31,'2020-07-08 03:52:36','2020-07-08 03:52:36'),(54,28,32,'2020-07-08 03:54:44','2020-07-08 03:54:44'),(55,29,33,'2020-07-08 03:57:04','2020-07-08 03:57:04'),(56,30,34,'2020-07-08 03:58:35','2020-07-08 03:58:35'),(57,31,35,'2020-07-08 04:00:06','2020-07-08 04:00:06'),(58,32,36,'2020-07-08 04:02:39','2020-07-08 04:02:39'),(59,33,37,'2020-07-08 04:05:51','2020-07-08 04:05:51'),(60,34,38,'2020-07-08 04:07:32','2020-07-08 04:07:32'),(61,35,38,'2020-07-08 04:11:30','2020-07-08 04:11:30'),(62,36,40,'2020-07-08 04:13:36','2020-07-08 04:13:36'),(63,37,41,'2020-07-08 04:29:05','2020-07-08 04:29:05'),(64,37,42,'2020-07-08 04:29:05','2020-07-08 04:29:05'),(65,37,43,'2020-07-08 04:29:05','2020-07-08 04:29:05'),(66,37,44,'2020-07-08 04:29:05','2020-07-08 04:29:05'),(67,38,45,'2020-07-08 04:31:35','2020-07-08 04:31:35'),(68,39,46,'2020-07-08 04:34:22','2020-07-08 04:34:22'),(69,40,47,'2020-07-08 04:36:23','2020-07-08 04:36:23'),(70,41,48,'2020-07-08 04:40:48','2020-07-08 04:40:48'),(71,42,49,'2020-07-08 04:49:25','2020-07-08 04:49:25'),(72,43,50,'2020-07-08 04:51:26','2020-07-08 04:51:26'),(73,44,51,'2020-07-08 04:53:54','2020-07-08 04:53:54'),(75,46,53,'2020-07-08 05:02:44','2020-07-08 05:02:44'),(76,47,54,'2020-07-08 15:08:34','2020-07-08 15:08:34'),(77,48,55,'2020-07-08 15:10:46','2020-07-08 15:10:46'),(78,49,56,'2020-07-08 15:12:42','2020-07-08 15:12:42'),(79,50,57,'2020-07-08 15:15:19','2020-07-08 15:15:19'),(80,51,58,'2020-07-08 15:17:47','2020-07-08 15:17:47'),(81,52,59,'2020-07-08 15:21:35','2020-07-08 15:21:35'),(82,53,60,'2020-07-08 15:43:55','2020-07-08 15:43:55'),(83,54,61,'2020-07-08 15:45:57','2020-07-08 15:45:57'),(84,55,62,'2020-07-08 15:52:02','2020-07-08 15:52:02'),(85,56,63,'2020-07-08 15:55:27','2020-07-08 15:55:27'),(86,57,64,'2020-07-08 15:59:15','2020-07-08 15:59:15'),(87,59,67,'2020-07-08 20:36:04','2020-07-08 20:36:04'),(88,60,68,'2020-07-08 20:40:09','2020-07-08 20:40:09'),(89,62,70,'2020-07-08 20:58:32','2020-07-08 20:58:32'),(90,63,71,'2020-07-08 21:01:24','2020-07-08 21:01:24'),(91,64,72,'2020-07-08 21:04:24','2020-07-08 21:04:24'),(95,67,10,'2020-07-10 16:21:27','2020-07-10 16:21:27'),(96,67,75,'2020-07-10 16:21:27','2020-07-10 16:21:27'),(98,68,78,'2020-07-10 16:38:18','2020-07-10 16:38:18'),(99,69,76,'2020-07-10 16:39:34','2020-07-10 16:39:34'),(100,69,77,'2020-07-10 16:39:34','2020-07-10 16:39:34'),(101,69,79,'2020-07-10 16:39:34','2020-07-10 16:39:34'),(102,69,80,'2020-07-10 16:39:34','2020-07-10 16:39:34'),(104,72,82,'2020-07-10 16:58:39','2020-07-10 16:58:39'),(109,11,15,'2020-07-10 17:39:05','2020-07-10 17:39:05'),(117,65,74,'2020-07-10 18:32:22','2020-07-10 18:32:22'),(118,79,88,'2020-07-10 18:34:01','2020-07-10 18:34:01'),(119,73,83,'2020-07-10 18:34:35','2020-07-10 18:34:35'),(120,71,81,'2020-07-10 18:34:58','2020-07-10 18:34:58'),(121,25,29,'2020-07-10 18:51:39','2020-07-10 18:51:39'),(122,45,52,'2020-07-10 19:01:28','2020-07-10 19:01:28'),(123,80,89,'2020-07-10 19:02:05','2020-07-10 19:02:05'),(124,78,87,'2020-07-10 19:02:47','2020-07-10 19:02:47'),(125,76,85,'2020-07-10 19:03:30','2020-07-10 19:03:30'),(126,75,36,'2020-07-10 19:04:10','2020-07-10 19:04:10'),(127,77,86,'2020-07-10 19:04:45','2020-07-10 19:04:45'),(128,12,16,'2020-07-10 19:08:43','2020-07-10 19:08:43'),(129,13,17,'2020-07-10 19:10:51','2020-07-10 19:10:51'),(132,81,90,'2020-07-10 19:43:09','2020-07-10 19:43:09');
/*!40000 ALTER TABLE `test_heads` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `test_particulars`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test_particulars` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `report_head_id` int(10) unsigned NOT NULL,
  `name` varchar(250) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `result` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `unit` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `male` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `female` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `high_range` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `low_range` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `test_particulars_report_head_id_foreign` (`report_head_id`),
  CONSTRAINT `test_particulars_report_head_id_foreign` FOREIGN KEY (`report_head_id`) REFERENCES `report_heads` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=257 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `test_particulars` WRITE;
/*!40000 ALTER TABLE `test_particulars` DISABLE KEYS */;
INSERT INTO `test_particulars` VALUES (1,3,'Neutrophils',NULL,'%','43-74','43-74','74','43',NULL,'2020-07-04 12:48:51','2020-07-04 12:48:51'),(2,3,'Lymphocytes',NULL,'%','18-46','18-46','46','18',NULL,'2020-07-04 12:48:51','2020-07-04 12:48:51'),(3,3,'Monocytes',NULL,'%','3-8','3-8','8','3',NULL,'2020-07-04 12:48:51','2020-07-04 12:48:51'),(4,3,'Eosinophils',NULL,'%','1-5','1-5','5','1',NULL,'2020-07-04 12:48:51','2020-07-04 12:48:51'),(5,2,'Color','pale Yellow',NULL,'pale Yellow','pale Yellow',NULL,NULL,NULL,'2020-07-04 12:56:57','2020-07-04 12:56:57'),(6,2,'Appearance','Clear',NULL,'Clear','Clear',NULL,NULL,NULL,'2020-07-04 12:56:57','2020-07-04 12:56:57'),(7,2,'Sp.Gravity','1.025',NULL,'1.005 - 1.025','1.005 - 1.025',NULL,NULL,NULL,'2020-07-04 12:56:57','2020-07-04 12:56:57'),(8,1,'HEMOGLOBIN (HB)',NULL,'d/dl','14 - 18','11 - 16','16','11.5','2020-07-04 13:32:36','2020-07-04 13:03:20','2020-07-04 13:32:36'),(9,1,'WBC (TLC)',NULL,'x10 /ul','3.8 - 11','3.8 - 11','11','3.8','2020-07-04 13:32:36','2020-07-04 13:03:20','2020-07-04 13:32:36'),(10,1,'TOTAL RBC',NULL,'Millo/Cmm','4.5 - 6.0','4.0 - 5.5','5.5','4.0','2020-07-04 13:32:36','2020-07-04 13:03:20','2020-07-04 13:32:36'),(11,1,'MCV',NULL,'fl','80 - 96','76 - 96','96','76','2020-07-04 13:32:36','2020-07-04 13:03:20','2020-07-04 13:32:36'),(12,1,'RDW - CV',NULL,'%','12 - 14','12 - 14','14','12','2020-07-04 13:32:36','2020-07-04 13:03:20','2020-07-04 13:32:36'),(13,1,'RDW - SD',NULL,'fl^3','37 - 47','37 - 47','47','37','2020-07-04 13:32:36','2020-07-04 13:03:20','2020-07-04 13:32:36'),(14,1,'HCT',NULL,'%','40 - 49','36 - 46','46','36','2020-07-04 13:32:36','2020-07-04 13:03:20','2020-07-04 13:32:36'),(15,1,'Plateltes',NULL,'/Cmm','150000 - 400000','150000 - 400000','400000','150000','2020-07-04 13:32:36','2020-07-04 13:03:20','2020-07-04 13:32:36'),(16,1,'MPV',NULL,'fl^3','9 - 11.9','9 - 11.9','11.9','9','2020-07-04 13:32:36','2020-07-04 13:03:20','2020-07-04 13:32:36'),(17,1,'PDW',NULL,'fL','9.9','15.4','15.4','9.9','2020-07-04 13:32:36','2020-07-04 13:03:20','2020-07-04 13:32:36'),(18,1,'P-LCR',NULL,'%','17.5 - 42.3','17.5 - 42.3','42.3','17.5','2020-07-04 13:32:36','2020-07-04 13:03:20','2020-07-04 13:32:36'),(19,1,'MCH',NULL,'%','27 - 32','27 - 32','32','27','2020-07-04 13:32:36','2020-07-04 13:03:20','2020-07-04 13:32:36'),(20,1,'MCHC',NULL,'%','33 - 35','33 - 35','35','33','2020-07-04 13:32:36','2020-07-04 13:03:20','2020-07-04 13:32:36'),(21,4,'pH','6.0',NULL,'5.0 - 7.5','5.0 - 7.5',NULL,NULL,'2020-07-10 17:25:34','2020-07-04 13:03:50','2020-07-10 17:25:34'),(22,4,'Glucose','Nil',NULL,'Nil','Nil',NULL,NULL,'2020-07-10 17:25:34','2020-07-04 13:03:50','2020-07-10 17:25:34'),(23,4,'Protein','Nil',NULL,'Nil','Nil',NULL,NULL,'2020-07-10 17:25:34','2020-07-04 13:03:50','2020-07-10 17:25:34'),(24,4,'Ketone','Nil',NULL,'Nil','Nil',NULL,NULL,'2020-07-10 17:25:34','2020-07-04 13:03:50','2020-07-10 17:25:34'),(25,4,'Urobilinogen','Normal',NULL,'< 1mg/dl','< 1mg/dl',NULL,NULL,'2020-07-10 17:25:34','2020-07-04 13:03:50','2020-07-10 17:25:34'),(26,4,'Bilirubin','Nil',NULL,'Nil','Nil',NULL,NULL,'2020-07-10 17:25:34','2020-07-04 13:03:50','2020-07-10 17:25:34'),(27,4,'Blood','Nil',NULL,'Nil','Nil',NULL,NULL,'2020-07-10 17:25:34','2020-07-04 13:03:50','2020-07-10 17:25:34'),(28,4,'Leucocytes','Nil',NULL,'Negative','Negative',NULL,NULL,'2020-07-10 17:25:34','2020-07-04 13:03:50','2020-07-10 17:25:34'),(29,5,'Pus Cells','1 - 2','/HPF','0 - 2','0 - 2',NULL,NULL,'2020-07-04 13:24:47','2020-07-04 13:20:10','2020-07-04 13:24:47'),(30,5,'Pus Cells','1 - 2','/HPF','0 - 2','0 - 2',NULL,NULL,NULL,'2020-07-04 13:24:47','2020-07-04 13:24:47'),(31,5,'Epithelial Cell','0 - 1','/HPF',NULL,'0 - 5',NULL,NULL,NULL,'2020-07-04 13:24:47','2020-07-04 13:24:47'),(32,5,'RBC','1 - 2','/HPF','0 - 2','0 - 2',NULL,NULL,NULL,'2020-07-04 13:24:47','2020-07-04 13:24:47'),(33,5,'Crystals','Nil','/HPF','Nil','Nil',NULL,NULL,NULL,'2020-07-04 13:24:47','2020-07-04 13:24:47'),(34,5,'Casts','Nil','/HPF','Nil','Nil',NULL,NULL,NULL,'2020-07-04 13:24:47','2020-07-04 13:24:47'),(35,1,'HEMOGLOBIN (HB)',NULL,'d/dl','14 - 18','11 - 16','16','11.5',NULL,'2020-07-04 13:32:36','2020-07-04 13:32:36'),(36,1,'WBC (TLC)',NULL,'x10 /ul','3.8 - 11','3.8 - 11','11','3.8',NULL,'2020-07-04 13:32:36','2020-07-04 13:32:36'),(37,1,'TOTAL RBC',NULL,'Millo/Cmm','4.5 - 6.0','4.0 - 5.5','5.5','4.0',NULL,'2020-07-04 13:32:36','2020-07-04 13:32:36'),(38,1,'MCV',NULL,'fl','80 - 96','76 - 96','96','76',NULL,'2020-07-04 13:32:36','2020-07-04 13:32:36'),(39,1,'RDW - CV',NULL,'%','12 - 14','12 - 14','14','12',NULL,'2020-07-04 13:32:36','2020-07-04 13:32:36'),(40,1,'RDW - SD',NULL,'fl^3','37 - 47','37 - 47','47','37',NULL,'2020-07-04 13:32:36','2020-07-04 13:32:36'),(41,1,'HCT',NULL,'%','40 - 49','36 - 46','46','36',NULL,'2020-07-04 13:32:36','2020-07-04 13:32:36'),(42,1,'Plateltes',NULL,'/Cmm','150000 - 400000','150000 - 400000','400000','150000',NULL,'2020-07-04 13:32:36','2020-07-04 13:32:36'),(43,1,'MPV',NULL,'fl^3','9 - 11.9','9 - 11.9','11.9','9',NULL,'2020-07-04 13:32:36','2020-07-04 13:32:36'),(44,1,'PDW',NULL,'fL','9.9','15.4','15.4','9.9',NULL,'2020-07-04 13:32:36','2020-07-04 13:32:36'),(45,1,'P-LCR',NULL,'%','17.5 - 42.3','17.5 - 42.3','42.3','17.5',NULL,'2020-07-04 13:32:36','2020-07-04 13:32:36'),(46,1,'MCH',NULL,'%','27 - 32','27 - 32','32','27',NULL,'2020-07-04 13:32:36','2020-07-04 13:32:36'),(47,1,'MCHC',NULL,'%','33 - 35','33 - 35','35','33',NULL,'2020-07-04 13:32:36','2020-07-04 13:32:36'),(48,6,'HAEMOGLOBIN (HB)',NULL,'g/dl','14 - 18','11 - 16','16','11','2020-07-07 16:57:34','2020-07-04 14:01:27','2020-07-07 16:57:34'),(49,6,'HCT',NULL,'%','40 - 49','36 - 46','46','36','2020-07-07 16:57:34','2020-07-04 14:01:27','2020-07-07 16:57:34'),(50,6,'WBC (TLC)',NULL,'g/dl','3.8 - 11','3.8 - 11','11','3.8','2020-07-07 16:57:34','2020-07-04 14:01:27','2020-07-07 16:57:34'),(51,6,'Plateltes',NULL,'/Cmm','150000 - 400000','150000 - 400000','400000','150000','2020-07-07 16:57:34','2020-07-04 14:01:27','2020-07-07 16:57:34'),(52,7,'SGPT',NULL,'u/l','05 - 42','05 - 42','42','5','2020-07-07 16:57:04','2020-07-06 06:31:53','2020-07-07 16:57:04'),(53,8,'H-pylori','Negative',NULL,NULL,NULL,NULL,NULL,'2020-07-07 16:56:03','2020-07-06 06:44:22','2020-07-07 16:56:03'),(54,9,'Blood Sugar (Random)',NULL,'mg/dl','upto 160','upto 160',NULL,NULL,'2020-07-07 16:57:21','2020-07-06 07:02:04','2020-07-07 16:57:21'),(55,9,'Blood Sugar (Fasting)',NULL,'mg/dl','55 - 115','55 - 115','115','55','2020-07-07 16:57:21','2020-07-06 07:02:04','2020-07-07 16:57:21'),(56,10,'Typhidot IgG','Negative',NULL,NULL,NULL,NULL,NULL,'2020-07-07 16:57:50','2020-07-06 07:12:53','2020-07-07 16:57:50'),(57,10,'Typhidot IgM','Negative',NULL,NULL,NULL,NULL,NULL,'2020-07-07 16:57:50','2020-07-06 07:12:53','2020-07-07 16:57:50'),(58,11,'Creatinine',NULL,'mg/dl','0.7 - 1.3','0.6 - 1.3','1.3','0.6','2020-07-07 16:56:32','2020-07-07 16:08:58','2020-07-07 16:56:32'),(59,12,'Urea',NULL,'md/dl','13 - 45','13 - 45','45','13','2020-07-07 16:46:48','2020-07-07 16:46:12','2020-07-07 16:46:48'),(60,12,'Urea',NULL,'md/dl','13 - 45','13 - 45','45','13',NULL,'2020-07-07 16:46:48','2020-07-07 16:46:48'),(61,8,'H-pylori','Negative',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-07 16:56:03','2020-07-07 16:56:03'),(62,11,'Creatinine',NULL,'mg/dl','0.7 - 1.3','0.6 - 1.3','1.3','0.6',NULL,'2020-07-07 16:56:32','2020-07-07 16:56:32'),(63,7,'SGPT',NULL,'u/l','05 - 42','05 - 42','42','5','2020-07-10 19:53:05','2020-07-07 16:57:04','2020-07-10 19:53:05'),(64,9,'Blood Sugar (Random)',NULL,'mg/dl','upto 160','upto 160',NULL,NULL,NULL,'2020-07-07 16:57:21','2020-07-07 16:57:21'),(65,9,'Blood Sugar (Fasting)',NULL,'mg/dl','55 - 115','55 - 115','115','55',NULL,'2020-07-07 16:57:21','2020-07-07 16:57:21'),(66,6,'HAEMOGLOBIN (HB)',NULL,'g/dl','14 - 18','11 - 16','16','11',NULL,'2020-07-07 16:57:34','2020-07-07 16:57:34'),(67,6,'HCT',NULL,'%','40 - 49','36 - 46','46','36',NULL,'2020-07-07 16:57:34','2020-07-07 16:57:34'),(68,6,'WBC (TLC)',NULL,'g/dl','3.8 - 11','3.8 - 11','11','3.8',NULL,'2020-07-07 16:57:34','2020-07-07 16:57:34'),(69,6,'Plateltes',NULL,'/Cmm','150000 - 400000','150000 - 400000','400000','150000',NULL,'2020-07-07 16:57:34','2020-07-07 16:57:34'),(70,10,'Typhidot IgG','Negative',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-07 16:57:50','2020-07-07 16:57:50'),(71,10,'Typhidot IgM','Negative',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-07 16:57:50','2020-07-07 16:57:50'),(72,13,'LDH',NULL,'U/l','225 - 450','225 - 450','450','225',NULL,'2020-07-07 17:03:29','2020-07-07 17:03:29'),(73,14,'Albumin',NULL,'g/dl','4.2 - 5.5','3.7 - 5.3','5.3','4.2',NULL,'2020-07-07 17:10:11','2020-07-07 17:10:11'),(74,15,'Pregnancy Test',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-07 17:15:24','2020-07-07 17:15:24'),(75,16,'CRP (Quantitative)',NULL,'mg/dl','0 - 1','0 - 1','1','0',NULL,'2020-07-07 17:23:10','2020-07-07 17:23:10'),(76,17,'CPK',NULL,'U/l','24 - 204U/L','24 - 173U/L',NULL,NULL,NULL,'2020-07-07 17:31:58','2020-07-07 17:31:58'),(77,18,'A/G Ratio',NULL,'%',NULL,NULL,NULL,NULL,'2020-07-08 01:19:00','2020-07-08 01:06:48','2020-07-08 01:19:00'),(78,19,'A/G Ratio',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-08 01:11:28','2020-07-08 01:10:44','2020-07-08 01:11:28'),(79,19,'A/G Ratio',NULL,'%',NULL,NULL,NULL,NULL,NULL,'2020-07-08 01:11:28','2020-07-08 01:11:28'),(80,18,'Serum A.C.Enzyme',NULL,'U/I','Upto: 52 at 37 C Temp','Upto: 52 at 37 C Temp',NULL,NULL,NULL,'2020-07-08 01:19:00','2020-07-08 01:19:00'),(81,20,'ACTH',NULL,'pg/ml','Upto: 50','Upto: 50',NULL,NULL,NULL,'2020-07-08 01:21:49','2020-07-08 01:21:49'),(82,21,'ANA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-08 01:24:08','2020-07-08 01:24:08'),(83,22,'Patient APTT (Activited Partial Thromboplastin Time)',NULL,'Sec.','33 - 48','33 - 48','48','33',NULL,'2020-07-08 03:01:50','2020-07-08 03:01:50'),(84,23,'Serum Aldolase',NULL,'U/l','Upto:  7.6','Upto:  7.6',NULL,NULL,NULL,'2020-07-08 03:08:05','2020-07-08 03:08:05'),(85,24,'Aldosteron Level',NULL,'ng/dl','INFANTS','INFANTS',NULL,NULL,NULL,'2020-07-08 03:10:57','2020-07-08 03:10:57'),(86,25,'Alkaline Phosphate',NULL,'U/L','Years             Normal','Years             Normal',NULL,NULL,NULL,'2020-07-08 03:14:11','2020-07-08 03:14:11'),(87,26,'Alpha-MBDH',NULL,'U/l','55 - 140','55 - 140','140','55',NULL,'2020-07-08 03:17:18','2020-07-08 03:17:18'),(88,27,'ALPHA Feto-Protein',NULL,'IU/ml','0.82 - 9.12','0.82 - 9.12',NULL,NULL,NULL,'2020-07-08 03:22:50','2020-07-08 03:22:50'),(89,28,'Ammonia (NH3)',NULL,'umol/L','11.2 - 48.2','11.2 - 48.2','48.2','11',NULL,'2020-07-08 03:30:28','2020-07-08 03:30:28'),(90,29,'Serum Amylase',NULL,'U/l','Less than: 96','Less than: 96',NULL,NULL,NULL,'2020-07-08 03:32:52','2020-07-08 03:32:52'),(91,30,'Urinary Amylase',NULL,'AU/Hour','Upto:  260','Upto:  260',NULL,NULL,'2020-07-08 16:43:32','2020-07-08 03:34:47','2020-07-08 16:43:32'),(92,31,'Anti ds DNA','- Negative : < 0.9',NULL,NULL,NULL,NULL,NULL,'2020-07-08 03:44:41','2020-07-08 03:37:38','2020-07-08 03:44:41'),(93,31,'Anti ds DNA',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-08 03:44:41','2020-07-08 03:44:41'),(94,32,'Anti HBc lgG',NULL,'2.0',NULL,NULL,NULL,NULL,NULL,'2020-07-08 03:53:43','2020-07-08 03:53:43'),(95,33,'Anti HBc lgM',NULL,NULL,'2.0',NULL,NULL,NULL,NULL,'2020-07-08 03:55:24','2020-07-08 03:55:24'),(96,34,'Anti HBe',NULL,'2.0',NULL,NULL,NULL,NULL,NULL,'2020-07-08 03:57:32','2020-07-08 03:57:32'),(97,35,'Anti HBs',NULL,'2.0',NULL,NULL,NULL,NULL,NULL,'2020-07-08 03:59:15','2020-07-08 03:59:15'),(98,36,'Anti HCV','Negative',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-08 04:01:16','2020-07-08 04:01:16'),(99,37,'Anti HCV',NULL,'1',NULL,NULL,NULL,NULL,NULL,'2020-07-08 04:04:25','2020-07-08 04:04:25'),(100,38,'Anti HEV IgM',NULL,'2.0',NULL,NULL,NULL,NULL,NULL,'2020-07-08 04:06:33','2020-07-08 04:06:33'),(101,39,'Anti HEV IgM',NULL,'2.0',NULL,NULL,NULL,NULL,'2020-07-08 04:10:01','2020-07-08 04:08:03','2020-07-08 04:10:01'),(102,40,'Anti Sperm Abs (Scamual)',NULL,'U/ml',NULL,'Negative:  < 60.0',NULL,NULL,NULL,'2020-07-08 04:12:40','2020-07-08 04:12:40'),(103,41,'Colour','Clear/Straw',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-08 04:17:54','2020-07-08 04:17:54'),(104,41,'Quantity','250ml',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-08 04:17:54','2020-07-08 04:17:54'),(105,41,'Turbidity','NIL',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-08 04:17:54','2020-07-08 04:17:54'),(106,41,'Clot Formation','NIL',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-08 04:17:54','2020-07-08 04:17:54'),(107,41,'Sediment',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-08 04:17:54','2020-07-08 04:17:54'),(108,42,'Glucose',NULL,'mg/dl','80 - 180','80 - 180','180','80',NULL,'2020-07-08 04:22:29','2020-07-08 04:22:29'),(109,42,'Protein',NULL,'g/dl',NULL,NULL,NULL,NULL,NULL,'2020-07-08 04:22:29','2020-07-08 04:22:29'),(110,42,'Chloride',NULL,'mmol/l','94 - 111','94 - 111','111','94',NULL,'2020-07-08 04:22:29','2020-07-08 04:22:29'),(111,42,'pH',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-08 04:22:29','2020-07-08 04:22:29'),(112,42,'Amylase',NULL,'U/l','Less Than: 220','Less Than: 220',NULL,NULL,NULL,'2020-07-08 04:22:29','2020-07-08 04:22:29'),(113,42,'LDH',NULL,'U/l','55 - 140','55 - 140','140','55',NULL,'2020-07-08 04:22:29','2020-07-08 04:22:29'),(114,43,'WBC\'s',NULL,'/Cmm',NULL,NULL,NULL,NULL,NULL,'2020-07-08 04:24:16','2020-07-08 04:24:16'),(115,43,'RBC\'s',NULL,'/Cmm',NULL,NULL,NULL,NULL,NULL,'2020-07-08 04:24:16','2020-07-08 04:24:16'),(116,43,'Neutrophils',NULL,'%',NULL,NULL,NULL,NULL,NULL,'2020-07-08 04:24:16','2020-07-08 04:24:16'),(117,43,'Lymphocytes',NULL,'%',NULL,NULL,NULL,NULL,NULL,'2020-07-08 04:24:16','2020-07-08 04:24:16'),(118,44,'Z-N','Negative for Acid Fast Bacilli.',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-08 04:25:56','2020-07-08 04:25:56'),(119,44,'Gram\'s','No Stain-able Micro Organism Seen.',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-08 04:25:56','2020-07-08 04:25:56'),(120,44,'H&E',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-08 04:25:56','2020-07-08 04:25:56'),(121,45,'ASOT (Quantitative)','Negative , Positive','IU/ml','N. Value: 0 - 200','N. Value: 0 - 200',NULL,NULL,NULL,'2020-07-08 04:30:40','2020-07-08 04:30:40'),(122,46,'Beta HCG',NULL,'IU/ml','< 5.0','-  Upto: 10.0',NULL,NULL,NULL,'2020-07-08 04:33:13','2020-07-08 04:33:13'),(123,47,'Bicarbonate (HCO3)',NULL,'UNITS mmol/L','24 - 30','24 - 30',NULL,NULL,NULL,'2020-07-08 04:35:15','2020-07-08 04:35:15'),(124,48,'Bilirubin (Direct)',NULL,'mg/dl','0.1 - 0.4','0.1 - 0.4','0.4','0.1',NULL,'2020-07-08 04:39:37','2020-07-08 04:39:37'),(125,49,'Bilirubin (Total)',NULL,'mg/dl','Adults: 0.2 - 1.0','Adults: 0.2 - 1.0',NULL,NULL,NULL,'2020-07-08 04:48:20','2020-07-08 04:48:20'),(126,50,'Bilirubin (Indirect)',NULL,'mg/dl','0.1 - 0.4','0.1 - 0.4',NULL,NULL,NULL,'2020-07-08 04:50:11','2020-07-08 04:50:11'),(127,51,'Bleeding Time',NULL,'Minute / Seconds','2 - 7','2 - 7','7','2',NULL,'2020-07-08 04:53:00','2020-07-08 04:53:00'),(128,52,'Urea',NULL,'mg/dl','10 - 50','10 - 50',NULL,NULL,NULL,'2020-07-08 04:57:55','2020-07-08 04:57:55'),(129,52,'BUN',NULL,'mg/dl','8 - 25','8 - 25',NULL,NULL,NULL,'2020-07-08 04:57:55','2020-07-08 04:57:55'),(130,52,'Creatinine',NULL,'mg/dl','0.5 - 1.4','0.5 - 1.2',NULL,NULL,NULL,'2020-07-08 04:57:55','2020-07-08 04:57:55'),(131,52,'Total Protein',NULL,'g/dl','6.4 - 8.3','6.4 - 8.3',NULL,NULL,NULL,'2020-07-08 04:57:55','2020-07-08 04:57:55'),(132,52,'Albumin',NULL,'g/dl','3.4 - 4.8','3.4 - 4.8',NULL,NULL,NULL,'2020-07-08 04:57:55','2020-07-08 04:57:55'),(133,52,'Calcium',NULL,'mg/dl','8.5 - 10.5','8.5 - 10.5',NULL,NULL,NULL,'2020-07-08 04:57:55','2020-07-08 04:57:55'),(134,52,'Phosphate',NULL,'mg/dl','2.7 - 4.5','2.7 - 4.5',NULL,NULL,NULL,'2020-07-08 04:57:55','2020-07-08 04:57:55'),(135,53,'Blood Group',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-08 05:01:33','2020-07-08 05:01:33'),(136,53,'Rh Factor',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-08 05:01:33','2020-07-08 05:01:33'),(137,54,'BUN',NULL,'mg/dl','8 - 25','8 - 25','25','8',NULL,'2020-07-08 15:07:06','2020-07-08 15:07:06'),(138,55,'CEA',NULL,'ng/ml','Smoker: <5.0',NULL,NULL,NULL,NULL,'2020-07-08 15:09:32','2020-07-08 15:09:32'),(139,56,'C-3',NULL,'mg/dl','89 - 154','89 - 154','154','89',NULL,'2020-07-08 15:11:46','2020-07-08 15:11:46'),(140,57,'C-4',NULL,'mg/dl','20 - 50','20 - 50','50','20',NULL,'2020-07-08 15:14:24','2020-07-08 15:14:24'),(141,58,'CA 125',NULL,'U/ml','< 35','< 35',NULL,NULL,NULL,'2020-07-08 15:16:49','2020-07-08 15:16:49'),(142,59,'CA 19-9',NULL,'U/ml',NULL,NULL,NULL,NULL,NULL,'2020-07-08 15:19:48','2020-07-08 15:19:48'),(143,60,'Calcium (Ca+)',NULL,'mg/dl','8.5 - 10.3','8.5 - 10.3',NULL,NULL,NULL,'2020-07-08 15:41:32','2020-07-08 15:41:32'),(144,61,'Carbamazepine (Tegretol)',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-08 15:44:55','2020-07-08 15:44:55'),(145,62,'CPK',NULL,'U/I','Upto 196','Upto 196',NULL,NULL,NULL,'2020-07-08 15:50:41','2020-07-08 15:50:41'),(146,62,'CKMB',NULL,'U/I','0  -  25','0  -  25',NULL,NULL,NULL,'2020-07-08 15:50:41','2020-07-08 15:50:41'),(147,62,'AST (SGOT)',NULL,'U/I','5 - 38','5 - 32',NULL,NULL,NULL,'2020-07-08 15:50:41','2020-07-08 15:50:41'),(148,62,'LDH',NULL,'U/I','225 - 450','225 - 450',NULL,NULL,NULL,'2020-07-08 15:50:41','2020-07-08 15:50:41'),(149,62,'Alpha MBDH',NULL,'U/I','55 - 140','55 - 140',NULL,NULL,NULL,'2020-07-08 15:50:41','2020-07-08 15:50:41'),(150,63,'Chloride (Cl-)',NULL,'mmol/L','92 - 108','92 - 108',NULL,NULL,NULL,'2020-07-08 15:54:10','2020-07-08 15:54:10'),(151,64,'Cholesterol','-  Without Known Cornorary Artery Disease Less Than\r\n   Or Equal to 200: DESIRABLE.\r\n-  With Known Coronary Artery Disease Less Than \r\n   Or Equal to 160: OPTIMAL','mg/dl',NULL,NULL,NULL,NULL,'2020-07-08 16:23:52','2020-07-08 15:57:40','2020-07-08 16:23:52'),(153,64,'Cholesterol','-  Without Known Cornorary Artery Disease Less Than\r\n   Or Equal to 200: DESIRABLE.\r\n-  With Known Coronary Artery Disease Less Than \r\n   Or Equal to 160: OPTIMAL','mg/dl',NULL,NULL,NULL,NULL,'2020-07-08 16:24:25','2020-07-08 16:23:52','2020-07-08 16:24:25'),(154,64,NULL,'5',NULL,NULL,NULL,NULL,NULL,'2020-07-08 16:24:25','2020-07-08 16:23:52','2020-07-08 16:24:25'),(155,64,'Cholesterol',NULL,'mg/dl',NULL,NULL,NULL,NULL,NULL,'2020-07-08 16:24:25','2020-07-08 16:24:25'),(156,64,NULL,'-  Without Known Cornorary Artery Disease Less Than\r\n   Or Equal to 200: DESIRABLE.\r\n-  With Known Coronary Artery Disease Less Than \r\n   Or Equal to 160: OPTIMAL',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-08 16:24:25','2020-07-08 16:24:25'),(157,30,'Urinary Amylase',NULL,'AU/Hour','Upto:  260','Upto:  260',NULL,NULL,'2020-07-08 16:43:43','2020-07-08 16:43:32','2020-07-08 16:43:43'),(158,30,'Urinary Amylase',NULL,'AU/Hour','Upto:  260','Upto:  260',NULL,NULL,'2020-07-08 16:43:55','2020-07-08 16:43:44','2020-07-08 16:43:55'),(159,30,'Urinary Amylase',NULL,'AU/Hour','Upto:  260','Upto:  260',NULL,NULL,'2020-07-08 16:44:48','2020-07-08 16:43:55','2020-07-08 16:44:48'),(160,30,'Urinary Amylase',NULL,'AU/Hour','Upto:  260','Upto:  260',NULL,NULL,'2020-07-08 16:56:22','2020-07-08 16:44:48','2020-07-08 16:56:22'),(161,30,'Urinary Amylase',NULL,'AU/Hour','Upto:  260','Upto:  260',NULL,NULL,'2020-07-08 16:56:31','2020-07-08 16:56:22','2020-07-08 16:56:31'),(162,30,'Urinary Amylase',NULL,'AU/Hour','Upto:  260','Upto:  260',NULL,NULL,'2020-07-08 16:57:17','2020-07-08 16:56:31','2020-07-08 16:57:17'),(163,30,'Urinary Amylase',NULL,'AU/Hour','Upto:  260','Upto:  260',NULL,NULL,'2020-07-08 16:57:40','2020-07-08 16:57:17','2020-07-08 16:57:40'),(164,30,'Urinary Amylase',NULL,'AU/Hour','Upto:  260','Upto:  260',NULL,NULL,'2020-07-08 16:58:05','2020-07-08 16:57:40','2020-07-08 16:58:05'),(165,30,'Urinary Amylase',NULL,'AU/Hour','Upto:  260','Upto:  260',NULL,NULL,NULL,'2020-07-08 16:58:05','2020-07-08 16:58:05'),(166,65,'CK-MB',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-08 17:06:05','2020-07-08 17:05:39','2020-07-08 17:06:05'),(167,65,'CK-MB',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-08 17:06:29','2020-07-08 17:06:05','2020-07-08 17:06:29'),(168,66,'CK-MB',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-08 20:30:55','2020-07-08 20:30:41','2020-07-08 20:30:55'),(169,66,'CK-MB',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-08 20:31:04','2020-07-08 20:30:55','2020-07-08 20:31:04'),(170,66,'CK-MB',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-08 20:31:14','2020-07-08 20:31:04','2020-07-08 20:31:14'),(171,66,'CK-MB',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-08 20:31:20','2020-07-08 20:31:14','2020-07-08 20:31:20'),(172,67,'CK-MB',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-08 20:33:28','2020-07-08 20:31:36','2020-07-08 20:33:28'),(173,67,'CK-MB',NULL,'U/l','0 - 25','0 - 25',NULL,NULL,NULL,'2020-07-08 20:33:28','2020-07-08 20:33:28'),(174,68,'Clotting Time',NULL,'Minutes / Seconds.','5 - 11','5 - 11',NULL,NULL,'2020-07-08 20:38:34','2020-07-08 20:37:46','2020-07-08 20:38:34'),(175,68,'Clotting Time',NULL,'Minutes / Seconds.','5 - 11','5 - 11',NULL,NULL,NULL,'2020-07-08 20:38:34','2020-07-08 20:38:34'),(176,69,'CMV lgG',NULL,'12.0',NULL,NULL,NULL,NULL,NULL,'2020-07-08 20:55:47','2020-07-08 20:55:47'),(177,70,'CMV lgM',NULL,'1.0',NULL,NULL,NULL,NULL,NULL,'2020-07-08 20:57:35','2020-07-08 20:57:35'),(178,71,'Direct',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-08 21:00:03','2020-07-08 21:00:03'),(179,72,'Indirect',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-08 21:03:21','2020-07-08 21:03:07','2020-07-08 21:03:21'),(180,72,'Indirect',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-08 21:03:21','2020-07-08 21:03:21'),(181,73,'Typhidot IgG','Negative',NULL,NULL,NULL,NULL,NULL,'2020-07-10 16:17:00','2020-07-10 15:57:13','2020-07-10 16:17:00'),(182,73,'Typhidot IgM','Negative',NULL,NULL,NULL,NULL,NULL,'2020-07-10 16:17:00','2020-07-10 15:57:13','2020-07-10 16:17:00'),(183,74,'TSH',NULL,'mIU/L','01-11 Months: 1.0 - 6.1',NULL,NULL,NULL,'2020-07-10 15:59:17','2020-07-10 15:58:20','2020-07-10 15:59:17'),(184,74,'.',NULL,NULL,'01-05 Years: 0.7 - 6.3',NULL,NULL,NULL,'2020-07-10 15:59:17','2020-07-10 15:58:20','2020-07-10 15:59:17'),(185,74,'.',NULL,NULL,'05-015 Years: 0.7 - 6.4',NULL,NULL,NULL,'2020-07-10 15:59:17','2020-07-10 15:58:20','2020-07-10 15:59:17'),(186,74,'.',NULL,NULL,'15-50 Years: 0.4 - 4.2',NULL,NULL,NULL,'2020-07-10 15:59:17','2020-07-10 15:58:20','2020-07-10 15:59:17'),(187,74,'.',NULL,NULL,'Above 50 Years: 0.5 - 8.9',NULL,NULL,NULL,'2020-07-10 15:59:17','2020-07-10 15:58:20','2020-07-10 15:59:17'),(188,74,'TSH',NULL,'mIU/L','01-11 Months: 1.0 - 6.1','01-11 Months: 1.0 - 6.1',NULL,NULL,NULL,'2020-07-10 15:59:17','2020-07-10 15:59:17'),(189,74,'.',NULL,NULL,'01-05 Years: 0.7 - 6.3','01-05 Years: 0.7 - 6.3',NULL,NULL,NULL,'2020-07-10 15:59:17','2020-07-10 15:59:17'),(190,74,'.',NULL,NULL,'05-015 Years: 0.7 - 6.4','05-015 Years: 0.7 - 6.4',NULL,NULL,NULL,'2020-07-10 15:59:17','2020-07-10 15:59:17'),(191,74,'.',NULL,NULL,'15-50 Years: 0.4 - 4.2','15-50 Years: 0.4 - 4.2',NULL,NULL,NULL,'2020-07-10 15:59:17','2020-07-10 15:59:17'),(192,74,'.',NULL,NULL,'Above 50 Years: 0.5 - 8.9','Above 50 Years: 0.5 - 8.9',NULL,NULL,NULL,'2020-07-10 15:59:17','2020-07-10 15:59:17'),(193,75,'IgM Positive Only:','Acute Typhoid Fever.',NULL,NULL,NULL,NULL,NULL,'2020-07-10 16:10:24','2020-07-10 16:07:23','2020-07-10 16:10:24'),(194,75,'IgG & IgM Positive Only:','Acute Typhoid Fever. \r\n(in the Middle stage of Infection',NULL,NULL,NULL,NULL,NULL,'2020-07-10 16:10:24','2020-07-10 16:07:23','2020-07-10 16:10:24'),(195,75,'IgG  Positive Only:','imp',NULL,NULL,NULL,NULL,NULL,'2020-07-10 16:10:24','2020-07-10 16:07:23','2020-07-10 16:10:24'),(196,75,'IgG & IgM Negative','Probably Not Typhoid',NULL,NULL,NULL,NULL,NULL,'2020-07-10 16:10:24','2020-07-10 16:07:23','2020-07-10 16:10:24'),(197,75,'IgM Positive Only:','Acute Typhoid Fever.',NULL,NULL,NULL,NULL,NULL,'2020-07-10 16:11:15','2020-07-10 16:10:24','2020-07-10 16:11:15'),(198,75,'IgG & IgM Positive Only:','Acute Typhoid Fever. \r\n(in the Middle stage of Infection',NULL,NULL,NULL,NULL,NULL,'2020-07-10 16:11:15','2020-07-10 16:10:24','2020-07-10 16:11:15'),(199,75,'IgG  Positive Only:','Implications for the presence of IgG antibodies include previous infection (in which case current fever may not be due to typhoid), or relapse or re-infection.\r\nTherefore, it is important tha',NULL,NULL,NULL,NULL,NULL,'2020-07-10 16:11:15','2020-07-10 16:10:24','2020-07-10 16:11:15'),(200,75,'IgG & IgM Negative','Probably Not Typhoid',NULL,NULL,NULL,NULL,NULL,'2020-07-10 16:11:15','2020-07-10 16:10:24','2020-07-10 16:11:15'),(201,75,'IgM Positive Only:','Acute Typhoid Fever.',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-10 16:11:15','2020-07-10 16:11:15'),(202,75,'IgG & IgM Positive Only:','Acute Typhoid Fever. \r\n(in the Middle stage of Infection',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-10 16:11:15','2020-07-10 16:11:15'),(203,75,'IgG  Positive Only:','Implications for the presence of IgG antibodies include previous infection (in which case current fever may not be due to typhoid), or relapse or re-infection.\r\nTherefore, it is important tha',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-10 16:11:15','2020-07-10 16:11:15'),(204,75,'IgG & IgM Negative','Probably Not Typhoid',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-10 16:11:15','2020-07-10 16:11:15'),(205,73,'Typhidot IgG','Negative',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-10 16:17:00','2020-07-10 16:17:00'),(206,73,'Typhidot IgM','Negative',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-10 16:17:00','2020-07-10 16:17:00'),(207,76,'COLOR','CREAMY WHITE',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-10 16:23:48','2020-07-10 16:23:48'),(208,76,'VISCOSITY','SEMI VISCOUS',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-10 16:23:48','2020-07-10 16:23:48'),(209,76,'VOLUME','2','ML',NULL,NULL,NULL,NULL,NULL,'2020-07-10 16:23:48','2020-07-10 16:23:48'),(210,76,'PH','ALKALINE',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-10 16:23:48','2020-07-10 16:23:48'),(211,76,'LIQUEFACTION TIME','2','MIN',NULL,NULL,NULL,NULL,NULL,'2020-07-10 16:23:48','2020-07-10 16:23:48'),(212,77,'TOTAL SPERM COUNT','22','MILLIOM/ML',NULL,NULL,NULL,NULL,NULL,'2020-07-10 16:28:53','2020-07-10 16:28:53'),(213,77,'PUSS CELL','0','/HPF',NULL,NULL,NULL,NULL,NULL,'2020-07-10 16:28:53','2020-07-10 16:28:53'),(214,77,'RBCs','0','/HPF',NULL,NULL,NULL,NULL,NULL,'2020-07-10 16:28:53','2020-07-10 16:28:53'),(215,77,'CYSTAL','0','/HPF',NULL,NULL,NULL,NULL,NULL,'2020-07-10 16:28:53','2020-07-10 16:28:53'),(216,78,'Bilirubin Total',NULL,'mg/dl','0.2 - 1.1','0.2 - 1.1',NULL,NULL,NULL,'2020-07-10 16:30:47','2020-07-10 16:30:47'),(217,78,'Bilirubin Direct',NULL,'mg/dl','0.1 - 0.7','0.1 - 0.7',NULL,NULL,NULL,'2020-07-10 16:30:47','2020-07-10 16:30:47'),(218,78,'Bilirubine Indirect',NULL,'mg/dl','0.1 - 0.4','0.1 - 0.4',NULL,NULL,NULL,'2020-07-10 16:30:47','2020-07-10 16:30:47'),(219,78,'SGPT (ALT)',NULL,'U/L','5 - 42','5 - 42',NULL,NULL,NULL,'2020-07-10 16:30:47','2020-07-10 16:30:47'),(220,78,'SGOT (AST)',NULL,'U/L','5 - 45','5 - 45',NULL,NULL,NULL,'2020-07-10 16:30:47','2020-07-10 16:30:47'),(221,78,'Alkaline Phasphatase',NULL,'U/L','90 - 306','90 - 306',NULL,NULL,NULL,'2020-07-10 16:30:47','2020-07-10 16:30:47'),(222,78,'90 - 306',NULL,'U/L','7 - 32','7 - 32',NULL,NULL,NULL,'2020-07-10 16:30:47','2020-07-10 16:30:47'),(223,78,'Total Proteins',NULL,'g/dl','6.4 - 8.3','6.4 - 8.3',NULL,NULL,NULL,'2020-07-10 16:30:47','2020-07-10 16:30:47'),(224,78,'Albumin',NULL,'g/dl','3.4 - 5.4','3.4 - 5.4',NULL,NULL,NULL,'2020-07-10 16:30:47','2020-07-10 16:30:47'),(225,79,'Excellent Motile','2','%','More than 60',NULL,NULL,NULL,NULL,'2020-07-10 16:33:30','2020-07-10 16:33:30'),(226,79,'Good Active Motile','2','%',NULL,NULL,NULL,NULL,NULL,'2020-07-10 16:33:30','2020-07-10 16:33:30'),(227,79,'Sluggish Motile',NULL,'%',NULL,NULL,NULL,NULL,NULL,'2020-07-10 16:33:30','2020-07-10 16:33:30'),(228,79,'Non Motile',NULL,'%',NULL,NULL,NULL,NULL,NULL,'2020-07-10 16:33:30','2020-07-10 16:33:30'),(229,80,'Normal','2','%',NULL,NULL,NULL,NULL,NULL,'2020-07-10 16:35:26','2020-07-10 16:35:26'),(230,80,'Abnormal','2','%',NULL,NULL,NULL,NULL,NULL,'2020-07-10 16:35:26','2020-07-10 16:35:26'),(231,81,'T3','1','nmol/L','0.92 - 2.33','0.92 - 2.33',NULL,NULL,NULL,'2020-07-10 16:42:53','2020-07-10 16:42:53'),(232,82,'S.Typhi (O):','-','-','-','-','-','-',NULL,'2020-07-10 16:49:35','2020-07-10 16:49:35'),(233,82,'S.Typhi (H):','-','-','-','-','-','-',NULL,'2020-07-10 16:49:35','2020-07-10 16:49:35'),(234,82,'S.P. Typhi (AO):','-','-','-','-','-','-',NULL,'2020-07-10 16:49:35','2020-07-10 16:49:35'),(235,82,'S.P. Typhi (AH):','-','-','-','-','-','-',NULL,'2020-07-10 16:49:35','2020-07-10 16:49:35'),(236,82,'S.P. Typhi (BO):','-','-','-','-','-','-',NULL,'2020-07-10 16:49:35','2020-07-10 16:49:35'),(237,82,'S.P. Typhi (BH):','-','-','-','-','-','-',NULL,'2020-07-10 16:49:35','2020-07-10 16:49:35'),(238,83,'T4',NULL,'nmol/L','60 - 120','60 - 120','120','60',NULL,'2020-07-10 16:57:32','2020-07-10 16:57:32'),(239,84,'Hcv pcr',NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-10 17:03:35','2020-07-10 17:03:35'),(240,4,'pH','6.0',NULL,'5.0 - 7.5','5.0 - 7.5',NULL,NULL,NULL,'2020-07-10 17:25:34','2020-07-10 17:25:34'),(241,4,'Glucose','Nil',NULL,'Nil','Nil',NULL,NULL,NULL,'2020-07-10 17:25:34','2020-07-10 17:25:34'),(242,4,'Protein','Nil',NULL,'Nil','Nil',NULL,NULL,NULL,'2020-07-10 17:25:34','2020-07-10 17:25:34'),(243,4,'Ketone','Nil',NULL,'Nil','Nil',NULL,NULL,NULL,'2020-07-10 17:25:34','2020-07-10 17:25:34'),(244,4,'Urobilinogen','Normal',NULL,'< 1mg/dl','< 1mg/dl',NULL,NULL,NULL,'2020-07-10 17:25:34','2020-07-10 17:25:34'),(245,4,'Bilirubin','Nil',NULL,'Nil','Nil',NULL,NULL,NULL,'2020-07-10 17:25:34','2020-07-10 17:25:34'),(246,4,'Blood','Nil',NULL,'Nil','Nil',NULL,NULL,NULL,'2020-07-10 17:25:34','2020-07-10 17:25:34'),(247,4,'Leucocytes','Nil',NULL,'Negative','Negative',NULL,NULL,NULL,'2020-07-10 17:25:34','2020-07-10 17:25:34'),(248,4,'Nitrite','Negative',NULL,'Negative','Negative',NULL,NULL,NULL,'2020-07-10 17:25:34','2020-07-10 17:25:34'),(249,85,'HbA1c',NULL,'%','Normal Non Diabetic Patients: 4.0 - 5.7  DIABETIC:   -Risk of developing diabetes: 5.7 - 6.0%  -High Risk of developing diabetes: 6.0 - 6.5%  -Poor control:  Above   6.5%','Diabetic Patients: 4.0 - 5.7  DIABETIC:   -Risk of developing diabetes: 5.7 - 6.0%  -High Risk of developing diabetes: 6.0 - 6.5%  -Poor control:  Above   6.5%',NULL,NULL,NULL,'2020-07-10 17:30:19','2020-07-10 17:30:19'),(250,86,'FSH',NULL,'mIU/mI','1.7 - 12.0','Female (Follicular phase) : 3.9 - 12.0 Female (Ovulation peak): 6.3 - 24.0 Female (Luteal phase: D+3 to D+15): 1.5 - 7.0 Female (Post-Menopausal): 17.0 - 95.0 Adulat Male  :          1.7 - 12',NULL,NULL,NULL,'2020-07-10 17:45:31','2020-07-10 17:45:31'),(251,87,'LH',NULL,'IU/I','1.7 - 8.6','Female (Follicular phase): 1.5 - 8.0 Female (Ovulation peak): 9.6 - 80.0 Female (Luteal phase: D+3 to D+15): 0.2 - 6.5 Female (Post-Menopausal): 8.0 - 33.0 Adult Male       1.7 - 8.6',NULL,NULL,NULL,'2020-07-10 17:53:43','2020-07-10 17:53:43'),(252,88,'Testosterone',NULL,'ng/ml','Male :  2.27 – 10.30','Male :  2.27 – 10.30  Female  ≥ 19 – 50 Years:  0.23 – 0.73  Female  > 50 Years:  0.14 – 0.68',NULL,NULL,NULL,'2020-07-10 17:59:14','2020-07-10 17:59:14'),(253,89,'Prolactin',NULL,'ng/ml','3 – 25','Normal Menstruating women:  5 – 35  Menopausal Women:  5 - 35  Men:   3 – 25',NULL,NULL,NULL,'2020-07-10 18:18:28','2020-07-10 18:18:28'),(254,90,'Brucella Abortus:','-','-','-','-','-','-',NULL,'2020-07-10 19:08:04','2020-07-10 19:08:04'),(255,90,'Brucella Melitensis:','-','-','-','-','-','-',NULL,'2020-07-10 19:08:04','2020-07-10 19:08:04'),(256,7,'SGPT',NULL,'u/l','05 - 42','05 - 42','42','5',NULL,'2020-07-10 19:53:05','2020-07-10 19:53:05');
/*!40000 ALTER TABLE `test_particulars` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `test_sells`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `test_sells` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `test_id` int(10) unsigned NOT NULL,
  `transaction_id` int(10) unsigned NOT NULL,
  `patient_id` int(10) unsigned NOT NULL,
  `department_id` int(10) unsigned NOT NULL,
  `ref_by` int(10) unsigned NOT NULL,
  `report_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `test_comment` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `test_result` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `reported_dated` datetime DEFAULT NULL,
  `report_date` datetime NOT NULL,
  `file` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `final_total` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `test_cast_amount` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `more_amount` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `invoice_token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `test_sells_test_id_foreign` (`test_id`),
  KEY `test_sells_transaction_id_foreign` (`transaction_id`),
  KEY `test_sells_patient_id_foreign` (`patient_id`),
  KEY `test_sells_department_id_foreign` (`department_id`),
  KEY `test_sells_ref_by_foreign` (`ref_by`),
  CONSTRAINT `test_sells_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `test_sells_patient_id_foreign` FOREIGN KEY (`patient_id`) REFERENCES `contacts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `test_sells_ref_by_foreign` FOREIGN KEY (`ref_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `test_sells_test_id_foreign` FOREIGN KEY (`test_id`) REFERENCES `tests` (`id`) ON DELETE CASCADE,
  CONSTRAINT `test_sells_transaction_id_foreign` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `test_sells` WRITE;
/*!40000 ALTER TABLE `test_sells` DISABLE KEYS */;
INSERT INTO `test_sells` VALUES (1,1,1,1,1,3,'RP2020/0001',NULL,NULL,'2020-07-04 18:21:56','2020-07-04 18:19:21',NULL,'Complete',300.0000,143.3000,156.7000,NULL,'2020-07-04 13:19:21','2020-07-04 13:21:56',NULL),(2,2,2,1,1,3,'RP2020/0002',NULL,NULL,'2020-07-04 19:06:29','2020-07-04 19:05:51',NULL,'Complete',150.0000,143.3000,6.7000,NULL,'2020-07-04 14:05:51','2020-07-04 14:06:29','b963e3b4cdff629080c4fab422276279'),(3,5,3,1,4,3,'RP2020/0003',NULL,NULL,NULL,'2020-07-07 11:26:34',NULL,'Waiting',300.0000,75.5000,224.5000,NULL,'2020-07-07 16:26:34','2020-07-07 16:26:34',NULL),(4,6,4,1,428,3,'RP2020/0004',NULL,NULL,'2020-07-07 11:42:20','2020-07-07 11:41:21',NULL,'Complete',100.0000,11.5000,88.5000,NULL,'2020-07-07 16:41:21','2020-07-07 16:42:20','ad3d50ec3e671a763c56dfb4f6d6736a'),(5,1,5,2,1,16,'RP2020/0005','Cnszdxcvnzxcmvn,szmxcnv',NULL,'2020-07-10 13:19:45','2020-07-07 13:15:53',NULL,'Complete',300.0000,143.3000,156.7000,NULL,'2020-07-07 18:15:53','2020-07-10 18:19:45','0521d479284817f01d7856baf7f2a382'),(7,57,7,1,144,3,'RP2020/0007',NULL,NULL,'2020-07-08 11:25:59','2020-07-08 11:25:20',NULL,'Complete',2.0000,2.0000,0.0000,NULL,'2020-07-08 16:25:20','2020-07-08 16:25:59','e95ef469132ef2f3c364ce06cfa2cae6'),(8,1,8,1,1,4,'RP2020/0008',NULL,NULL,'2020-07-09 18:03:38','2020-07-09 09:10:08',NULL,'Complete',300.0000,143.3000,156.7000,NULL,'2020-07-09 14:10:09','2020-07-09 23:03:38',NULL),(9,1,10,1,1,4,'RP2020/0009',NULL,NULL,NULL,'2020-07-09 18:02:43',NULL,'Waiting',300.0000,143.3000,156.7000,NULL,'2020-07-09 23:02:43','2020-07-09 23:02:43',NULL),(10,72,11,1,531,3,'RP2020/0010','<p>Titres in excess of 1:80 are probably significant...</p>','Positive','2020-07-10 12:16:56','2020-07-10 12:02:50',NULL,'Complete',100.0000,14.8000,85.2000,NULL,'2020-07-10 17:02:50','2020-07-10 17:16:56','cbdc926d59c89f71bf27eaf3d7f17af8'),(11,81,13,1,547,3,'RP2020/0011',NULL,'Positive','2020-07-10 14:47:40','2020-07-10 14:41:12',NULL,'Complete',2.0000,2.0000,0.0000,NULL,'2020-07-10 19:41:12','2020-07-10 19:47:40','f0c572bb3fe382f77bec0e11b664dd3b'),(12,1,14,3,1,4,'RP2020/0012',NULL,NULL,'2020-07-10 14:50:09','2020-07-10 14:49:04',NULL,'Complete',300.0000,143.3000,156.7000,NULL,'2020-07-10 19:49:04','2020-07-10 19:50:09',NULL),(13,3,14,3,497,4,'RP2020/0013',NULL,NULL,'2020-07-10 14:51:29','2020-07-10 14:49:04',NULL,'Complete',100.0000,24.0000,76.0000,NULL,'2020-07-10 19:49:04','2020-07-10 19:51:29',NULL),(14,4,14,3,10,4,'RP2020/0014',NULL,NULL,'2020-07-10 14:52:15','2020-07-10 14:49:04',NULL,'Complete',200.0000,10.8900,189.1100,NULL,'2020-07-10 19:49:04','2020-07-10 19:52:15',NULL),(15,4,15,4,10,5,'RP2020/0015',NULL,NULL,'2020-07-10 14:59:13','2020-07-10 14:57:41',NULL,'Complete',200.0000,10.8900,189.1100,NULL,'2020-07-10 19:57:41','2020-07-10 19:59:13','46176302af78adc972b14aba461907ce'),(16,72,15,4,531,5,'RP2020/0016','<p>Titres in excess of 1:80 are probably significant...</p>','Positive','2020-07-10 14:58:52','2020-07-10 14:57:41',NULL,'Complete',100.0000,14.8000,85.2000,NULL,'2020-07-10 19:57:41','2020-07-10 19:58:52','c6374ae41b72898ee4cfad01fc400861'),(17,1,16,5,1,4,'RP2020/0017',NULL,NULL,'2020-07-10 15:25:47','2020-07-10 15:24:52',NULL,'Complete',300.0000,143.3000,156.7000,NULL,'2020-07-10 20:24:52','2020-07-10 20:25:47',NULL),(18,72,16,5,531,4,'RP2020/0018','<p>Titres in excess of 1:80 are probably significant...</p>','Positive','2020-07-10 15:26:25','2020-07-10 15:24:52',NULL,'Complete',100.0000,14.8000,85.2000,NULL,'2020-07-10 20:24:52','2020-07-10 20:26:25','90b7bb4328a11a48c0f12a24ed78c75f');
/*!40000 ALTER TABLE `test_sells` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `tests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `tests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `department_id` int(10) unsigned NOT NULL,
  `test_code` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `sample_require` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `carry_out` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `report_time_day` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `test_comment` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `final_total` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `test_cast_amount` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `more_amount` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `business_id` int(10) unsigned NOT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `tests_department_id_foreign` (`department_id`),
  KEY `tests_business_id_foreign` (`business_id`),
  KEY `tests_created_by_foreign` (`created_by`),
  CONSTRAINT `tests_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tests_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `tests_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=82 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `tests` WRITE;
/*!40000 ALTER TABLE `tests` DISABLE KEYS */;
INSERT INTO `tests` VALUES (1,'CBC-Blood Complete Examination',1,'cbc','3 cc Blood In EDTA','Routine','Sameday',NULL,NULL,300.0000,143.3000,156.7000,1,1,NULL,'2020-07-04 13:18:03','2020-07-07 16:37:56'),(2,'HB',1,'HB','3 cc Blood In EDTA','Routine','Sameday',NULL,NULL,150.0000,143.3000,6.7000,1,1,NULL,'2020-07-04 14:04:26','2020-07-07 16:36:03'),(3,'Urine Complete Examination',497,'ur','Random Urine','Routine','Sameday',NULL,NULL,100.0000,24.0000,76.0000,1,1,NULL,'2020-07-06 06:30:30','2020-07-07 17:30:11'),(4,'SGPT (ALT)',10,'sgpt','3-5 cc Clotted Blood/Serum','Routine','Sameday',NULL,NULL,200.0000,10.8900,189.1100,1,1,NULL,'2020-07-06 06:38:08','2020-07-07 16:34:20'),(5,'H.Pylori Abs (Screening)',16,'h-pylori','3-5 cc Clotted Blood/Serum','Routine','Sameday',NULL,NULL,300.0000,75.8000,224.2000,1,1,NULL,'2020-07-06 06:47:23','2020-07-07 16:31:36'),(6,'Blood sugar',428,'sugar','3-5 cc Clotted Blood/Serum','Routine','Sameday',NULL,NULL,100.0000,11.5000,88.5000,1,1,NULL,'2020-07-06 07:06:51','2020-07-07 16:40:22'),(7,'Creatinine',119,'Creatinine','3-5 cc Clotted Blood/Serum','Routine','Sameday',NULL,NULL,200.0000,10.8000,189.2000,1,1,NULL,'2020-07-07 16:23:03','2020-07-07 16:23:03'),(8,'Urea',119,'Uera','3-5 cc Clotted Blood/Serum','Routine','Sameday',NULL,NULL,200.0000,10.8000,189.2000,1,1,NULL,'2020-07-07 16:53:41','2020-07-07 16:53:41'),(9,'LDH (Lactic Dehydrogenase)',22,'LDH','3-5 cc Clotted Blood/Serum','Routine','Sameday',NULL,NULL,400.0000,10.8000,389.2000,1,1,NULL,'2020-07-07 17:08:00','2020-07-07 17:08:00'),(10,'Albumin',10,'Albumin','3-5 cc Clotted Blood/Serum','Routine','Sameday',NULL,NULL,200.0000,10.8000,189.2000,1,1,NULL,'2020-07-07 17:12:01','2020-07-07 17:12:01'),(11,'Pregnancy Test',544,'Pregnancy Test','Random Urine','Routine','Sameday',NULL,NULL,100.0000,13.0000,87.0000,1,1,NULL,'2020-07-07 17:20:17','2020-07-10 17:39:05'),(12,'CRP (Quantitative)',545,'crp','3-5 cc Clotted Blood/Serum','Routine','Sameday',NULL,NULL,500.0000,153.3000,346.7000,1,1,NULL,'2020-07-07 17:29:26','2020-07-10 19:08:43'),(13,'CPK',22,'CPK','3-5 cc Clotted Blood/Serum','Routine','Sameday',NULL,NULL,500.0000,152.5000,347.5000,1,1,NULL,'2020-07-07 17:56:51','2020-07-10 19:10:51'),(14,'A/G Ratio',10,'A/G Ratio','3-5 cc Clotted Blood/Serum','Special','After 5 Days',NULL,NULL,100.0000,4.8000,95.2000,1,1,NULL,'2020-07-08 01:08:52','2020-07-08 01:16:34'),(15,'ACE (Angiotensin Converting Enzyme)',13,'ACE (Angiotensin Converting Enzyme)','3-5 cc Clotted Blood/Serum','Special',NULL,NULL,NULL,4.5000,4.5000,0.0000,1,1,NULL,'2020-07-08 01:20:58','2020-07-08 01:20:58'),(16,'ACTH',15,'ACTH','3-5 cc Blood in EDTA/Serum','Special','After 2 Days',NULL,NULL,10.8000,10.8000,0.0000,1,1,NULL,'2020-07-08 01:23:18','2020-07-08 01:23:18'),(17,'ANA',16,'ANA','3-5 cc Clotted Blood/Serum','Routine','same day',NULL,NULL,4.8000,4.8000,0.0000,1,1,NULL,'2020-07-08 01:25:21','2020-07-08 01:25:21'),(18,'APTT (Activated Partial Thromboplastin Time)',1,'APTT','Citrate Tube (From Lab)','Routine','Sameday',NULL,NULL,4.8000,4.8000,0.0000,1,1,NULL,'2020-07-08 03:03:25','2020-07-08 03:03:25'),(19,'Aldolase',13,'Aldolase','3-5 cc Clotted Blood/Serum','Special','Next Day',NULL,NULL,10.8000,10.8000,0.0000,1,1,NULL,'2020-07-08 03:09:59','2020-07-08 03:09:59'),(20,'Aldosterone Level',15,'Aldosterone Level','3-5 cc Clotted Blood/Serum','Special','After 1-Week',NULL,NULL,4.8000,4.8000,0.0000,1,1,NULL,'2020-07-08 03:12:45','2020-07-08 03:12:45'),(21,'Alkaline Phosphate',10,'Alkaline Phosphate','3-5 cc Clotted Blood/Serum','Routine','Same Day',NULL,NULL,4.8000,4.8000,0.0000,1,1,NULL,'2020-07-08 03:15:37','2020-07-08 03:15:37'),(22,'ALPHA 1-Anti Trypsin Level (L-1)',22,'ALPHA 1-Anti Trypsin Level (L-1)','3-5 cc Clotted Blood/Serum','Special','After 1-Week',NULL,NULL,4.8000,4.8000,0.0000,1,1,NULL,'2020-07-08 03:18:56','2020-07-08 03:18:56'),(23,'ALPHA Feto-protein (AFP)',23,'AFP','3-5 cc Clotted Blood/Serum','Routine','Nextday',NULL,NULL,4.8000,4.8000,0.0000,1,1,NULL,'2020-07-08 03:25:30','2020-07-08 03:25:30'),(24,'Ammonia (NH3)',26,'Ammonia (NH3)','3-5 cc Blood In EDTA','Special','Nextday',NULL,NULL,10.8000,10.8000,0.0000,1,1,NULL,'2020-07-08 03:31:50','2020-07-08 03:31:50'),(25,'Amylase',13,'Amylase','3-5 cc Clotted Blood/Serum','Routine','Sameday',NULL,NULL,350.0000,146.5000,203.5000,1,1,NULL,'2020-07-08 03:33:59','2020-07-10 18:51:39'),(26,'Amylase (Urine)',13,'Amylase (Urine)','24 Hrs Urine/Random Urine','Routine','Sameday',NULL,NULL,5.0000,5.0000,0.0000,1,1,NULL,'2020-07-08 03:35:50','2020-07-08 03:35:50'),(27,'Anti ds DNA',16,'Anti ds DNA','3-5 cc Clotted Blood/Serum','Special','After 1-Week',NULL,NULL,4.8000,4.8000,0.0000,1,1,NULL,'2020-07-08 03:52:36','2020-07-08 03:52:36'),(28,'Anti HBc lgG',45,'Anti HBc lgG','3-5 cc Clotted Blood/Serum','Special','After 1-Week',NULL,NULL,4.8000,4.8000,0.0000,1,1,NULL,'2020-07-08 03:54:44','2020-07-08 03:54:44'),(29,'Anti HBc lgM',45,'Anti HBc lgM','3-5 cc Clotted Blood/Serum','Special','After 1-Week',NULL,NULL,4.8000,4.8000,0.0000,1,1,NULL,'2020-07-08 03:57:04','2020-07-08 03:57:04'),(30,'Anti HBe',45,'Anti HBe','3-5 cc Clotted Blood/Serum','Routine','After 1-Week',NULL,NULL,4.8000,4.8000,0.0000,1,1,NULL,'2020-07-08 03:58:35','2020-07-08 03:58:35'),(31,'Anti HBs (ELISA)',45,'Anti HBs (ELISA)','3-5 cc Clotted Blood/Serum','Special','After 7 Days',NULL,NULL,4.8000,4.8000,0.0000,1,1,NULL,'2020-07-08 04:00:06','2020-07-08 04:00:06'),(32,'Anti HCV (Screening)',51,'Anti HCV (Screening)','3-5 cc Clotted Blood/Serum','Routine','same day',NULL,NULL,4.8000,4.8000,0.0000,1,1,NULL,'2020-07-08 04:02:39','2020-07-08 04:02:39'),(33,'Anti HCV (ELISA)',45,'Anti HCV (ELISA)','3-5 cc Clotted Blood/Serum','Special','Next Day',NULL,NULL,4.8000,4.8000,0.0000,1,1,NULL,'2020-07-08 04:05:51','2020-07-08 04:05:51'),(34,'Anti HEV lgG',45,'Anti HEV lgG','3-5 cc Clotted Blood/Serum','Special','After 3-Days',NULL,NULL,4.8000,4.8000,0.0000,1,1,NULL,'2020-07-08 04:07:32','2020-07-08 04:07:32'),(35,'Anti HEV lgM',45,'Anti HEV lgM','3-5 cc Clotted Blood/Serum','Special','After 3-Days',NULL,NULL,4.8000,4.8000,0.0000,1,1,NULL,'2020-07-08 04:11:30','2020-07-08 04:11:30'),(36,'Anti Sperm Antibodies',70,'Anti Sperm Antibodies','3-5 cc Clotted Blood/Serum','Special','After 1-Week',NULL,NULL,4.8000,4.8000,0.0000,1,1,NULL,'2020-07-08 04:13:36','2020-07-08 04:13:36'),(37,'Ascitic Fluid For Analysis (C/E)',78,'Ascitic Fluid For Analysis (C/E)','Specimen Fluid','Routine','Next Day',NULL,NULL,2.4000,2.4000,0.0000,1,1,NULL,'2020-07-08 04:29:05','2020-07-08 04:29:05'),(38,'ASOT',16,'ASOT','3-5 cc Clotted Blood/Serum','Routine','Sameday',NULL,NULL,2.4000,2.4000,0.0000,1,1,NULL,'2020-07-08 04:31:35','2020-07-08 04:31:35'),(39,'Beta HCG',15,'Beta HCG','3-5 cc Clotted Blood/Serum','Special','Next Day',NULL,NULL,2.0000,2.0000,0.0000,1,1,NULL,'2020-07-08 04:34:22','2020-07-08 04:34:22'),(40,'Bicarbonate (HCO3)',26,'Bicarbonate (HCO3)','3-5 cc Clotted Blood/Serum','Routine','Sameday',NULL,NULL,2.0000,2.0000,0.0000,1,1,NULL,'2020-07-08 04:36:23','2020-07-08 04:36:23'),(41,'Bilirubin Direct (Conjugated)',10,'Bilirubin Direct (Conjugated)','3-5 cc Clotted Blood/Serum','Routine','Sameday',NULL,NULL,2.0000,2.0000,0.0000,1,1,NULL,'2020-07-08 04:40:48','2020-07-08 04:40:48'),(42,'Bilirubin Total',10,'Bilirubin Total','3-5 cc Clotted Blood/Serum','Routine','Same day',NULL,NULL,2.0000,2.0000,0.0000,1,1,NULL,'2020-07-08 04:49:25','2020-07-08 04:49:25'),(43,'Bilirubin Indirect (Unconjugated)',10,'Bilirubin Indirect (Unconjugated)','3-5 cc Clotted Blood/Serum','Routine','Same Day',NULL,NULL,2.0000,2.0000,0.0000,1,1,NULL,'2020-07-08 04:51:26','2020-07-08 04:51:26'),(44,'Bleeding Time',1,'Bleeding Time','Contact Lab','Routine','Same Day',NULL,NULL,2.0000,2.0000,0.0000,1,1,NULL,'2020-07-08 04:53:54','2020-07-08 04:53:54'),(45,'RFT-Renal Function Tests',107,'RFT-Renal Function Tests','3-5 cc Clotted Blood/Serum','Routine','Sameday',NULL,NULL,700.0000,212.5000,487.5000,1,1,NULL,'2020-07-08 04:58:46','2020-07-10 19:01:28'),(46,'Blood Group & Rh Factor',106,'Blood Group & Rh Factor','3 cc Blood In EDTA','Routine','Same day',NULL,NULL,2.0000,2.0000,0.0000,1,1,NULL,'2020-07-08 05:02:44','2020-07-08 05:02:44'),(47,'BUN',119,'BUN','3-5 cc Clotted Blood/Serum','Routine','Same Day',NULL,NULL,2.0000,2.0000,0.0000,1,1,NULL,'2020-07-08 15:08:34','2020-07-08 15:08:34'),(48,'CEA',23,'CEA','3-5 cc Clotted Blood/Serum','Special','Next Day',NULL,NULL,2.0000,2.0000,0.0000,1,1,NULL,'2020-07-08 15:10:46','2020-07-08 15:10:46'),(49,'C-3',121,'C-3','3-5 cc Clotted Blood/Serum','Special','After 5-Days',NULL,NULL,2.0000,2.0000,0.0000,1,1,NULL,'2020-07-08 15:12:42','2020-07-08 15:12:42'),(50,'C-4',121,'C-4','3-5 cc Clotted Blood/Serum','Special','After 5-Days',NULL,NULL,2.0000,2.0000,0.0000,1,1,NULL,'2020-07-08 15:15:19','2020-07-08 15:15:19'),(51,'CA 125',23,'CA 125','3-5 cc Clotted Blood/Serum','Special','Same Day',NULL,NULL,2.0000,2.0000,0.0000,1,1,NULL,'2020-07-08 15:17:47','2020-07-08 15:17:47'),(52,'CA 19-9',23,'CA 19-9','3-5 cc Clotted Blood/Serum','Special','After 1-Week',NULL,NULL,2.0000,2.0000,0.0000,1,1,NULL,'2020-07-08 15:21:35','2020-07-08 15:21:35'),(53,'Calcium',26,'Calcium','3-5 cc Clotted Blood/Serum','Routine','Same Day',NULL,NULL,2.0000,2.0000,0.0000,1,1,NULL,'2020-07-08 15:43:55','2020-07-08 15:43:55'),(54,'Carbamazepine (Tegretol,Epilepin)',135,'Carbamazepine (Tegretol,Epilepin)','3-5 cc Clotted Blood/Serum','Special','After 2-Days',NULL,NULL,2.0000,2.0000,0.0000,1,1,NULL,'2020-07-08 15:45:57','2020-07-08 15:45:57'),(55,'Cardiac Enzymes (CPK,CKMB,SGOT,LDH)',22,'Cardiac Enzymes (CPK,CKMB,SGOT,LDH)','3-5 cc Clotted Blood/Serum','Routine','Next Day',NULL,NULL,2.0000,2.0000,0.0000,1,1,NULL,'2020-07-08 15:52:02','2020-07-08 15:52:02'),(56,'Chloride',26,'Chloride','3-5 cc Clotted Blood/Serum','Routine','Same Day',NULL,NULL,2.0000,2.0000,0.0000,1,1,NULL,'2020-07-08 15:55:27','2020-07-08 15:55:27'),(57,'Cholesterol',144,'Cholesterol','3-5 cc Clotted Blood/Serum','Routine','Same Day',NULL,NULL,2.0000,2.0000,0.0000,1,1,NULL,'2020-07-08 15:59:15','2020-07-08 15:59:15'),(59,'CK-MB',22,'CK-MB','3-5 cc Clotted Blood/Serum','Routine','Next Day',NULL,NULL,2.0000,2.0000,0.0000,1,1,NULL,'2020-07-08 20:36:04','2020-07-08 20:36:04'),(60,'Clotting Time',1,'Clotting Time','Contact Lab','Routine','Same Day',NULL,NULL,2.0000,2.0000,0.0000,1,1,NULL,'2020-07-08 20:40:09','2020-07-08 20:40:09'),(62,'CMV lgM',148,'CMV lgM','3-5 cc Clotted Blood/Serum','Special','After 2-Days',NULL,NULL,2.0000,2.0000,0.0000,1,1,NULL,'2020-07-08 20:58:32','2020-07-08 20:58:32'),(63,'Coomb\'s Test (Direct)',152,'Coomb\'s Test (Direct)','3 cc Blood in EDTA','Routine','Same Day',NULL,NULL,2.0000,2.0000,0.0000,1,1,NULL,'2020-07-08 21:01:24','2020-07-08 21:01:24'),(64,'Coomb\'s Test (Indirect)',152,'Coomb\'s Test (Indirect)','3-5 cc Clotted Blood/Serum','Routine','Same Day',NULL,NULL,2.0000,2.0000,0.0000,1,1,NULL,'2020-07-08 21:04:24','2020-07-08 21:04:24'),(65,'TSH',15,'tsh','3-5 cc Clotted Blood/Serum','Special','Sameday',NULL,NULL,1000.0000,336.8000,663.2000,1,1,NULL,'2020-07-10 16:10:01','2020-07-10 18:32:22'),(67,'Typhidot Test (IgG & IgM)',16,'Typhidot','3-5 cc Clotted Blood/Serum','Routine','Same Day',NULL,NULL,300.0000,100.8000,199.2000,1,1,NULL,'2020-07-10 16:21:03','2020-07-10 16:21:27'),(68,'LFT-Liver Functions Tests',10,'lft','3-5 cc Clotted Blood/Serum','Routine','Same Day',NULL,NULL,800.0000,18.8000,781.2000,1,1,NULL,'2020-07-10 16:37:35','2020-07-10 16:38:18'),(69,'SEMEN ANALYSIS',404,'semen analysis','semen','Routine','Sameday',NULL,NULL,250.0000,11.0000,239.0000,1,1,NULL,'2020-07-10 16:39:34','2020-07-10 16:39:34'),(71,'T3',15,'T3','3-5 cc Clotted Blood/Serum','Special','Sameday',NULL,NULL,1000.0000,282.5000,717.5000,1,1,NULL,'2020-07-10 16:53:42','2020-07-10 18:34:58'),(72,'widal test',531,'widal Test','3-5 cc Clotted Blood/Serum','Routine','Same day',NULL,'<p>Titres in excess of 1:80 are probably significant...</p>',100.0000,14.8000,85.2000,1,1,NULL,'2020-07-10 16:58:39','2020-07-10 16:58:39'),(73,'T4',15,'t4','3-5 cc Clotted Blood/Serum','Special','Sameday',NULL,NULL,1000.0000,282.5000,717.5000,1,1,NULL,'2020-07-10 17:01:19','2020-07-10 18:34:35'),(75,'Hcv pcr QN',1,'pcr hcv','3-5 cc Clotted Blood/Serum','Special','7 days',NULL,NULL,2500.0000,282.5000,2217.5000,1,1,NULL,'2020-07-10 17:15:17','2020-07-10 19:04:10'),(76,'HbA1c',13,'hba1c','Blood','Special','Sameday',NULL,NULL,1000.0000,462.5000,537.5000,1,1,NULL,'2020-07-10 17:35:01','2020-07-10 19:03:30'),(77,'FSH',15,'fsh','3-5 cc Clotted Blood/Serum','Special','Sameday',NULL,NULL,1000.0000,462.5000,537.5000,1,1,NULL,'2020-07-10 17:48:52','2020-07-10 19:04:45'),(78,'LH',15,'lh','3-5 cc Clotted Blood/Serum','Special','Sameday',NULL,NULL,1000.0000,462.5000,537.5000,1,1,NULL,'2020-07-10 17:55:37','2020-07-10 19:02:47'),(79,'Testosterone',15,'testo','3-5 cc Clotted Blood/Serum','Special','Sameday',NULL,NULL,1000.0000,462.5000,537.5000,1,1,NULL,'2020-07-10 18:01:33','2020-07-10 18:34:01'),(80,'Prolactin',15,'Prolactin','3-5 cc Clotted Blood/Serum','Special','Sameday',NULL,NULL,1000.0000,462.5000,537.5000,1,1,NULL,'2020-07-10 18:20:31','2020-07-10 19:02:05'),(81,'Brucella Test',547,'Brucella Test','3-5 cc Clotted Blood/Serum','Routine','Same day',NULL,NULL,200.0000,42.5000,157.5000,1,1,NULL,'2020-07-10 19:10:55','2020-07-10 19:43:09');
/*!40000 ALTER TABLE `tests` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `transaction_payments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transaction_payments` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_id` int(11) unsigned DEFAULT NULL,
  `business_id` int(11) DEFAULT NULL,
  `is_return` tinyint(1) NOT NULL DEFAULT 0 COMMENT 'Used during sales to return the change',
  `amount` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `method` enum('cash','card','cheque','bank_transfer','custom_pay_1','custom_pay_2','custom_pay_3','other') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `card_transaction_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `card_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `card_type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `card_holder_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `card_month` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `card_year` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `card_security` varchar(5) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `cheque_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_account_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `paid_on` datetime DEFAULT NULL,
  `created_by` int(11) NOT NULL,
  `payment_for` int(11) DEFAULT NULL,
  `parent_id` int(11) DEFAULT NULL,
  `note` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `document` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `payment_ref_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `account_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transaction_payments_transaction_id_foreign` (`transaction_id`),
  KEY `transaction_payments_created_by_index` (`created_by`),
  KEY `transaction_payments_parent_id_index` (`parent_id`),
  CONSTRAINT `transaction_payments_transaction_id_foreign` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=19 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `transaction_payments` WRITE;
/*!40000 ALTER TABLE `transaction_payments` DISABLE KEYS */;
INSERT INTO `transaction_payments` VALUES (1,1,1,0,300.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-04 18:19:21',1,1,NULL,NULL,NULL,'SP2020/0001',NULL,'2020-07-04 13:19:21','2020-07-04 13:19:21'),(2,2,1,0,150.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-04 19:05:51',1,1,NULL,NULL,NULL,'SP2020/0002',NULL,'2020-07-04 14:05:51','2020-07-04 14:05:51'),(3,3,1,0,300.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-07 11:26:34',1,1,NULL,NULL,NULL,'SP2020/0003',NULL,'2020-07-07 16:26:34','2020-07-07 16:26:34'),(4,4,1,0,100.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-07 11:41:21',1,1,NULL,NULL,NULL,'SP2020/0004',NULL,'2020-07-07 16:41:21','2020-07-07 16:41:21'),(5,5,1,0,300.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-07 13:15:53',1,2,NULL,NULL,NULL,'SP2020/0005',NULL,'2020-07-07 18:15:53','2020-07-07 18:15:53'),(7,7,1,0,2.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-08 11:25:20',1,1,NULL,NULL,NULL,'SP2020/0007',NULL,'2020-07-08 16:25:20','2020-07-08 16:25:20'),(8,8,1,0,300.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-09 09:10:09',1,1,NULL,NULL,NULL,'SP2020/0008',NULL,'2020-07-09 14:10:09','2020-07-09 14:10:09'),(11,10,1,0,300.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-09 18:02:43',1,1,NULL,NULL,NULL,'SP2020/0010',NULL,'2020-07-09 23:02:43','2020-07-09 23:02:43'),(12,11,1,0,100.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-10 12:02:50',1,1,NULL,NULL,NULL,'SP2020/0011',NULL,'2020-07-10 17:02:50','2020-07-10 17:02:50'),(14,13,1,0,2.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-10 14:41:12',1,1,NULL,NULL,NULL,'SP2020/0013',NULL,'2020-07-10 19:41:12','2020-07-10 19:41:12'),(15,14,1,0,600.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-10 14:49:04',1,3,NULL,NULL,NULL,'SP2020/0014',NULL,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(16,15,1,0,300.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-10 14:57:41',1,4,NULL,NULL,NULL,'SP2020/0015',NULL,'2020-07-10 19:57:41','2020-07-10 19:57:41'),(17,16,1,0,400.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-10 15:24:52',1,5,NULL,NULL,NULL,'SP2020/0016',NULL,'2020-07-10 20:24:52','2020-07-10 20:24:52'),(18,17,1,0,10.0000,'cash',NULL,NULL,NULL,'credit',NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-10 15:29:43',1,NULL,NULL,NULL,NULL,'SP2020/0017',NULL,'2020-07-10 20:29:43','2020-07-10 20:29:43');
/*!40000 ALTER TABLE `transaction_payments` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `transaction_sell_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transaction_sell_lines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `transaction_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `variation_id` int(10) unsigned NOT NULL,
  `quantity` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `quantity_returned` decimal(20,4) NOT NULL DEFAULT 0.0000,
  `unit_price_before_discount` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `unit_price` decimal(22,4) DEFAULT NULL COMMENT 'Sell price excluding tax',
  `line_discount_type` enum('fixed','percentage') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `line_discount_amount` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `unit_price_inc_tax` decimal(22,4) DEFAULT NULL COMMENT 'Sell price including tax',
  `item_tax` decimal(22,4) NOT NULL COMMENT 'Tax for one quantity',
  `tax_id` int(10) unsigned DEFAULT NULL,
  `discount_id` int(11) DEFAULT NULL,
  `lot_no_line_id` int(11) DEFAULT NULL,
  `sell_line_note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `res_service_staff_id` int(11) DEFAULT NULL,
  `res_line_order_status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `parent_sell_line_id` int(11) DEFAULT NULL,
  `children_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT '' COMMENT 'Type of children for the parent, like modifier or combo',
  `sub_unit_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transaction_sell_lines_transaction_id_foreign` (`transaction_id`),
  KEY `transaction_sell_lines_product_id_foreign` (`product_id`),
  KEY `transaction_sell_lines_variation_id_foreign` (`variation_id`),
  KEY `transaction_sell_lines_tax_id_foreign` (`tax_id`),
  KEY `transaction_sell_lines_children_type_index` (`children_type`),
  KEY `transaction_sell_lines_parent_sell_line_id_index` (`parent_sell_line_id`),
  CONSTRAINT `transaction_sell_lines_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transaction_sell_lines_tax_id_foreign` FOREIGN KEY (`tax_id`) REFERENCES `tax_rates` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transaction_sell_lines_transaction_id_foreign` FOREIGN KEY (`transaction_id`) REFERENCES `transactions` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transaction_sell_lines_variation_id_foreign` FOREIGN KEY (`variation_id`) REFERENCES `variations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `transaction_sell_lines` WRITE;
/*!40000 ALTER TABLE `transaction_sell_lines` DISABLE KEYS */;
INSERT INTO `transaction_sell_lines` VALUES (1,1,3,3,1.0000,0.0000,6.0000,6.0000,'fixed',0.0000,6.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,'2020-07-04 13:19:21','2020-07-04 13:19:21'),(2,1,4,4,1.0000,0.0000,4.8000,4.8000,'fixed',0.0000,4.8000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,'2020-07-04 13:19:21','2020-07-04 13:19:21'),(3,1,1,1,225.0000,0.0000,0.5300,0.5300,'fixed',0.0000,0.5300,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',7,'2020-07-04 13:19:21','2020-07-04 13:19:21'),(4,1,2,2,25.0000,0.0000,0.5300,0.5300,'fixed',0.0000,0.5300,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',7,'2020-07-04 13:19:21','2020-07-04 13:19:21'),(5,2,3,3,1.0000,0.0000,6.0000,6.0000,'fixed',0.0000,6.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,'2020-07-04 14:05:51','2020-07-04 14:05:51'),(6,2,4,4,1.0000,0.0000,4.8000,4.8000,'fixed',0.0000,4.8000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,'2020-07-04 14:05:51','2020-07-04 14:05:51'),(7,2,1,1,225.0000,0.0000,0.5300,0.5300,'fixed',0.0000,0.5300,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',7,'2020-07-04 14:05:51','2020-07-04 14:05:51'),(8,2,2,2,25.0000,0.0000,0.5300,0.5300,'fixed',0.0000,0.5300,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',7,'2020-07-04 14:05:51','2020-07-04 14:05:51'),(9,3,3,3,1.0000,0.0000,6.0000,6.0000,'fixed',0.0000,6.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,'2020-07-07 16:26:34','2020-07-07 16:26:34'),(10,3,6,6,1.0000,0.0000,65.0000,65.0000,'fixed',0.0000,65.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,'2020-07-07 16:26:34','2020-07-07 16:26:34'),(11,3,4,4,1.0000,0.0000,4.5000,4.5000,'fixed',0.0000,4.5000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,'2020-07-07 16:26:34','2020-07-07 16:26:34'),(12,4,12,12,1.0000,0.0000,7.0000,7.0000,'fixed',0.0000,7.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,'2020-07-07 16:41:21','2020-07-07 16:41:21'),(13,4,4,4,1.0000,0.0000,4.5000,4.5000,'fixed',0.0000,4.5000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',2,'2020-07-07 16:41:21','2020-07-07 16:41:21'),(14,5,3,3,1.0000,0.0000,6.0000,6.0000,'fixed',0.0000,6.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,'2020-07-07 18:15:53','2020-07-07 18:15:53'),(15,5,4,4,1.0000,0.0000,4.8000,4.8000,'fixed',0.0000,4.8000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',2,'2020-07-07 18:15:53','2020-07-07 18:15:53'),(16,5,1,1,225.0000,0.0000,0.5300,0.5300,'fixed',0.0000,0.5300,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',7,'2020-07-07 18:15:53','2020-07-07 18:15:53'),(17,5,2,2,25.0000,0.0000,0.5300,0.5300,'fixed',0.0000,0.5300,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',7,'2020-07-07 18:15:53','2020-07-07 18:15:53'),(19,7,17,17,1.0000,0.0000,2.0000,2.0000,'fixed',0.0000,2.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,'2020-07-08 16:25:20','2020-07-08 16:25:20'),(20,8,3,3,1.0000,0.0000,6.0000,6.0000,'fixed',0.0000,6.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,'2020-07-09 14:10:09','2020-07-09 14:10:09'),(21,8,4,4,1.0000,0.0000,4.8000,4.8000,'fixed',0.0000,4.8000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',2,'2020-07-09 14:10:09','2020-07-09 14:10:09'),(22,8,1,1,225.0000,0.0000,0.5300,0.5300,'fixed',0.0000,0.5300,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',7,'2020-07-09 14:10:09','2020-07-09 14:10:09'),(23,8,2,2,25.0000,0.0000,0.5300,0.5300,'fixed',0.0000,0.5300,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',7,'2020-07-09 14:10:09','2020-07-09 14:10:09'),(24,10,3,3,1.0000,0.0000,6.0000,6.0000,'fixed',0.0000,6.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,'2020-07-09 23:02:43','2020-07-09 23:02:43'),(25,10,4,4,1.0000,0.0000,4.8000,4.8000,'fixed',0.0000,4.8000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',2,'2020-07-09 23:02:43','2020-07-09 23:02:43'),(26,10,1,1,225.0000,0.0000,0.5300,0.5300,'fixed',0.0000,0.5300,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',7,'2020-07-09 23:02:43','2020-07-09 23:02:43'),(27,10,2,2,25.0000,0.0000,0.5300,0.5300,'fixed',0.0000,0.5300,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',7,'2020-07-09 23:02:43','2020-07-09 23:02:43'),(28,11,3,3,1.0000,0.0000,6.0000,6.0000,'fixed',0.0000,6.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,'2020-07-10 17:02:50','2020-07-10 17:02:50'),(29,11,4,4,1.0000,0.0000,4.8000,4.8000,'fixed',0.0000,4.8000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,'2020-07-10 17:02:50','2020-07-10 17:02:50'),(30,11,17,17,1.0000,0.0000,3.0000,3.0000,'fixed',0.0000,3.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,'2020-07-10 17:02:50','2020-07-10 17:02:50'),(31,11,10,10,1.0000,0.0000,1.0000,1.0000,'fixed',0.0000,1.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,'2020-07-10 17:02:50','2020-07-10 17:02:50'),(32,13,17,17,1.0000,0.0000,2.0000,2.0000,'fixed',0.0000,2.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,'2020-07-10 19:41:12','2020-07-10 19:41:12'),(33,14,3,3,1.0000,0.0000,6.0000,6.0000,'fixed',0.0000,6.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(34,14,4,4,1.0000,0.0000,4.8000,4.8000,'fixed',0.0000,4.8000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',2,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(35,14,1,1,225.0000,0.0000,0.5300,0.5300,'fixed',0.0000,0.5300,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',7,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(36,14,2,2,25.0000,0.0000,0.5300,0.5300,'fixed',0.0000,0.5300,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',7,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(37,14,7,7,1.0000,0.0000,6.0000,6.0000,'fixed',0.0000,6.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(38,14,8,8,1.0000,0.0000,4.5000,4.5000,'fixed',0.0000,4.5000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(39,14,9,9,1.0000,0.0000,9.0000,9.0000,'fixed',0.0000,9.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(40,14,10,10,1.0000,0.0000,1.0000,1.0000,'fixed',0.0000,1.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(41,14,11,11,1.0000,0.0000,1.0000,1.0000,'fixed',0.0000,1.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(42,14,17,17,1.0000,0.0000,2.5000,2.5000,'fixed',0.0000,2.5000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(43,14,3,3,1.0000,0.0000,6.0000,6.0000,'fixed',0.0000,6.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(44,14,5,5,0.2000,0.0000,0.4700,0.4700,'fixed',0.0000,0.4700,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',7,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(45,14,4,4,1.0000,0.0000,4.8000,4.8000,'fixed',0.0000,4.8000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',2,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(46,15,3,3,1.0000,0.0000,6.0000,6.0000,'fixed',0.0000,6.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,'2020-07-10 19:57:41','2020-07-10 19:57:41'),(47,15,5,5,0.2000,0.0000,0.4700,0.4700,'fixed',0.0000,0.4700,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',7,'2020-07-10 19:57:41','2020-07-10 19:57:41'),(48,15,4,4,1.0000,0.0000,4.8000,4.8000,'fixed',0.0000,4.8000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',2,'2020-07-10 19:57:41','2020-07-10 19:57:41'),(49,15,3,3,1.0000,0.0000,6.0000,6.0000,'fixed',0.0000,6.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,'2020-07-10 19:57:41','2020-07-10 19:57:41'),(50,15,4,4,1.0000,0.0000,4.8000,4.8000,'fixed',0.0000,4.8000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,'2020-07-10 19:57:41','2020-07-10 19:57:41'),(51,15,17,17,1.0000,0.0000,3.0000,3.0000,'fixed',0.0000,3.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,'2020-07-10 19:57:41','2020-07-10 19:57:41'),(52,15,10,10,1.0000,0.0000,1.0000,1.0000,'fixed',0.0000,1.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,'2020-07-10 19:57:41','2020-07-10 19:57:41'),(53,16,3,3,1.0000,0.0000,6.0000,6.0000,'fixed',0.0000,6.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,'2020-07-10 20:24:52','2020-07-10 20:24:52'),(54,16,4,4,1.0000,0.0000,4.8000,4.8000,'fixed',0.0000,4.8000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',2,'2020-07-10 20:24:52','2020-07-10 20:24:52'),(55,16,1,1,225.0000,0.0000,0.5300,0.5300,'fixed',0.0000,0.5300,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',7,'2020-07-10 20:24:52','2020-07-10 20:24:52'),(56,16,2,2,25.0000,0.0000,0.5300,0.5300,'fixed',0.0000,0.5300,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',7,'2020-07-10 20:24:52','2020-07-10 20:24:52'),(57,16,3,3,1.0000,0.0000,6.0000,6.0000,'fixed',0.0000,6.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,'2020-07-10 20:24:52','2020-07-10 20:24:52'),(58,16,4,4,1.0000,0.0000,4.8000,4.8000,'fixed',0.0000,4.8000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,'2020-07-10 20:24:52','2020-07-10 20:24:52'),(59,16,17,17,1.0000,0.0000,3.0000,3.0000,'fixed',0.0000,3.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,'2020-07-10 20:24:52','2020-07-10 20:24:52'),(60,16,10,10,1.0000,0.0000,1.0000,1.0000,'fixed',0.0000,1.0000,0.0000,NULL,NULL,NULL,'',NULL,NULL,NULL,'',NULL,'2020-07-10 20:24:52','2020-07-10 20:24:52');
/*!40000 ALTER TABLE `transaction_sell_lines` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `transaction_sell_lines_purchase_lines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transaction_sell_lines_purchase_lines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `sell_line_id` int(10) unsigned DEFAULT NULL COMMENT 'id from transaction_sell_lines',
  `stock_adjustment_line_id` int(10) unsigned DEFAULT NULL COMMENT 'id from stock_adjustment_lines',
  `purchase_line_id` int(10) unsigned NOT NULL COMMENT 'id from purchase_lines',
  `quantity` decimal(22,4) NOT NULL,
  `qty_returned` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `sell_line_id` (`sell_line_id`),
  KEY `stock_adjustment_line_id` (`stock_adjustment_line_id`),
  KEY `purchase_line_id` (`purchase_line_id`)
) ENGINE=InnoDB AUTO_INCREMENT=61 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `transaction_sell_lines_purchase_lines` WRITE;
/*!40000 ALTER TABLE `transaction_sell_lines_purchase_lines` DISABLE KEYS */;
INSERT INTO `transaction_sell_lines_purchase_lines` VALUES (1,1,NULL,0,1.0000,0.0000,'2020-07-04 13:19:21','2020-07-04 13:19:21'),(2,2,NULL,0,1.0000,0.0000,'2020-07-04 13:19:21','2020-07-04 13:19:21'),(3,3,NULL,0,225.0000,0.0000,'2020-07-04 13:19:21','2020-07-04 13:19:21'),(4,4,NULL,0,25.0000,0.0000,'2020-07-04 13:19:21','2020-07-04 13:19:21'),(5,5,NULL,0,1.0000,0.0000,'2020-07-04 14:05:51','2020-07-04 14:05:51'),(6,6,NULL,0,1.0000,0.0000,'2020-07-04 14:05:51','2020-07-04 14:05:51'),(7,7,NULL,0,225.0000,0.0000,'2020-07-04 14:05:51','2020-07-04 14:05:51'),(8,8,NULL,0,25.0000,0.0000,'2020-07-04 14:05:51','2020-07-04 14:05:51'),(9,9,NULL,0,1.0000,0.0000,'2020-07-07 16:26:34','2020-07-07 16:26:34'),(10,10,NULL,0,1.0000,0.0000,'2020-07-07 16:26:34','2020-07-07 16:26:34'),(11,11,NULL,0,1.0000,0.0000,'2020-07-07 16:26:34','2020-07-07 16:26:34'),(12,12,NULL,0,1.0000,0.0000,'2020-07-07 16:41:21','2020-07-07 16:41:21'),(13,13,NULL,0,1.0000,0.0000,'2020-07-07 16:41:21','2020-07-07 16:41:21'),(14,14,NULL,0,1.0000,0.0000,'2020-07-07 18:15:53','2020-07-07 18:15:53'),(15,15,NULL,0,1.0000,0.0000,'2020-07-07 18:15:53','2020-07-07 18:15:53'),(16,16,NULL,0,225.0000,0.0000,'2020-07-07 18:15:53','2020-07-07 18:15:53'),(17,17,NULL,0,25.0000,0.0000,'2020-07-07 18:15:53','2020-07-07 18:15:53'),(19,19,NULL,0,1.0000,0.0000,'2020-07-08 16:25:20','2020-07-08 16:25:20'),(20,20,NULL,0,1.0000,0.0000,'2020-07-09 14:10:09','2020-07-09 14:10:09'),(21,21,NULL,0,1.0000,0.0000,'2020-07-09 14:10:09','2020-07-09 14:10:09'),(22,22,NULL,0,225.0000,0.0000,'2020-07-09 14:10:09','2020-07-09 14:10:09'),(23,23,NULL,0,25.0000,0.0000,'2020-07-09 14:10:09','2020-07-09 14:10:09'),(24,24,NULL,0,1.0000,0.0000,'2020-07-09 23:02:43','2020-07-09 23:02:43'),(25,25,NULL,0,1.0000,0.0000,'2020-07-09 23:02:43','2020-07-09 23:02:43'),(26,26,NULL,0,225.0000,0.0000,'2020-07-09 23:02:43','2020-07-09 23:02:43'),(27,27,NULL,0,25.0000,0.0000,'2020-07-09 23:02:43','2020-07-09 23:02:43'),(28,28,NULL,0,1.0000,0.0000,'2020-07-10 17:02:50','2020-07-10 17:02:50'),(29,29,NULL,0,1.0000,0.0000,'2020-07-10 17:02:50','2020-07-10 17:02:50'),(30,30,NULL,0,1.0000,0.0000,'2020-07-10 17:02:50','2020-07-10 17:02:50'),(31,31,NULL,0,1.0000,0.0000,'2020-07-10 17:02:50','2020-07-10 17:02:50'),(32,32,NULL,0,1.0000,0.0000,'2020-07-10 19:41:12','2020-07-10 19:41:12'),(33,33,NULL,0,1.0000,0.0000,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(34,34,NULL,0,1.0000,0.0000,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(35,35,NULL,0,225.0000,0.0000,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(36,36,NULL,0,25.0000,0.0000,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(37,37,NULL,0,1.0000,0.0000,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(38,38,NULL,0,1.0000,0.0000,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(39,39,NULL,0,1.0000,0.0000,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(40,40,NULL,0,1.0000,0.0000,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(41,41,NULL,0,1.0000,0.0000,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(42,42,NULL,0,1.0000,0.0000,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(43,43,NULL,0,1.0000,0.0000,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(44,44,NULL,0,0.2000,0.0000,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(45,45,NULL,0,1.0000,0.0000,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(46,46,NULL,0,1.0000,0.0000,'2020-07-10 19:57:41','2020-07-10 19:57:41'),(47,47,NULL,0,0.2000,0.0000,'2020-07-10 19:57:41','2020-07-10 19:57:41'),(48,48,NULL,0,1.0000,0.0000,'2020-07-10 19:57:41','2020-07-10 19:57:41'),(49,49,NULL,0,1.0000,0.0000,'2020-07-10 19:57:41','2020-07-10 19:57:41'),(50,50,NULL,0,1.0000,0.0000,'2020-07-10 19:57:41','2020-07-10 19:57:41'),(51,51,NULL,0,1.0000,0.0000,'2020-07-10 19:57:41','2020-07-10 19:57:41'),(52,52,NULL,0,1.0000,0.0000,'2020-07-10 19:57:42','2020-07-10 19:57:42'),(53,53,NULL,0,1.0000,0.0000,'2020-07-10 20:24:53','2020-07-10 20:24:53'),(54,54,NULL,0,1.0000,0.0000,'2020-07-10 20:24:53','2020-07-10 20:24:53'),(55,55,NULL,0,225.0000,0.0000,'2020-07-10 20:24:53','2020-07-10 20:24:53'),(56,56,NULL,0,25.0000,0.0000,'2020-07-10 20:24:53','2020-07-10 20:24:53'),(57,57,NULL,0,1.0000,0.0000,'2020-07-10 20:24:53','2020-07-10 20:24:53'),(58,58,NULL,0,1.0000,0.0000,'2020-07-10 20:24:53','2020-07-10 20:24:53'),(59,59,NULL,0,1.0000,0.0000,'2020-07-10 20:24:53','2020-07-10 20:24:53'),(60,60,NULL,0,1.0000,0.0000,'2020-07-10 20:24:53','2020-07-10 20:24:53');
/*!40000 ALTER TABLE `transaction_sell_lines_purchase_lines` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `transactions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `transactions` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `location_id` int(10) unsigned DEFAULT NULL,
  `res_table_id` int(10) unsigned DEFAULT NULL COMMENT 'fields to restaurant module',
  `res_waiter_id` int(10) unsigned DEFAULT NULL COMMENT 'fields to restaurant module',
  `res_order_status` enum('received','cooked','served') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `type` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `sub_type` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `status` enum('received','pending','ordered','draft','final') COLLATE utf8mb4_unicode_ci NOT NULL,
  `is_quotation` tinyint(1) NOT NULL DEFAULT 0,
  `payment_status` enum('paid','due','partial') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `adjustment_type` enum('normal','abnormal') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_id` int(11) unsigned DEFAULT NULL,
  `doctor_id` int(10) unsigned DEFAULT NULL,
  `appointment_id` int(10) unsigned DEFAULT NULL,
  `customer_group_id` int(11) DEFAULT NULL COMMENT 'used to add customer group while selling',
  `invoice_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `ref_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subscription_no` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `subscription_repeat_on` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `transaction_date` datetime NOT NULL,
  `total_before_tax` decimal(22,4) NOT NULL DEFAULT 0.0000 COMMENT 'Total before the purchase/invoice tax, this includeds the indivisual product tax',
  `tax_id` int(10) unsigned DEFAULT NULL,
  `tax_amount` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `discount_type` enum('fixed','percentage') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `discount_amount` decimal(22,4) DEFAULT 0.0000,
  `rp_redeemed` int(11) NOT NULL DEFAULT 0 COMMENT 'rp is the short form of reward points',
  `rp_redeemed_amount` decimal(22,4) NOT NULL DEFAULT 0.0000 COMMENT 'rp is the short form of reward points',
  `shipping_details` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_status` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `delivered_to` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `shipping_charges` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `additional_notes` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `staff_note` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `round_off_amount` decimal(22,4) NOT NULL DEFAULT 0.0000 COMMENT 'Difference of rounded total and actual total',
  `final_total` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `expense_category_id` int(10) unsigned DEFAULT NULL,
  `expense_for` int(10) unsigned DEFAULT NULL,
  `commission_agent` int(11) DEFAULT NULL,
  `document` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_direct_sale` tinyint(1) NOT NULL DEFAULT 0,
  `is_suspend` tinyint(1) NOT NULL DEFAULT 0,
  `exchange_rate` decimal(20,3) NOT NULL DEFAULT 1.000,
  `total_amount_recovered` decimal(22,4) DEFAULT NULL COMMENT 'Used for stock adjustment.',
  `transfer_parent_id` int(11) DEFAULT NULL,
  `return_parent_id` int(11) DEFAULT NULL,
  `opening_stock_product_id` int(11) DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `ref_by` int(10) unsigned DEFAULT NULL,
  `import_batch` int(11) DEFAULT NULL,
  `import_time` datetime DEFAULT NULL,
  `types_of_service_id` int(11) DEFAULT NULL,
  `packing_charge` decimal(22,4) DEFAULT NULL,
  `packing_charge_type` enum('fixed','percent') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `service_custom_field_1` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `service_custom_field_2` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `service_custom_field_3` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `service_custom_field_4` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_created_from_api` tinyint(1) NOT NULL DEFAULT 0,
  `essentials_duration` decimal(8,2) NOT NULL,
  `essentials_duration_unit` varchar(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `essentials_amount_per_unit_duration` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `essentials_allowances` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `essentials_deductions` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `rp_earned` int(11) NOT NULL DEFAULT 0 COMMENT 'rp is the short form of reward points',
  `order_addresses` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `is_recurring` tinyint(1) NOT NULL DEFAULT 0,
  `recur_interval` double(22,4) DEFAULT NULL,
  `recur_interval_type` enum('days','months','years') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `recur_repetitions` int(11) DEFAULT NULL,
  `recur_stopped_on` datetime DEFAULT NULL,
  `recur_parent_id` int(11) DEFAULT NULL,
  `invoice_token` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `pay_term_number` int(11) DEFAULT NULL,
  `pay_term_type` enum('days','months') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `selling_price_group_id` int(11) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `transactions_tax_id_foreign` (`tax_id`),
  KEY `transactions_business_id_index` (`business_id`),
  KEY `transactions_type_index` (`type`),
  KEY `transactions_contact_id_index` (`contact_id`),
  KEY `transactions_transaction_date_index` (`transaction_date`),
  KEY `transactions_created_by_index` (`created_by`),
  KEY `transactions_location_id_index` (`location_id`),
  KEY `transactions_expense_for_foreign` (`expense_for`),
  KEY `transactions_expense_category_id_index` (`expense_category_id`),
  KEY `transactions_sub_type_index` (`sub_type`),
  KEY `transactions_return_parent_id_index` (`return_parent_id`),
  KEY `type` (`type`),
  KEY `transactions_ref_by_foreign` (`ref_by`),
  KEY `transactions_doctor_id_foreign` (`doctor_id`),
  KEY `transactions_appointment_id_index` (`appointment_id`),
  CONSTRAINT `transactions_appointment_id_foreign` FOREIGN KEY (`appointment_id`) REFERENCES `appointments` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transactions_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transactions_contact_id_foreign` FOREIGN KEY (`contact_id`) REFERENCES `contacts` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transactions_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transactions_doctor_id_foreign` FOREIGN KEY (`doctor_id`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transactions_expense_category_id_foreign` FOREIGN KEY (`expense_category_id`) REFERENCES `expense_categories` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transactions_expense_for_foreign` FOREIGN KEY (`expense_for`) REFERENCES `users` (`id`) ON DELETE CASCADE,
  CONSTRAINT `transactions_location_id_foreign` FOREIGN KEY (`location_id`) REFERENCES `business_locations` (`id`),
  CONSTRAINT `transactions_ref_by_foreign` FOREIGN KEY (`ref_by`) REFERENCES `users` (`id`),
  CONSTRAINT `transactions_tax_id_foreign` FOREIGN KEY (`tax_id`) REFERENCES `tax_rates` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=18 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `transactions` WRITE;
/*!40000 ALTER TABLE `transactions` DISABLE KEYS */;
INSERT INTO `transactions` VALUES (1,1,2,NULL,NULL,NULL,'lab_sell',NULL,'final',0,'paid',NULL,1,NULL,NULL,NULL,'0001','',NULL,NULL,'2020-07-04 18:19:21',300.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,0.0000,300.0000,NULL,NULL,3,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,3,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,0,NULL,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2020-07-04 13:19:21','2020-07-04 13:19:21'),(2,1,2,NULL,NULL,NULL,'lab_sell',NULL,'final',0,'paid',NULL,1,NULL,NULL,NULL,'0002','',NULL,NULL,'2020-07-04 19:05:51',150.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,0.0000,150.0000,NULL,NULL,3,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,3,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,0,NULL,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2020-07-04 14:05:51','2020-07-04 14:05:51'),(3,1,2,NULL,NULL,NULL,'lab_sell',NULL,'final',0,'paid',NULL,1,NULL,NULL,NULL,'0003','',NULL,NULL,'2020-07-07 11:26:34',300.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,0.0000,300.0000,NULL,NULL,3,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,3,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,0,NULL,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2020-07-07 16:26:34','2020-07-07 16:26:34'),(4,1,2,NULL,NULL,NULL,'lab_sell',NULL,'final',0,'paid',NULL,1,NULL,NULL,NULL,'0004','',NULL,NULL,'2020-07-07 11:41:21',100.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,0.0000,100.0000,NULL,NULL,3,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,3,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,0,NULL,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2020-07-07 16:41:21','2020-07-07 16:41:21'),(5,1,2,NULL,NULL,NULL,'lab_sell',NULL,'final',0,'paid',NULL,2,NULL,NULL,NULL,'0005','',NULL,NULL,'2020-07-07 13:15:53',300.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,0.0000,300.0000,NULL,NULL,16,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,16,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,0,NULL,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2020-07-07 18:15:53','2020-07-07 18:15:53'),(7,1,2,NULL,NULL,NULL,'lab_sell',NULL,'final',0,'paid',NULL,1,NULL,NULL,NULL,'0007','',NULL,NULL,'2020-07-08 11:25:20',2.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,0.0000,2.0000,NULL,NULL,3,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,3,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,0,NULL,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2020-07-08 16:25:20','2020-07-08 16:25:20'),(8,1,2,NULL,NULL,NULL,'lab_sell',NULL,'final',0,'paid',NULL,1,NULL,NULL,NULL,'0008','',NULL,NULL,'2020-07-09 09:10:08',300.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,0.0000,300.0000,NULL,NULL,4,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,4,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,0,NULL,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2020-07-09 14:10:08','2020-07-09 14:10:09'),(10,1,2,NULL,NULL,NULL,'lab_sell',NULL,'final',0,'paid',NULL,1,NULL,NULL,NULL,'0009','',NULL,NULL,'2020-07-09 18:02:43',300.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,0.0000,300.0000,NULL,NULL,4,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,4,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,0,NULL,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2020-07-09 23:02:43','2020-07-09 23:02:43'),(11,1,2,NULL,NULL,NULL,'lab_sell',NULL,'final',0,'paid',NULL,1,NULL,NULL,NULL,'0010','',NULL,NULL,'2020-07-10 12:02:50',100.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,0.0000,100.0000,NULL,NULL,3,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,3,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,0,NULL,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2020-07-10 17:02:50','2020-07-10 17:02:50'),(13,1,2,NULL,NULL,NULL,'lab_sell',NULL,'final',0,'paid',NULL,1,NULL,NULL,NULL,'0011','',NULL,NULL,'2020-07-10 14:41:12',2.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,0.0000,2.0000,NULL,NULL,3,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,3,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,0,NULL,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2020-07-10 19:41:12','2020-07-10 19:41:12'),(14,1,2,NULL,NULL,NULL,'lab_sell',NULL,'final',0,'paid',NULL,3,NULL,NULL,NULL,'0012','',NULL,NULL,'2020-07-10 14:49:04',600.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,0.0000,600.0000,NULL,NULL,4,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,4,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,0,NULL,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(15,1,2,NULL,NULL,NULL,'lab_sell',NULL,'final',0,'paid',NULL,4,NULL,NULL,NULL,'0013','',NULL,NULL,'2020-07-10 14:57:41',300.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,0.0000,300.0000,NULL,NULL,5,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,5,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,0,NULL,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2020-07-10 19:57:41','2020-07-10 19:57:41'),(16,1,2,NULL,NULL,NULL,'lab_sell',NULL,'final',0,'paid',NULL,5,NULL,NULL,NULL,'0014','',NULL,NULL,'2020-07-10 15:24:52',400.0000,NULL,0.0000,'percentage',0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,0.0000,400.0000,NULL,NULL,4,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,4,NULL,NULL,NULL,0.0000,NULL,NULL,NULL,NULL,NULL,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,0,NULL,'days',0,NULL,NULL,NULL,NULL,NULL,0,'2020-07-10 20:24:52','2020-07-10 20:24:53'),(17,1,2,NULL,NULL,NULL,'doctorexpense',NULL,'final',0,'partial',NULL,NULL,NULL,NULL,NULL,NULL,'EP2020/0003',NULL,NULL,'2020-07-10 15:29:00',100.0000,NULL,0.0000,NULL,0.0000,0,0.0000,NULL,NULL,NULL,NULL,0.0000,NULL,NULL,0.0000,100.0000,NULL,NULL,NULL,NULL,0,0,1.000,NULL,NULL,NULL,NULL,1,4,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,0,0.00,NULL,0.0000,NULL,NULL,0,NULL,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-10 20:29:43','2020-07-10 20:29:43');
/*!40000 ALTER TABLE `transactions` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `types_of_services`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `types_of_services` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `business_id` int(11) NOT NULL,
  `location_price_group` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `packing_charge` decimal(22,4) DEFAULT NULL,
  `packing_charge_type` enum('fixed','percent') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `enable_custom_fields` tinyint(1) NOT NULL DEFAULT 0,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `types_of_services_business_id_index` (`business_id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `types_of_services` WRITE;
/*!40000 ALTER TABLE `types_of_services` DISABLE KEYS */;
/*!40000 ALTER TABLE `types_of_services` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `units`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `units` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `actual_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `short_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `allow_decimal` tinyint(1) NOT NULL,
  `base_unit_id` int(11) DEFAULT NULL,
  `base_unit_multiplier` decimal(20,4) DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `units_business_id_foreign` (`business_id`),
  KEY `units_created_by_foreign` (`created_by`),
  KEY `units_base_unit_id_index` (`base_unit_id`),
  CONSTRAINT `units_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `units_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=8 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `units` WRITE;
/*!40000 ALTER TABLE `units` DISABLE KEYS */;
INSERT INTO `units` VALUES (1,1,'Pieces','Pc(s)',0,NULL,NULL,1,NULL,'2020-07-04 12:23:41','2020-07-04 12:23:41'),(2,1,'ML','ML',1,NULL,NULL,1,NULL,'2020-07-04 12:17:24','2020-07-04 12:17:44'),(3,1,'20 litter','20 litter',1,2,20000.0000,1,NULL,'2020-07-04 12:18:51','2020-07-04 12:21:26'),(4,1,'15Litter','15Litter',1,2,15000.0000,1,NULL,'2020-07-04 12:22:41','2020-07-04 12:22:41'),(5,1,'10Litter','10Litter',1,2,10000.0000,1,NULL,'2020-07-04 12:23:07','2020-07-04 12:23:07'),(6,1,'500 ml','500 ml',1,2,500.0000,1,NULL,'2020-07-04 12:23:33','2020-07-04 12:23:33'),(7,1,'1ml','1ml',1,2,1.0000,1,NULL,'2020-07-04 12:26:33','2020-07-04 12:26:33');
/*!40000 ALTER TABLE `units` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `use_product_tests`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `use_product_tests` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `test_id` int(10) unsigned NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `variation_id` int(10) unsigned NOT NULL,
  `unit_id` int(10) unsigned NOT NULL,
  `sub_unit_id` int(11) DEFAULT NULL,
  `base_unit_multiplier` decimal(20,4) DEFAULT NULL,
  `quantity` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `purchase_price` decimal(22,4) DEFAULT NULL COMMENT 'purchase price excluding tax',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `use_product_tests_test_id_foreign` (`test_id`),
  KEY `use_product_tests_product_id_foreign` (`product_id`),
  KEY `use_product_tests_variation_id_foreign` (`variation_id`),
  KEY `use_product_tests_unit_id_foreign` (`unit_id`),
  CONSTRAINT `use_product_tests_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `use_product_tests_test_id_foreign` FOREIGN KEY (`test_id`) REFERENCES `tests` (`id`) ON DELETE CASCADE,
  CONSTRAINT `use_product_tests_unit_id_foreign` FOREIGN KEY (`unit_id`) REFERENCES `units` (`id`) ON DELETE CASCADE,
  CONSTRAINT `use_product_tests_variation_id_foreign` FOREIGN KEY (`variation_id`) REFERENCES `variations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=271 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `use_product_tests` WRITE;
/*!40000 ALTER TABLE `use_product_tests` DISABLE KEYS */;
INSERT INTO `use_product_tests` VALUES (35,7,4,4,1,1,NULL,1.0000,4.8000,'2020-07-07 16:23:03','2020-07-07 16:23:03'),(39,5,3,3,1,1,NULL,1.0000,6.0000,'2020-07-07 16:31:36','2020-07-07 16:31:36'),(40,5,6,6,1,1,NULL,1.0000,65.0000,'2020-07-07 16:31:36','2020-07-07 16:31:36'),(41,5,4,4,1,2,NULL,1.0000,4.8000,'2020-07-07 16:31:36','2020-07-07 16:31:36'),(42,4,3,3,1,1,NULL,1.0000,6.0000,'2020-07-07 16:34:20','2020-07-07 16:34:20'),(43,4,5,5,2,7,1.0000,0.2000,0.4700,'2020-07-07 16:34:20','2020-07-07 16:34:20'),(44,4,4,4,1,2,NULL,1.0000,4.8000,'2020-07-07 16:34:20','2020-07-07 16:34:20'),(45,2,3,3,1,1,NULL,1.0000,6.0000,'2020-07-07 16:36:03','2020-07-07 16:36:03'),(46,2,4,4,1,2,NULL,1.0000,4.8000,'2020-07-07 16:36:03','2020-07-07 16:36:03'),(47,2,1,1,2,7,1.0000,225.0000,0.5300,'2020-07-07 16:36:03','2020-07-07 16:36:03'),(48,2,2,2,2,7,1.0000,25.0000,0.5300,'2020-07-07 16:36:03','2020-07-07 16:36:03'),(49,1,3,3,1,1,NULL,1.0000,6.0000,'2020-07-07 16:37:56','2020-07-07 16:37:56'),(50,1,4,4,1,2,NULL,1.0000,4.8000,'2020-07-07 16:37:56','2020-07-07 16:37:56'),(51,1,1,1,2,7,1.0000,225.0000,0.5300,'2020-07-07 16:37:56','2020-07-07 16:37:56'),(52,1,2,2,2,7,1.0000,25.0000,0.5300,'2020-07-07 16:37:56','2020-07-07 16:37:56'),(53,6,12,12,1,1,NULL,1.0000,7.0000,'2020-07-07 16:40:22','2020-07-07 16:40:22'),(54,6,4,4,1,2,NULL,1.0000,4.5000,'2020-07-07 16:40:22','2020-07-07 16:40:22'),(57,8,14,14,1,1,NULL,1.0000,6.0000,'2020-07-07 16:54:01','2020-07-07 16:54:01'),(58,8,4,4,1,1,NULL,1.0000,4.8000,'2020-07-07 16:54:01','2020-07-07 16:54:01'),(64,9,14,14,1,1,NULL,1.0000,6.0000,'2020-07-07 17:08:00','2020-07-07 17:08:00'),(65,9,4,4,1,1,NULL,1.0000,4.8000,'2020-07-07 17:08:00','2020-07-07 17:08:00'),(66,10,14,14,1,1,NULL,1.0000,6.0000,'2020-07-07 17:12:01','2020-07-07 17:12:01'),(67,10,4,4,1,1,NULL,1.0000,4.8000,'2020-07-07 17:12:01','2020-07-07 17:12:01'),(75,3,7,7,1,1,NULL,1.0000,6.0000,'2020-07-07 17:30:11','2020-07-07 17:30:11'),(76,3,8,8,1,1,NULL,1.0000,4.5000,'2020-07-07 17:30:11','2020-07-07 17:30:11'),(77,3,9,9,1,1,NULL,1.0000,9.0000,'2020-07-07 17:30:11','2020-07-07 17:30:11'),(78,3,10,10,1,1,NULL,1.0000,1.0000,'2020-07-07 17:30:11','2020-07-07 17:30:11'),(79,3,11,11,1,1,NULL,1.0000,1.0000,'2020-07-07 17:30:11','2020-07-07 17:30:11'),(80,3,17,17,1,1,NULL,1.0000,2.5000,'2020-07-07 17:30:11','2020-07-07 17:30:11'),(85,14,4,4,1,1,NULL,1.0000,4.8000,'2020-07-08 01:16:34','2020-07-08 01:16:34'),(86,15,4,4,1,1,NULL,1.0000,4.5000,'2020-07-08 01:20:58','2020-07-08 01:20:58'),(87,16,3,3,1,1,NULL,1.0000,6.0000,'2020-07-08 01:23:18','2020-07-08 01:23:18'),(88,16,4,4,1,1,NULL,1.0000,4.8000,'2020-07-08 01:23:18','2020-07-08 01:23:18'),(89,17,4,4,1,1,NULL,1.0000,4.8000,'2020-07-08 01:25:21','2020-07-08 01:25:21'),(90,18,4,4,1,1,NULL,1.0000,4.8000,'2020-07-08 03:03:25','2020-07-08 03:03:25'),(91,19,3,3,1,1,NULL,1.0000,6.0000,'2020-07-08 03:09:59','2020-07-08 03:09:59'),(92,19,4,4,1,1,NULL,1.0000,4.8000,'2020-07-08 03:09:59','2020-07-08 03:09:59'),(93,20,4,4,1,1,NULL,1.0000,4.8000,'2020-07-08 03:12:45','2020-07-08 03:12:45'),(94,21,4,4,1,1,NULL,1.0000,4.8000,'2020-07-08 03:15:37','2020-07-08 03:15:37'),(95,22,4,4,1,1,NULL,1.0000,4.8000,'2020-07-08 03:18:56','2020-07-08 03:18:56'),(96,23,4,4,1,1,NULL,1.0000,4.8000,'2020-07-08 03:25:30','2020-07-08 03:25:30'),(97,24,3,3,1,1,NULL,1.0000,6.0000,'2020-07-08 03:31:50','2020-07-08 03:31:50'),(98,24,4,4,1,1,NULL,1.0000,4.8000,'2020-07-08 03:31:50','2020-07-08 03:31:50'),(100,26,7,7,1,1,NULL,1.0000,5.0000,'2020-07-08 03:35:50','2020-07-08 03:35:50'),(101,27,4,4,1,1,NULL,1.0000,4.8000,'2020-07-08 03:52:36','2020-07-08 03:52:36'),(102,28,4,4,1,1,NULL,1.0000,4.8000,'2020-07-08 03:54:44','2020-07-08 03:54:44'),(103,29,4,4,1,1,NULL,1.0000,4.8000,'2020-07-08 03:57:04','2020-07-08 03:57:04'),(104,30,4,4,1,1,NULL,1.0000,4.8000,'2020-07-08 03:58:35','2020-07-08 03:58:35'),(105,31,4,4,1,1,NULL,1.0000,4.8000,'2020-07-08 04:00:06','2020-07-08 04:00:06'),(106,32,4,4,1,1,NULL,1.0000,4.8000,'2020-07-08 04:02:39','2020-07-08 04:02:39'),(107,33,4,4,1,1,NULL,1.0000,4.8000,'2020-07-08 04:05:51','2020-07-08 04:05:51'),(108,34,4,4,1,1,NULL,1.0000,4.8000,'2020-07-08 04:07:32','2020-07-08 04:07:32'),(109,35,4,4,1,1,NULL,1.0000,4.8000,'2020-07-08 04:11:30','2020-07-08 04:11:30'),(110,36,4,4,1,1,NULL,1.0000,4.8000,'2020-07-08 04:13:36','2020-07-08 04:13:36'),(111,37,17,17,1,1,NULL,1.0000,2.4000,'2020-07-08 04:29:05','2020-07-08 04:29:05'),(112,38,17,17,1,1,NULL,1.0000,2.4000,'2020-07-08 04:31:35','2020-07-08 04:31:35'),(113,39,17,17,1,1,NULL,1.0000,2.0000,'2020-07-08 04:34:22','2020-07-08 04:34:22'),(114,40,17,17,1,1,NULL,1.0000,2.0000,'2020-07-08 04:36:23','2020-07-08 04:36:23'),(115,41,17,17,1,1,NULL,1.0000,2.0000,'2020-07-08 04:40:48','2020-07-08 04:40:48'),(116,42,17,17,1,1,NULL,1.0000,2.0000,'2020-07-08 04:49:25','2020-07-08 04:49:25'),(117,43,17,17,1,1,NULL,1.0000,2.0000,'2020-07-08 04:51:26','2020-07-08 04:51:26'),(118,44,17,17,1,1,NULL,1.0000,2.0000,'2020-07-08 04:53:54','2020-07-08 04:53:54'),(120,46,17,17,1,1,NULL,1.0000,2.0000,'2020-07-08 05:02:44','2020-07-08 05:02:44'),(121,47,17,17,1,1,NULL,1.0000,2.0000,'2020-07-08 15:08:34','2020-07-08 15:08:34'),(122,48,17,17,1,1,NULL,1.0000,2.0000,'2020-07-08 15:10:46','2020-07-08 15:10:46'),(123,49,17,17,1,1,NULL,1.0000,2.0000,'2020-07-08 15:12:42','2020-07-08 15:12:42'),(124,50,17,17,1,1,NULL,1.0000,2.0000,'2020-07-08 15:15:19','2020-07-08 15:15:19'),(125,51,17,17,1,1,NULL,1.0000,2.0000,'2020-07-08 15:17:47','2020-07-08 15:17:47'),(126,52,17,17,1,1,NULL,1.0000,2.0000,'2020-07-08 15:21:35','2020-07-08 15:21:35'),(127,53,17,17,1,1,NULL,1.0000,2.0000,'2020-07-08 15:43:55','2020-07-08 15:43:55'),(128,54,17,17,1,1,NULL,1.0000,2.0000,'2020-07-08 15:45:57','2020-07-08 15:45:57'),(129,55,17,17,1,1,NULL,1.0000,2.0000,'2020-07-08 15:52:02','2020-07-08 15:52:02'),(130,56,17,17,1,1,NULL,1.0000,2.0000,'2020-07-08 15:55:27','2020-07-08 15:55:27'),(131,57,17,17,1,1,NULL,1.0000,2.0000,'2020-07-08 15:59:15','2020-07-08 15:59:15'),(132,59,17,17,1,1,NULL,1.0000,2.0000,'2020-07-08 20:36:04','2020-07-08 20:36:04'),(133,60,17,17,1,1,NULL,1.0000,2.0000,'2020-07-08 20:40:09','2020-07-08 20:40:09'),(134,62,17,17,1,1,NULL,1.0000,2.0000,'2020-07-08 20:58:32','2020-07-08 20:58:32'),(135,63,17,17,1,1,NULL,1.0000,2.0000,'2020-07-08 21:01:24','2020-07-08 21:01:24'),(136,64,17,17,1,1,NULL,1.0000,2.0000,'2020-07-08 21:04:24','2020-07-08 21:04:24'),(143,67,4,4,1,1,NULL,1.0000,4.8000,'2020-07-10 16:21:27','2020-07-10 16:21:27'),(144,67,3,3,1,1,NULL,1.0000,6.0000,'2020-07-10 16:21:27','2020-07-10 16:21:27'),(145,67,19,19,1,1,NULL,1.0000,90.0000,'2020-07-10 16:21:27','2020-07-10 16:21:27'),(151,68,16,16,1,1,NULL,1.0000,6.0000,'2020-07-10 16:38:18','2020-07-10 16:38:18'),(152,68,4,4,1,1,NULL,1.0000,4.8000,'2020-07-10 16:38:18','2020-07-10 16:38:18'),(153,68,20,20,1,1,NULL,1.0000,5.0000,'2020-07-10 16:38:18','2020-07-10 16:38:18'),(154,68,17,17,1,1,NULL,1.0000,2.0000,'2020-07-10 16:38:18','2020-07-10 16:38:18'),(155,68,21,21,1,1,NULL,1.0000,1.0000,'2020-07-10 16:38:18','2020-07-10 16:38:18'),(156,69,7,7,1,1,NULL,1.0000,8.0000,'2020-07-10 16:39:34','2020-07-10 16:39:34'),(157,69,10,10,1,1,NULL,1.0000,1.0000,'2020-07-10 16:39:34','2020-07-10 16:39:34'),(158,69,17,17,1,1,NULL,1.0000,2.0000,'2020-07-10 16:39:34','2020-07-10 16:39:34'),(163,72,3,3,1,1,NULL,1.0000,6.0000,'2020-07-10 16:58:39','2020-07-10 16:58:39'),(164,72,4,4,1,1,NULL,1.0000,4.8000,'2020-07-10 16:58:39','2020-07-10 16:58:39'),(165,72,17,17,1,1,NULL,1.0000,3.0000,'2020-07-10 16:58:39','2020-07-10 16:58:39'),(166,72,10,10,1,1,NULL,1.0000,1.0000,'2020-07-10 16:58:39','2020-07-10 16:58:39'),(181,11,7,7,1,1,NULL,1.0000,5.0000,'2020-07-10 17:39:05','2020-07-10 17:39:05'),(182,11,15,15,1,1,NULL,1.0000,6.0000,'2020-07-10 17:39:05','2020-07-10 17:39:05'),(183,11,17,17,1,1,NULL,1.0000,2.0000,'2020-07-10 17:39:05','2020-07-10 17:39:05'),(211,65,4,4,1,1,NULL,1.0000,4.8000,'2020-07-10 18:32:22','2020-07-10 18:32:22'),(212,65,16,16,1,1,NULL,1.0000,6.0000,'2020-07-10 18:32:22','2020-07-10 18:32:22'),(213,65,18,18,1,1,NULL,1.0000,326.0000,'2020-07-10 18:32:22','2020-07-10 18:32:22'),(214,79,16,16,1,1,NULL,1.0000,6.0000,'2020-07-10 18:34:01','2020-07-10 18:34:01'),(215,79,28,28,1,1,NULL,1.0000,450.0000,'2020-07-10 18:34:01','2020-07-10 18:34:01'),(216,79,4,4,1,1,NULL,1.0000,4.5000,'2020-07-10 18:34:01','2020-07-10 18:34:01'),(217,79,17,17,1,1,NULL,1.0000,2.0000,'2020-07-10 18:34:01','2020-07-10 18:34:01'),(218,73,16,16,1,1,NULL,1.0000,6.0000,'2020-07-10 18:34:35','2020-07-10 18:34:35'),(219,73,23,23,1,1,NULL,1.0000,270.0000,'2020-07-10 18:34:35','2020-07-10 18:34:35'),(220,73,4,4,1,1,NULL,1.0000,4.5000,'2020-07-10 18:34:35','2020-07-10 18:34:35'),(221,73,17,17,1,1,NULL,1.0000,2.0000,'2020-07-10 18:34:35','2020-07-10 18:34:35'),(222,71,22,22,1,1,NULL,1.0000,270.0000,'2020-07-10 18:34:58','2020-07-10 18:34:58'),(223,71,16,16,1,1,NULL,1.0000,6.0000,'2020-07-10 18:34:58','2020-07-10 18:34:58'),(224,71,4,4,1,1,NULL,1.0000,4.5000,'2020-07-10 18:34:58','2020-07-10 18:34:58'),(225,71,17,17,1,1,NULL,1.0000,2.0000,'2020-07-10 18:34:58','2020-07-10 18:34:58'),(226,25,4,4,1,1,NULL,1.0000,4.5000,'2020-07-10 18:51:39','2020-07-10 18:51:39'),(227,25,30,30,2,7,1.0000,1.0000,134.0000,'2020-07-10 18:51:39','2020-07-10 18:51:39'),(228,25,14,14,1,1,NULL,1.0000,6.0000,'2020-07-10 18:51:39','2020-07-10 18:51:39'),(229,25,17,17,1,1,NULL,1.0000,2.0000,'2020-07-10 18:51:39','2020-07-10 18:51:39'),(230,45,17,17,1,1,NULL,1.0000,2.0000,'2020-07-10 19:01:28','2020-07-10 19:01:28'),(231,45,14,14,1,1,NULL,1.0000,6.0000,'2020-07-10 19:01:28','2020-07-10 19:01:28'),(232,45,32,32,2,7,1.0000,1.0000,50.0000,'2020-07-10 19:01:28','2020-07-10 19:01:28'),(233,45,31,31,2,7,1.0000,1.0000,50.0000,'2020-07-10 19:01:28','2020-07-10 19:01:28'),(234,45,33,33,2,7,1.0000,1.0000,50.0000,'2020-07-10 19:01:28','2020-07-10 19:01:28'),(235,45,34,34,2,7,1.0000,1.0000,50.0000,'2020-07-10 19:01:28','2020-07-10 19:01:28'),(236,45,4,4,1,1,NULL,1.0000,4.5000,'2020-07-10 19:01:28','2020-07-10 19:01:28'),(237,80,16,16,1,1,NULL,1.0000,6.0000,'2020-07-10 19:02:05','2020-07-10 19:02:05'),(238,80,29,29,1,1,NULL,1.0000,450.0000,'2020-07-10 19:02:05','2020-07-10 19:02:05'),(239,80,4,4,1,1,NULL,1.0000,4.5000,'2020-07-10 19:02:05','2020-07-10 19:02:05'),(240,80,17,17,1,1,NULL,1.0000,2.0000,'2020-07-10 19:02:05','2020-07-10 19:02:05'),(241,78,16,16,1,1,NULL,1.0000,6.0000,'2020-07-10 19:02:47','2020-07-10 19:02:47'),(242,78,27,27,1,1,NULL,1.0000,450.0000,'2020-07-10 19:02:47','2020-07-10 19:02:47'),(243,78,4,4,1,1,NULL,1.0000,4.5000,'2020-07-10 19:02:47','2020-07-10 19:02:47'),(244,78,17,17,1,1,NULL,1.0000,2.0000,'2020-07-10 19:02:47','2020-07-10 19:02:47'),(245,76,3,3,1,1,NULL,1.0000,6.0000,'2020-07-10 19:03:30','2020-07-10 19:03:30'),(246,76,25,25,1,1,NULL,1.0000,450.0000,'2020-07-10 19:03:30','2020-07-10 19:03:30'),(247,76,4,4,1,1,NULL,1.0000,4.5000,'2020-07-10 19:03:30','2020-07-10 19:03:30'),(248,76,17,17,1,1,NULL,1.0000,2.0000,'2020-07-10 19:03:30','2020-07-10 19:03:30'),(249,75,16,16,1,1,NULL,1.0000,6.0000,'2020-07-10 19:04:10','2020-07-10 19:04:10'),(250,75,24,24,1,1,NULL,1.0000,270.0000,'2020-07-10 19:04:10','2020-07-10 19:04:10'),(251,75,4,4,1,1,NULL,1.0000,4.5000,'2020-07-10 19:04:10','2020-07-10 19:04:10'),(252,75,17,17,1,1,NULL,1.0000,2.0000,'2020-07-10 19:04:10','2020-07-10 19:04:10'),(253,77,16,16,1,1,NULL,1.0000,6.0000,'2020-07-10 19:04:45','2020-07-10 19:04:45'),(254,77,4,4,1,1,NULL,1.0000,4.5000,'2020-07-10 19:04:45','2020-07-10 19:04:45'),(255,77,26,26,1,1,NULL,1.0000,450.0000,'2020-07-10 19:04:45','2020-07-10 19:04:45'),(256,77,17,17,1,1,NULL,1.0000,2.0000,'2020-07-10 19:04:45','2020-07-10 19:04:45'),(257,12,16,16,1,1,NULL,1.0000,6.0000,'2020-07-10 19:08:43','2020-07-10 19:08:43'),(258,12,4,4,1,1,NULL,1.0000,4.8000,'2020-07-10 19:08:43','2020-07-10 19:08:43'),(259,12,17,17,1,1,NULL,1.0000,2.5000,'2020-07-10 19:08:43','2020-07-10 19:08:43'),(260,12,35,35,2,7,1.0000,1.0000,140.0000,'2020-07-10 19:08:43','2020-07-10 19:08:43'),(261,13,4,4,1,1,NULL,1.0000,4.5000,'2020-07-10 19:10:51','2020-07-10 19:10:51'),(262,13,35,35,2,7,1.0000,1.0000,140.0000,'2020-07-10 19:10:51','2020-07-10 19:10:51'),(263,13,16,16,1,1,NULL,1.0000,6.0000,'2020-07-10 19:10:51','2020-07-10 19:10:51'),(264,13,17,17,1,1,NULL,1.0000,2.0000,'2020-07-10 19:10:51','2020-07-10 19:10:51'),(267,81,17,17,1,1,NULL,1.0000,2.0000,'2020-07-10 19:43:09','2020-07-10 19:43:09'),(268,81,3,3,1,1,NULL,1.0000,6.0000,'2020-07-10 19:43:09','2020-07-10 19:43:09'),(269,81,4,4,1,1,NULL,1.0000,4.5000,'2020-07-10 19:43:09','2020-07-10 19:43:09'),(270,81,36,36,2,7,1.0000,1.0000,30.0000,'2020-07-10 19:43:09','2020-07-10 19:43:09');
/*!40000 ALTER TABLE `use_product_tests` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `user_contact_access`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `user_contact_access` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` int(11) NOT NULL,
  `contact_id` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `user_contact_access` WRITE;
/*!40000 ALTER TABLE `user_contact_access` DISABLE KEYS */;
/*!40000 ALTER TABLE `user_contact_access` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `users` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `user_type` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'user',
  `surname` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `first_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `last_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `username` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `email` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `password` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `language` char(7) COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'en',
  `contact_no` char(15) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `remember_token` varchar(100) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `business_id` int(10) unsigned DEFAULT NULL,
  `max_sales_discount_percent` decimal(5,2) DEFAULT NULL,
  `allow_login` tinyint(1) NOT NULL DEFAULT 1,
  `essentials_department_id` int(11) DEFAULT NULL,
  `essentials_designation_id` int(11) DEFAULT NULL,
  `status` enum('active','inactive','terminated') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'active',
  `is_cmmsn_agnt` tinyint(1) NOT NULL DEFAULT 0,
  `cmmsn_percent` decimal(4,2) NOT NULL DEFAULT 0.00,
  `selected_contacts` tinyint(1) NOT NULL DEFAULT 0,
  `dob` date DEFAULT NULL,
  `gender` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `marital_status` enum('married','unmarried','divorced') COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `blood_group` char(10) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `contact_number` char(20) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `fb_link` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `twitter_link` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `social_media_1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `social_media_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `permanent_address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `current_address` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `guardian_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field_1` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field_2` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field_3` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `custom_field_4` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `bank_details` longtext COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_proof_name` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `id_proof_number` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `type` enum('employee','doctor') COLLATE utf8mb4_unicode_ci NOT NULL DEFAULT 'employee',
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_username_unique` (`username`),
  KEY `users_business_id_foreign` (`business_id`),
  KEY `users_user_type_index` (`user_type`),
  CONSTRAINT `users_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=86 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES (1,'user','Mr','Dawood','shah','dawoodshah','dawoodshah@gmail.com','$2y$10$NqCpkiS5n7D82h4Z1dWRe.B66OIObHHVmWo1TSGO3enrGQ5MnhuPW','en',NULL,NULL,'aFqPtsOoojNOlzWvPIg3gQ1yWYTjnyBieZoIM2dx7YylDnYDXhQjxmJFH4ZR',1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'2020-07-04 12:23:41','2020-07-04 12:23:41','employee'),(2,'user','mr','Mohabat','shah','mohabatshah','Mohabat@gmail.com','$2y$10$xKOaQ/O2L6/zB2M2tKiPVepD2XjdXd7g1Vg2xYY/J72.BSlGAh/BC','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 12:07:04','2020-07-04 12:07:04','employee'),(3,'user','dr','self','self','selfi','self@gamil.com','$2y$10$3LZ9VgtgsM3cBCsIUKRFOuAFFIBfuzoeA26a4cPL5n9S0WdfuKm8O','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 12:19:32','2020-07-04 12:19:32','doctor'),(4,'user','dr','WAQAR ALI','KHAN','WAQARALI','WAQAR@GMAIL.COM','$2y$10$OcOfeiEERqD9KgiudmlLkebWGu5yF/BLTXO7a.eM3j74AdM1.i65u','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 12:22:11','2020-07-04 12:22:11','doctor'),(5,'user','DR','DAWLAT','KHAN','DAWLATKHAN','DAWLAT@GMAIL.COM','$2y$10$YWAACztXc3aSCnWagOCHY.HqBs8xxD9cGMdLRmObQnnMzOmnyqF/W','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 12:23:34','2020-07-04 12:23:34','doctor'),(6,'user','DR','MUJAHID','KHAN','MUJAHID','MUJAHID@GMAIL.COM','$2y$10$Uvafy5Knt7/wp0s08j3WE.ys5xPu8UozzkJHuNHOArKPTdX7h1S8W','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 12:24:58','2020-07-04 12:24:58','doctor'),(7,'user','OPD','OPD','OPD','OPD@GMAIL.COM','OPD@GMAIL.COM','$2y$10$xpNDbrab8rQeNqon6lLMn.rWB2nzJx8ZL9fD44xsO9OLltRmcSWxS','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 12:27:12','2020-07-04 12:27:12','doctor'),(8,'user','DR','ZAFAR ALI','KHAN','ZAFAR','ZAFAR@GMAIL.COM','$2y$10$pOoXKBVa29W4rHSEIIs49up4FdcwyIMeR52IzK8uCPiMOwo4DCXB.','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 12:28:23','2020-07-04 12:28:23','doctor'),(9,'user','DR','SYED ABDULLAH','SHAH','SYED@GMAIL.COM','SYED@GMAIL.COM','$2y$10$xzVzqy..mKphhCFORcaxi.gi1KPvY1hALh9QeDuT465L8ZsLgBu/e','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 12:29:56','2020-07-04 12:29:56','doctor'),(10,'user','DR','SHER ZADA','MEDICAL CENTRE','SHERZADA','SHER@GMAIL.COM','$2y$10$y.P24LCd/Ao8nQaGCsZ2Meqf39kdvh2uRoOVOgsr8xwAYx.zaLSCG','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 12:31:28','2020-07-04 12:31:28','doctor'),(11,'user','DR','HIMAYAT','ULLAH SB','HIMAYAT','HIMAYAT@GMAIL.COM','$2y$10$li0/Hpalfd2M3pCJw7veL.4JeZCNv4g0H1Jn4PLOB/s4iXJ68cnh6','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 12:32:40','2020-07-04 12:32:40','doctor'),(12,'user','DR','NIZAR','KHAN','NIZAR','NIZAR@GMAIL.COM','$2y$10$SNHVwNVf0UU4TfbZaaDWS.C6.qyhufxP1tiyX0oedWLxE9gSlMoSa','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 12:38:16','2020-07-04 12:38:17','doctor'),(13,'user','DR','ABID','GHAFOOR','ABID1','ABID@GMAIL.COM','$2y$10$rfiqStGh/T6VPjuCpcldLOcy3outYeTXRW6lUgDE89h/J8gGiLqFe','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 12:39:24','2020-07-04 12:39:24','doctor'),(14,'user','DR','MUSHTAQ','AHMAD SB','MUSHTAQ','MUSHTAQ@GMAIL.COM','$2y$10$P0hIQTwkK6G03noMGDh9yeeaAkvJH2ywAtaQeph7k67BMrc86Smx2','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 12:40:27','2020-07-04 12:40:27','doctor'),(15,'user','DR','MUSTAFA','SB','MUSTAFA','MUSTAFA@GMAIL.COM','$2y$10$i0vDapRwKowU65MRG1MnQunaX/ncHgRJWpMMLeQx7j/lsimU3QpgS','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 12:41:35','2020-07-04 12:41:36','doctor'),(16,'user','DR','UMAR ALI','KHAN','UMARALI','UMAR@GMAIL.COM','$2y$10$BY9/T.LaPJjUUflol0RxNe0j/J2nVqVRVJHNqJdh9aAjuZOyQMKYG','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 12:42:50','2020-07-04 12:42:50','doctor'),(17,'user','DR','SHAKEEL','SB','SHAKEEL','SHAKEEL@GMAIL.COM','$2y$10$q5RZUnctGB.9x2YptryRCOcZNG.AcM5sWzVVZVcT5iaEnOhhePE.e','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 12:43:57','2020-07-04 12:43:57','doctor'),(18,'user','DR','HABIB','UR RAHMAN SB','HABIB','HABIB@GMAIL.COM','$2y$10$n/S5c02fcRBgvYKld.uiLe5dZsYOmHpppyxz7dieV8d3nsusND5He','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 12:45:04','2020-07-04 12:45:04','doctor'),(19,'user','DR','FAIZ','UR RAHMAN SB','FAIZ1','FAIZ@GMAIL.COM','$2y$10$HsRn.RH3SSif3wiaKy4yuO0ls8sb2fwhvaQw6CZ27pNSXldZk2cnq','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 12:46:14','2020-07-04 12:46:15','doctor'),(20,'user','DR','HASIB','RAHMAN SB','HASIB','HASIB@GMAIL.COM','$2y$10$Qo6ZKsPDQY5b19jTz4h7CO/.g6y.TsyKxxIcZYBb45/EwJ.jxNNfq','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 12:47:27','2020-07-04 12:47:27','doctor'),(21,'user','DR','KIFAYAT','ULLAH SB','KIFAYAT','KIFAYAT@GMAIL.COM','$2y$10$k.IQNTH0ZyeCsKuWp//0Y.LpAcN6HFQN.G/eXx/wR3EXRZjuKrqdy','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 12:48:38','2020-07-04 12:48:38','doctor'),(22,'user','DR','AMJAD ALI','SB','AMJAD','AMJADALI@GMAIL','$2y$10$BHo2HPlfzPwDb6mGr67jwentFsJsku8o9OjXGdC5V1Qc7oPeS5/Oq','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 12:49:47','2020-07-04 12:49:47','doctor'),(23,'user','DR','SHAFIQ','AHMAD SB','SHAFIQ','SHAFIQ@GMAIL.COM','$2y$10$FXNKEJzn5BoocCPtxwFdAuY6yt5n6w765TYM.8ykHcs4CtpV3Ig3S','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 12:50:52','2020-07-04 12:50:52','doctor'),(24,'user','DR','MUHAMMAD ESSA','KHAN','ESSA1','ESSA@GMAIL','$2y$10$Y1Fzh9dsrBdCBYYPrp/7AexkYpVh0AwcvMei1ukkw1e3Bw32rheZO','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 12:51:53','2020-07-04 12:51:53','doctor'),(25,'user','DR','GULSAMAD','SB','GULSAMAD','GULSAMAD@GMAIL.COM','$2y$10$9WkdwDWqkq8927i0Jg1SIOnGMFxBESGtPY.KabJwmbPA7iOT0I3X.','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 12:52:57','2020-07-04 12:52:57','doctor'),(26,'user','DR','AMJAD','IQBAL SB','AMJAD12','AMJAD@GMAIL.COM','$2y$10$GWyAH/c6NTMm9mWkIlkc4OaWKK8xsA1UzmlYv03bf3am4b9L9rvaa','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 12:54:09','2020-07-04 12:54:10','doctor'),(27,'user','DR','KISWAR','ALI SB','KISHWAR','KISWAR@GMAIL.COM','$2y$10$H3BdQUDP0w6JN6T6ba1uZ.KHP3e6SJOU3XbSnvJMov7uKSPoVu2gq','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 12:55:06','2020-07-04 12:55:06','doctor'),(28,'user','DR','SAEED','ULLAH SB','SAEED','SAEED@GMAIL.COM','$2y$10$hJZh4piNXRcHGmGJ65l/Q.njTZTCI.VfutGPuiHU5QO33em3cX1AK','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 12:56:07','2020-07-04 12:56:07','doctor'),(29,'user','DR','ANWAR','UL HAQ','ANWAR','ANWAR@GMAIL','$2y$10$xCOX4071Y6ZU0/rTuuGdwOnlJ4Z4G5uUe112LlT7ydHFt8hrkKk2G','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 12:57:21','2020-07-04 12:57:21','doctor'),(30,'user','DR','MUHAMMAD','ASHRAF SB','ASHRAF','ASHRAF@GMAIL.COM','$2y$10$x0qhJhabc8z9EAoHd0H/AOtj8iBQ2VvKAcrl.DRRzoL3GRQjlg3Ny','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:14:30','2020-07-04 13:14:30','doctor'),(31,'user','DR','RAHMAT','ALI SB','RAHMAT','RAHMAT@GMAIL','$2y$10$iun0ASmEdURc7hi4G8m.nOWT7qqkMz2Qz4xdT3XAUhNnZU7Hm5UqO','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:15:33','2020-07-04 13:15:33','doctor'),(32,'user','DR','SHAGUFTA','AMAN','SHAGUFTA','SHAGUFTA@GMAIL','$2y$10$Ka42wLWoQ6tlkXgTWnBAeuL6vFXHRtaOPJ/tmFUfMF1I6kysuAx7S','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:16:47','2020-07-04 13:16:47','doctor'),(33,'user','DR','MUHAMMAD','IMRAN SB','IMRAN','IMRAN@GMAIL','$2y$10$jESz3hRm6k8HTrSRSjPnpOtaUBIfOUPKhq3..xfOHyWuZF61bdcHG','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:17:49','2020-07-04 13:17:49','doctor'),(34,'user','DR','MEHRAN','ALI SB','MEHRAN','MEHRAN@GMAIL','$2y$10$d/I0grGbPRQCvJgICNqqMuATrnq1n57Lg1RdkpUdgGvD5ToRra99C','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:18:50','2020-07-04 13:18:50','doctor'),(35,'user','DR','ANWAR','ALI SB','ANWAR12','ANWAR12@GMAIL','$2y$10$vQpPbV1RXQiZHhGxiyr.XOrI/aHJ03Mb3HUlVWDns6/zpj4oPU/yi','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:20:07','2020-07-04 13:20:07','doctor'),(36,'user','DR','NOOR','AYISHA','NOOR1','NOOR@GMAIL','$2y$10$MP3ScM8Kw4knvP5jI62Iau9Uen1Fp6tkFVWt8kvRARY5X6BPWjjoO','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:21:13','2020-07-04 13:21:13','doctor'),(37,'user','DR','SHAHANA','AYAZ','SHAHANA','SHAHANA@GMAIL','$2y$10$MeHf9IeeUuBLgddxs0NxqeeCcnBkPyY.fAIaDBHZR6GqZy0gHMNNC','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:22:12','2020-07-04 13:22:12','doctor'),(38,'user','DR','MUHAMMAD','JAVED AFRIDI','JAVED','JAVED@GMAIL','$2y$10$onDjxXAw7PPw6XQzu0.bSuoW3h1bG1lWksgzttQO00GNWR8Xao5za','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:23:26','2020-07-04 13:23:26','doctor'),(39,'user','DR','FAZAL','RAHMAN SB','FAZAL','FAZAL@GMAIL','$2y$10$/4k/kKDXmLJGvNnB4d1py.RUOKVEI2YxqvZ1NcoV9GTBg49Rhu2Zq','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:24:36','2020-07-04 13:24:36','doctor'),(40,'user','DR','ABDULLAH','SB','ABDULLAH','ABDULLAH@GMAIL','$2y$10$96Hk5DGR2LoeaVVi.iEz1.lv5j7S0FT7xBejg0fhKbSXmqSAJkn/S','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:25:31','2020-07-04 13:25:31','doctor'),(41,'user','DR','BAHADAR','ALI KHAN','BAHADAR','BAHADAR@GMAIL','$2y$10$r1lW.bmTXagnU/DsemcCNuNup0dzO2qUqTsb/uuN39BBCuLrk54w2','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:26:25','2020-07-04 13:26:25','doctor'),(42,'user','DR','NOOR','RASHID SB','NOORRASHID@GMAIL','NOORRASHID@GMAIL','$2y$10$LcUrUI71Vuf1J2DQXBp1rOybatHeY7hnLojrTitpovFJtf3C7vjey','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:27:47','2020-07-04 13:27:47','doctor'),(43,'user','DR','KHAIR','UN NABI SB','KHAIR','KHAIR@GMAIL','$2y$10$CEufNeQIisaZMnhkKfyhF.s5RiM2u1/QJswPQinOMAF6TeZ/42cca','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:28:58','2020-07-04 13:28:58','doctor'),(44,'user','DR','NASAR','ULLAH SB','NASAR','NASAR@GMAIL','$2y$10$bAQ.arWlk40FiwUZTn8YoO64ORbdLL6p7fqr3jrnx1jb4itsBr3gO','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:30:00','2020-07-04 13:30:00','doctor'),(45,'user','DR','SULTAN','AKBAR SB','SULTAN','SULTAN@GMAIL','$2y$10$7cNHSh.SBBHNWlYD.8ykze8UrL2k7sb2msMJGlZtYYXu65YMrrhru','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:31:00','2020-07-04 13:31:00','doctor'),(46,'user','DR','SHAFI','ULLAH SB','SHAFI','SHAFI@GMAIL','$2y$10$cTdv1BPQU7Wx49CZtmFIF.jflM3bIQjFjfx1LzP7WD9imUBwzz1r.','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:31:53','2020-07-04 13:31:53','doctor'),(47,'user','DR','HAKEEM','FAZAL AKBAR SB','HAKEEM','HAKEEM@GMAIL','$2y$10$Xm1GRQ05X6pIdyKiRI9sdO/MRx9ZF303zP8KgJXBYAJVTriF2jPRy','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:32:59','2020-07-04 13:32:59','doctor'),(48,'user','DR','ASHRAF','SB','ASHRAF12','ASHRAF12@GMAIL','$2y$10$EobscjaJOAs5GnBjPJnwU.UZaa3rhqtqhMC6RuGIkha6nB4z2UfmK','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:34:06','2020-07-04 13:34:06','doctor'),(49,'user','DR','HAKEEM','INAM UL HAQ','HAKEEM12','HAKEEM12@GMAIL','$2y$10$4cGPJjf/qVNfrhi2v1uCIuERR9McG7jHeqEsgPt4f81jniXCXa/4S','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:35:30','2020-07-04 13:35:31','doctor'),(50,'user','DR','SHAKIR','ULLAH SB','SHAKIR','SHAKIR@GMAIL','$2y$10$iXQQpnK7vm2eZK5BsM1nXO.2D/vPtBOL53N6WWlJZl3KlsMiWVf6S','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:36:53','2020-07-04 13:36:53','doctor'),(51,'user','DR','IMRAN','ALI SB','IMRAN12','IMRAN12@GMAIL','$2y$10$FLZm8sbJBXELLaCTHxGzMeq1p4awzIqld.wWaSBh6.PjcXn8reYjy','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:38:33','2020-07-04 13:38:33','doctor'),(52,'user','DR','aSHFAQ','AHMAD SB','ASHFAQ','ASHFAQ@GMAIL','$2y$10$4FiwIJAjx/S7FGkFQhZ3IeKTkU0vCTinmc3Mz8gAyZa65uylmdW62','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:39:43','2020-07-04 13:39:43','doctor'),(53,'user','DR','PALWASHA','KHAN','PALWASHA','PALWASHA@GMAIL','$2y$10$cxhyfOevio24T9BH.nENTO4BWChpXnlt7320iAgUVaaZaHdlAdP5W','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:40:38','2020-07-04 13:40:38','doctor'),(54,'user','DR','SIRAJ','UD DIN SB','SIRAJ','SIRAJ@GMAIL','$2y$10$3uDsADAwSq2kNNIlgRXZVONRlipqOfxx2zDUt0Zn6sdkhxCruBrFu','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:41:44','2020-07-04 13:41:45','doctor'),(55,'user','DR','ALAM','MEDICAL COMPLEX','ALAM1','ALAM@GMAIL','$2y$10$6Q1xOKYBerJyqHaD.H7enO18kmS79ErAACRs5vJBqq7nbPKXiwXxO','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:42:44','2020-07-04 13:42:45','doctor'),(56,'user','DR','FAISAL','IKRAM','FAISAL','FAISAL@GMAIL','$2y$10$fdoKvE8JXIKFPG7H1EmUH.FX0qyzXrVyA9kZWiPUfsXpP5eS6qg9C','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:43:47','2020-07-04 13:43:47','doctor'),(57,'user','DR','SHER','AKBAR KHAN','SHER1','SHER@GMAIL','$2y$10$3O1YBocNQUZd8lPR6ASw8uk9RJuGtDlgDghd98WK34DZ4waTXHaqi','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:44:50','2020-07-04 13:44:51','doctor'),(58,'user','DR','SHAKIR','ULLAH SB','SHAKIR12','SHAKIR12@GMAIL','$2y$10$AKMf9UiKkxXhKigLFhJ6KeUE.SwLybjzLGD8W3hEEboHlxQjr8Hva','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:46:07','2020-07-04 13:46:08','doctor'),(59,'user','DR','ALIYA','ANWAR KHAN','ALIYA','ALIYA@GMAIL','$2y$10$eg5sifqfOZmIwOrG/gxVeuwr3Db/1y1.xWgG.eWs9NldrhCVzfO4O','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:47:13','2020-07-04 13:47:13','doctor'),(60,'user','DR','SYED NAIK','AMAL SHAH','NAIK1','NAIK@GMAIL','$2y$10$cK5uMPuKR5vhV54.ukB39.MB953GMsc7WkGCaIqr8sBXxyLr/ZcdW','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:49:10','2020-07-04 13:49:10','doctor'),(61,'user','DR','ZEB','HEALTH CLINIC','ZEB123','ZEB@GMAIL','$2y$10$pCDNqm9jiyyP2xM3jvsNV.rgYmZnBRYX1nawpDNfSODZxf3aeO.Jm','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:50:04','2020-07-04 13:50:04','doctor'),(62,'user','DR','WAQAR','AHMAD SB','WAQAR','WAQAR@GMAIL','$2y$10$IeAnaVP6FQCPLtej7uiAn.0yTrJrvjTaJLMGkPIC.AljyB5TrbVRK','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:50:54','2020-07-04 13:50:54','doctor'),(63,'user','DR','MUHAMMAD','SALEEM SB','SALEEM12','SALEEM@GMAIL','$2y$10$YJkZUT3UQK3pmcLBLvuV8eyjbQdSA9nZeV5AaxcJ0CBTCL0FgY35W','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:51:59','2020-07-04 13:51:59','doctor'),(64,'user','DR','BIO','TECH LAB','BIOTECH','BIOTECH@GMAIL','$2y$10$O04b0fZVvHfFYemZ55NZJ.BuF59g/0aYp43jPt8prpG0NYsu8o07.','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:53:00','2020-07-04 13:53:00','doctor'),(65,'user','DR','SAIF UD DIN','YOUSAFZAI','SAIF12','SAIF@GMAIL','$2y$10$joym7Y5oS.SQ4aNA1f6hL.sq5m9OCvRwuCeWDbG7Y2x309xDwtkHa','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:54:08','2020-07-04 13:54:08','doctor'),(66,'user','DR','AZEKHEL','LAB','AZEKHAIL','AZEKHEL@GMAIL','$2y$10$zMqTmwJ6sBSDrvDL9Tp3Y.4mYOI1BUUoGwK8ZVLLUqacKRORgzQoO','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:55:12','2020-07-04 13:55:12','doctor'),(67,'user','DR','NOOR','MUHAMMAD SB','NOOR21','NOOR21@GMAIL','$2y$10$YfBe0f7/60nzfTlntLidHuAvG0s1O6PYO2LYU5SIOAkBSZg7h/ItO','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:56:07','2020-07-04 13:56:07','doctor'),(68,'user','DR','ASLAM','ZEB SB','ASLAM12','ASLAM12@GMAIL','$2y$10$vGOsJlqtZ0VxLRUqF75hj.PhKefHRhHjHrlPLAQ4M8dUKbxGoruV2','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:57:01','2020-07-04 13:57:01','doctor'),(69,'user','DR','ZAMIRA','SULTAN','ZAMIRA','ZAMIRA@GMAIL','$2y$10$ccNYKcfWCWj7mbSDIMLb/OisQfPA189UIplR4QdgPniUVWIDyWd4.','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:57:50','2020-07-04 13:57:50','doctor'),(70,'user','DR','SALMAN','KHAN','SALMAN','SALMAN@GMAIL','$2y$10$g4m8ijFvrKkX.zQN3uWUeeA7XwPV9zUv/Arp7PhreBHAHddoOq9BO','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:58:37','2020-07-04 13:58:37','doctor'),(71,'user','DR','ISHFAQ','AHMAD SB','ISHFAQ','ISHFAQ@GMAIL','$2y$10$ciK66fFKb3wQ1aPPl9TFueyDxiFaUTzmBFzDKQCj7/N5IayM6.B7O','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 13:59:34','2020-07-04 13:59:34','doctor'),(72,'user','DR','AQSA','WAQAR','AQSA12','AQSA@GMAIL','$2y$10$P8Jl3jpvcqHLI8alYIH4LenvQptetIRUPWAwMu6.nkP7cPIUt..3y','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 14:00:21','2020-07-04 14:00:21','doctor'),(73,'user','DR','ABDUL','GHAFOOR SB','ABDUL','ABDUL@GMAIL','$2y$10$eazd/PMRQWSSSe0uquWLG./uAFcp0X7o.7nSxxc4SL8PzYnvcq5dm','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 14:01:48','2020-07-04 14:01:48','doctor'),(74,'user','DR','FAIZAN','ULLAH SB','FAIZAN','FAIZAN@GMAIL','$2y$10$3t.ffxbxLiiJiW.GKTQqJeStVppqka8KPq86CTyBUimkr5888AthS','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 14:02:39','2020-07-04 14:02:39','doctor'),(75,'user','DR','IHSAN','ULLAH SB','IHSAN','IHSAN@GMAIL','$2y$10$ev33bEc.3tsYjiujyUXcWeJpwyQ9MZrgUsMDsuJqNq5CbVayH0qtG','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 14:03:36','2020-07-04 14:03:36','doctor'),(76,'user','DR','KHALID','JAMAL SB','KHALID','KHALID@GMAIL','$2y$10$F6gXNwSaWjpMD/l9D5nRaOpIwXPXLfgwrPQsJ6X.g/3G4n5WN/FbS','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 14:04:48','2020-07-04 14:04:49','doctor'),(77,'user','DR','UMAIR','KHAN','UMAIR','UMAIR@GMAIL','$2y$10$.1NttYAoNRduGR2nVxJDwebf55Hb/yaMeBB2qTY57EBkkQAccEqCO','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 14:05:37','2020-07-04 14:05:37','doctor'),(78,'user','DR','HAKEEM SHER','RAHMAN SB','RAHMAN','RAHMAN@GMAIL','$2y$10$L.doYE0Q/LfSIzs8eU0YguDJu.uqQ82ep8bnFlHVjdGs5krOjdQde','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 14:06:48','2020-07-04 14:06:48','doctor'),(79,'user','DR','ASHRAF','ALI SB','ASHRAF21','ASHRAF21@GMAIL','$2y$10$AzU3ByVflwoKZUwQ1YjTsOAIoSBDwd0dKjgtm7DR8emB3VUXUPgGS','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 14:08:02','2020-07-04 14:08:02','doctor'),(80,'user','DR','ABID','FAROOQI','ABID3','ABID@GMAIL','$2y$10$RLliBWtyJ03AIFSrgLJWSOOK7jQVtnOTdEbrZOotkne5E0eLSWzKG','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 14:08:54','2020-07-04 14:08:54','doctor'),(81,'user','DR','MOHSIN','ALI SB','MOHSIN','MOHSIN@GMAIL','$2y$10$C/nhTeGbXpmNlQXkCjAfMeSzD9Qu/tu1S8zpZUv54hc.axj.tanme','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 14:10:18','2020-07-04 14:10:18','doctor'),(82,'user','DR','ALI','MURAD KHAN','MURAD','MURAD@GMAIL','$2y$10$s/eXWlH3cjre8Ito70Ktze3CxvRLLrcd.I8AqIlvjhp5K1JGyBguO','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 14:11:10','2020-07-04 14:11:10','doctor'),(83,'user','DR','SIKANDAR','BACHA SB','SIKANDAR','SIKANDAR@GMAIL','$2y$10$GtrCiOSJAfG6b.zKzyztnuzunDRf5naoNmSc1wSGSNd/NbHpPL/Q.','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 14:12:10','2020-07-04 14:12:10','doctor'),(84,'user','DR','NAVEED','ALAM SB','NAVEED','NAVEED@GMAIL','$2y$10$yoPRyRDqWUxLSTtRMjbZNuJe9Ys8Dr7ZNcP1LbkMNCnWnrW52ZhQ2','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 14:12:59','2020-07-04 14:12:59','doctor'),(85,'user','DR','SARDAR','ALI SB','SARDAR','SARDAR@GMAIL','$2y$10$8Tlr.ooLaPdUU5qUS3h7nOMivTUuj18owWfdzGtsBS5lj0LiuW/Mm','en',NULL,NULL,NULL,1,NULL,1,NULL,NULL,'active',0,0.00,0,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,NULL,'{\"account_holder_name\":null,\"account_number\":null,\"bank_name\":null,\"bank_code\":null,\"branch\":null,\"tax_payer_id\":null}',NULL,NULL,NULL,'2020-07-04 14:14:23','2020-07-04 14:14:23','doctor');
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `vaccines`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `vaccines` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `business_id` int(10) unsigned NOT NULL,
  `actual_name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `base_id` int(11) DEFAULT NULL,
  `created_by` int(10) unsigned NOT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `vaccines_business_id_foreign` (`business_id`),
  KEY `vaccines_created_by_foreign` (`created_by`),
  CONSTRAINT `vaccines_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE,
  CONSTRAINT `vaccines_created_by_foreign` FOREIGN KEY (`created_by`) REFERENCES `users` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `vaccines` WRITE;
/*!40000 ALTER TABLE `vaccines` DISABLE KEYS */;
/*!40000 ALTER TABLE `vaccines` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `variation_group_prices`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `variation_group_prices` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `variation_id` int(10) unsigned NOT NULL,
  `price_group_id` int(10) unsigned NOT NULL,
  `price_inc_tax` decimal(22,4) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `variation_group_prices_variation_id_foreign` (`variation_id`),
  KEY `variation_group_prices_price_group_id_foreign` (`price_group_id`),
  CONSTRAINT `variation_group_prices_price_group_id_foreign` FOREIGN KEY (`price_group_id`) REFERENCES `selling_price_groups` (`id`) ON DELETE CASCADE,
  CONSTRAINT `variation_group_prices_variation_id_foreign` FOREIGN KEY (`variation_id`) REFERENCES `variations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `variation_group_prices` WRITE;
/*!40000 ALTER TABLE `variation_group_prices` DISABLE KEYS */;
/*!40000 ALTER TABLE `variation_group_prices` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `variation_location_details`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `variation_location_details` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `product_id` int(10) unsigned NOT NULL,
  `product_variation_id` int(10) unsigned NOT NULL COMMENT 'id from product_variations table',
  `variation_id` int(10) unsigned NOT NULL,
  `location_id` int(10) unsigned NOT NULL,
  `qty_available` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `variation_location_details_location_id_foreign` (`location_id`),
  KEY `variation_location_details_product_id_index` (`product_id`),
  KEY `variation_location_details_product_variation_id_index` (`product_variation_id`),
  KEY `variation_location_details_variation_id_index` (`variation_id`),
  CONSTRAINT `variation_location_details_location_id_foreign` FOREIGN KEY (`location_id`) REFERENCES `business_locations` (`id`),
  CONSTRAINT `variation_location_details_variation_id_foreign` FOREIGN KEY (`variation_id`) REFERENCES `variations` (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `variation_location_details` WRITE;
/*!40000 ALTER TABLE `variation_location_details` DISABLE KEYS */;
INSERT INTO `variation_location_details` VALUES (1,3,3,3,2,-13.0000,'2020-07-04 13:19:21','2020-07-10 20:24:53'),(2,4,4,4,2,-14.0000,'2020-07-04 13:19:21','2020-07-10 20:24:53'),(3,1,1,1,2,-1575.0000,'2020-07-04 13:19:21','2020-07-10 20:24:53'),(4,2,2,2,2,-175.0000,'2020-07-04 13:19:21','2020-07-10 20:24:53'),(5,6,6,6,2,-1.0000,'2020-07-07 16:26:34','2020-07-07 16:26:34'),(6,12,12,12,2,-1.0000,'2020-07-07 16:41:21','2020-07-07 16:41:21'),(7,17,17,17,2,-6.0000,'2020-07-08 15:59:38','2020-07-10 20:24:53'),(8,10,10,10,2,-4.0000,'2020-07-10 17:02:50','2020-07-10 20:24:53'),(9,7,7,7,2,-1.0000,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(10,8,8,8,2,-1.0000,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(11,9,9,9,2,-1.0000,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(12,11,11,11,2,-1.0000,'2020-07-10 19:49:04','2020-07-10 19:49:04'),(13,5,5,5,2,-0.4000,'2020-07-10 19:49:04','2020-07-10 19:57:41');
/*!40000 ALTER TABLE `variation_location_details` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `variation_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `variation_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `business_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `variation_templates_business_id_foreign` (`business_id`),
  CONSTRAINT `variation_templates_business_id_foreign` FOREIGN KEY (`business_id`) REFERENCES `business` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `variation_templates` WRITE;
/*!40000 ALTER TABLE `variation_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `variation_templates` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `variation_value_templates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `variation_value_templates` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `variation_template_id` int(10) unsigned NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  KEY `variation_value_templates_name_index` (`name`),
  KEY `variation_value_templates_variation_template_id_index` (`variation_template_id`),
  CONSTRAINT `variation_value_templates_variation_template_id_foreign` FOREIGN KEY (`variation_template_id`) REFERENCES `variation_templates` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `variation_value_templates` WRITE;
/*!40000 ALTER TABLE `variation_value_templates` DISABLE KEYS */;
/*!40000 ALTER TABLE `variation_value_templates` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `variations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `variations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `product_id` int(10) unsigned NOT NULL,
  `sub_sku` varchar(191) COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `product_variation_id` int(10) unsigned NOT NULL,
  `variation_value_id` int(11) DEFAULT NULL,
  `default_purchase_price` decimal(22,4) DEFAULT NULL,
  `dpp_inc_tax` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `profit_percent` decimal(22,4) NOT NULL DEFAULT 0.0000,
  `default_sell_price` decimal(22,4) DEFAULT NULL,
  `sell_price_inc_tax` decimal(22,4) DEFAULT NULL COMMENT 'Sell price including tax',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `deleted_at` timestamp NULL DEFAULT NULL,
  `combo_variations` text COLLATE utf8mb4_unicode_ci DEFAULT NULL COMMENT 'Contains the combo variation details',
  PRIMARY KEY (`id`),
  KEY `variations_product_id_foreign` (`product_id`),
  KEY `variations_product_variation_id_foreign` (`product_variation_id`),
  KEY `variations_name_index` (`name`),
  KEY `variations_sub_sku_index` (`sub_sku`),
  KEY `variations_variation_value_id_index` (`variation_value_id`),
  CONSTRAINT `variations_product_id_foreign` FOREIGN KEY (`product_id`) REFERENCES `products` (`id`) ON DELETE CASCADE,
  CONSTRAINT `variations_product_variation_id_foreign` FOREIGN KEY (`product_variation_id`) REFERENCES `product_variations` (`id`) ON DELETE CASCADE
) ENGINE=InnoDB AUTO_INCREMENT=37 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `variations` WRITE;
/*!40000 ALTER TABLE `variations` DISABLE KEYS */;
INSERT INTO `variations` VALUES (1,'DUMMY',1,'0001',1,NULL,0.5250,0.5300,0.0000,0.5300,0.5300,'2020-07-04 12:28:28','2020-07-04 12:28:28',NULL,'[]'),(2,'DUMMY',2,'0002',2,NULL,0.5250,0.5300,0.0000,0.5300,0.5300,'2020-07-04 12:30:02','2020-07-04 12:30:02',NULL,'[]'),(3,'DUMMY',3,'0003',3,NULL,6.0000,6.0000,0.0000,6.0000,6.0000,'2020-07-04 12:30:36','2020-07-04 12:30:36',NULL,'[]'),(4,'DUMMY',4,'0004',4,NULL,4.8000,4.8000,0.0000,4.8000,4.8000,'2020-07-04 12:31:16','2020-07-07 16:19:19',NULL,'[]'),(5,'DUMMY',5,'0005',5,NULL,21.0000,21.0000,0.0000,21.0000,21.0000,'2020-07-06 06:04:19','2020-07-06 06:08:10',NULL,'[]'),(6,'DUMMY',6,'0006',6,NULL,65.0000,65.0000,0.0000,65.0000,65.0000,'2020-07-06 06:11:34','2020-07-06 06:11:34',NULL,'[]'),(7,'DUMMY',7,'0007',7,NULL,5.0000,5.0000,0.0000,5.0000,5.0000,'2020-07-06 06:16:53','2020-07-06 06:16:53',NULL,'[]'),(8,'DUMMY',8,'0008',8,NULL,4.5000,4.5000,0.0000,4.5000,4.5000,'2020-07-06 06:17:55','2020-07-06 06:17:55',NULL,'[]'),(9,'DUMMY',9,'0009',9,NULL,9.0000,9.0000,0.0000,9.0000,9.0000,'2020-07-06 06:19:15','2020-07-06 06:19:15',NULL,'[]'),(10,'DUMMY',10,'0010',10,NULL,1.0000,1.0000,0.0000,1.0000,1.0000,'2020-07-06 06:19:59','2020-07-06 06:19:59',NULL,'[]'),(11,'DUMMY',11,'0011',11,NULL,1.0000,1.0000,0.0000,1.0000,1.0000,'2020-07-06 06:20:50','2020-07-06 06:20:50',NULL,'[]'),(12,'DUMMY',12,'0012',12,NULL,7.0000,7.0000,0.0000,7.0000,7.0000,'2020-07-06 07:06:05','2020-07-06 07:06:05',NULL,'[]'),(14,'DUMMY',14,'0014',14,NULL,6.0000,6.0000,0.0000,6.0000,6.0000,'2020-07-07 16:52:05','2020-07-07 16:52:05',NULL,'[]'),(15,'DUMMY',15,'0015',15,NULL,6.0000,6.0000,0.0000,6.0000,6.0000,'2020-07-07 17:19:10','2020-07-07 17:19:10',NULL,'[]'),(16,'DUMMY',16,'0016',16,NULL,6.0000,6.0000,0.0000,6.0000,6.0000,'2020-07-07 17:26:45','2020-07-07 17:26:45',NULL,'[]'),(17,'DUMMY',17,'0017',17,NULL,2.5000,2.5000,0.0000,2.5000,2.5000,'2020-07-07 17:28:45','2020-07-07 17:28:45',NULL,'[]'),(18,'DUMMY',18,'0018',18,NULL,326.0000,326.0000,0.0000,326.0000,326.0000,'2020-07-10 16:05:18','2020-07-10 16:05:18',NULL,'[]'),(19,'DUMMY',19,'0019',19,NULL,90.0000,90.0000,0.0000,90.0000,90.0000,'2020-07-10 16:17:34','2020-07-10 16:17:34',NULL,'[]'),(20,'DUMMY',20,'0020',20,NULL,5.0000,5.0000,0.0000,5.0000,5.0000,'2020-07-10 16:34:53','2020-07-10 16:34:53',NULL,'[]'),(21,'DUMMY',21,'0021',21,NULL,1.0000,1.0000,0.0000,1.0000,1.0000,'2020-07-10 16:36:18','2020-07-10 16:36:18',NULL,'[]'),(22,'DUMMY',22,'0022',22,NULL,270.0000,270.0000,0.0000,270.0000,270.0000,'2020-07-10 16:47:18','2020-07-10 16:47:18',NULL,'[]'),(23,'DUMMY',23,'0023',23,NULL,270.0000,270.0000,0.0000,270.0000,270.0000,'2020-07-10 16:59:54','2020-07-10 16:59:54',NULL,'[]'),(24,'DUMMY',24,'0024',24,NULL,280.0000,280.0000,0.0000,280.0000,280.0000,'2020-07-10 17:07:13','2020-07-10 17:07:13',NULL,'[]'),(25,'DUMMY',25,'0025',25,NULL,450.0000,450.0000,0.0000,450.0000,450.0000,'2020-07-10 17:27:12','2020-07-10 17:27:12',NULL,'[]'),(26,'DUMMY',26,'0026',26,NULL,470.0000,470.0000,0.0000,470.0000,470.0000,'2020-07-10 17:41:51','2020-07-10 17:41:51',NULL,'[]'),(27,'DUMMY',27,'0027',27,NULL,450.0000,450.0000,0.0000,450.0000,450.0000,'2020-07-10 17:51:17','2020-07-10 17:51:17',NULL,'[]'),(28,'DUMMY',28,'0028',28,NULL,450.0000,450.0000,0.0000,450.0000,450.0000,'2020-07-10 17:57:51','2020-07-10 17:57:51',NULL,'[]'),(29,'DUMMY',29,'0029',29,NULL,450.0000,450.0000,0.0000,450.0000,450.0000,'2020-07-10 18:16:49','2020-07-10 18:16:49',NULL,'[]'),(30,'DUMMY',30,'0030',30,NULL,134.0000,134.0000,0.0000,134.0000,134.0000,'2020-07-10 18:47:32','2020-07-10 18:47:32',NULL,'[]'),(31,'DUMMY',31,'0031',31,NULL,50.0000,50.0000,0.0000,50.0000,50.0000,'2020-07-10 18:55:56','2020-07-10 18:55:56',NULL,'[]'),(32,'DUMMY',32,'0032',32,NULL,50.0000,50.0000,0.0000,50.0000,50.0000,'2020-07-10 18:56:24','2020-07-10 18:56:24',NULL,'[]'),(33,'DUMMY',33,'0033',33,NULL,50.0000,50.0000,0.0000,50.0000,50.0000,'2020-07-10 18:56:56','2020-07-10 18:56:56',NULL,'[]'),(34,'DUMMY',34,'0034',34,NULL,50.0000,50.0000,0.0000,50.0000,50.0000,'2020-07-10 18:58:10','2020-07-10 18:58:10',NULL,'[]'),(35,'DUMMY',35,'0035',35,NULL,140.0000,140.0000,0.0000,140.0000,140.0000,'2020-07-10 19:06:01','2020-07-10 19:06:01',NULL,'[]'),(36,'DUMMY',36,'0036',36,NULL,30.0000,30.0000,0.0000,30.0000,30.0000,'2020-07-10 19:41:54','2020-07-10 19:41:54',NULL,'[]');
/*!40000 ALTER TABLE `variations` ENABLE KEYS */;
UNLOCK TABLES;
DROP TABLE IF EXISTS `warranties`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `warranties` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(191) COLLATE utf8mb4_unicode_ci NOT NULL,
  `business_id` int(11) NOT NULL,
  `description` text COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `duration` int(11) NOT NULL,
  `duration_type` enum('days','months','years') COLLATE utf8mb4_unicode_ci NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

LOCK TABLES `warranties` WRITE;
/*!40000 ALTER TABLE `warranties` DISABLE KEYS */;
/*!40000 ALTER TABLE `warranties` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

